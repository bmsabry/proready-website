# Pro3DWorks — local native CAD viewing

This build adds genuine local SolidWorks/NX geometry decoding behind the application's Open workflow. It is not a standalone browser-native CAD kernel. The external approved NVIDIA/HOOPS runtime converts supported native input to viewing geometry locally; the application preserves source provenance and labels that result tessellated/unverified rather than exact editable B-rep.

## Quick setup on any Windows x64 PC

To give end users native SolidWorks (`.SLDPRT` / `.SLDASM`) and Siemens NX (`.prt`) geometry viewing **without** a Node build toolchain or `npm install`:

1. Download **`Pro3DWorks-v2.70.1-Windows-Native-Kit.zip`** from the GitHub Release (or clone the repository) and extract it to a writable local folder.
2. Double-click **`Setup-Pro3DWorks-Native.cmd`** once:
   - Checks for **Node.js 20+** and **Python 3.12** (64-bit), offering optional `winget` installation if either is missing.
   - Displays the NVIDIA Omniverse CAD Converter (`usd-convert-cad 0.3.0`, which uses the Tech Soft 3D HOOPS Exchange SDK) license terms and requires explicit `I ACCEPT` consent before creating an isolated Python 3.12 virtual environment under `%LOCALAPPDATA%\Pro3DWorks\native-cad-runtime` and installing `usd-convert-cad==0.3.0` from PyPI.
   - Verifies the pre-bundled helper files by SHA-256 (`native-kit/kit-manifest.json` via `bridge/configure-kit.mjs` — zero `npm install` needed in the packaged kit) and configures `%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-v2.70.1`.
   - Runs automated `--doctor --json` readiness checks before completion.
3. Double-click **`Start-Pro3DWorks-Native.cmd`** anytime to start the local loopback native CAD helper and open `dist/Pro3DWorks.html` in your default browser.

Run **Start-Pro3DWorks-Native.cmd from the kit or project root**. The current viewer is `dist/Pro3DWorks.html`; the root `Pro3DWorks.html` convenience copy carries identical bytes. The launcher prefers the configured helper in `%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-v2.70.1` (or `native-cad-helper-sw2800`), falling back to `native-local/`. From the root directory, `Start-Pro3DWorks-Native.cmd --doctor` checks the active helper without opening a browser, and `Setup-Pro3DWorks-Native.cmd --check` prints prerequisite status without making changes.

The launcher keeps private CAD/conversion work in local application storage (`%LOCALAPPDATA%\Pro3DWorks\native-cad-work\...`), never inside synced folders. Neither the Git repository nor the downloadable Windows Native Kit bundles NVIDIA/HOOPS binaries, wheels, or licence keys; an SDK runtime license is never bypassed or silently accepted.

### Manual repository setup (developers)

From a source checkout after reviewing and accepting NVIDIA runtime terms and installing Node 20+ and `usd-convert-cad==0.3.0`:

```text
npm ci
node bridge/configure-native.mjs --output-dir native-local --app dist/Pro3DWorks.html --python "C:\path\to\approved-runtime\python.exe" --node "C:\path\to\node.exe" --licensed-runtime
Start-Pro3DWorks-Native.cmd
```

To regenerate the end-user ZIP and single-file release artifacts in `output/`:

```text
npm run build
npm run package:native-kit
```

The `--licensed-runtime` switch is an operator attestation, not licence activation or a grant. Configuration requires an unoccupied target; never overwrite an existing helper blindly. Keep private runtime binaries, keys, CAD inputs and converted geometry outside Git and synced project storage.

## Start and open

1. Run **Start-Pro3DWorks-Native.cmd** at the authoritative project root. Keep that window open while using native translation. It starts a loopback-only service and opens the application in your default browser. Closing the browser alone does not stop the helper.
2. For a part, use the normal **Open** file action and select the actual `.SLDPRT` or NX `.prt` file.
3. For an assembly, provide the native root **and all supplied references**. The **Open assembly folder…** action preserves relative folders; multi-selecting files is suitable for a flat package with unique filenames.
4. If the primary-model dialog appears, explicitly select the intended native root. There is no default root. In particular, `.prt` does not distinguish an NX part from an assembly. Do not choose based on file size.
5. The original native file remains primary. An internal GLB/USD carrier is an implementation detail, not a requirement to export your own STEP/STL.

For supported legacy SolidWorks 2800 assemblies, select **Use strict native helper** rather than the separate saved-display option. The helper tessellates the validated stored Parasolid geometry and preserves the supplied assembly placements. It does not apply rollback deltas or regenerate SolidWorks authoring features. Missing components still stop the import. The stored route requires the separate installed and SHA-256-pinned X_B verifier in addition to the licensed converter; the default `native-local/` configuration above does not enable it.

For the supplied KROSS example, provide `KROSS.SLDASM`, its native component files and its actually declared `ATV_TIRE+jante AR_12 pouces.STEP` feature dependency. That STEP was already supplied in the original source package; it is not a substituted standalone model. A deliberately native-only subset without it must refuse.

## Verified native journeys on the integrated build

| Actual native input | Source mesh occurrences | Render Parts | Triangles |
|---|---:|---:|---:|
| SolidWorks `28.SLDPRT` | 1 | 1 | 12,910 |
| NX `Jet_Engine_Fan-Washer.prt` | 1 | 1 | 512 |
| SolidWorks `GIU.SLDASM` + references | 3 | 3 | 9,400 |
| NX `Jet_Engine-Assembly.prt` + references | 125 | 125 | 699,416 |
| SolidWorks `KROSS.SLDASM` + native/STEP references | 121 | 128 | 636,431 |
| Public `C04_cube_hole_5mm.SLDPRT` — native-v4 / XML15000 | 1 | 1 | 272 |
| Public `C10_cube_shell_1mm.SLDPRT` — CFB-v3 / XML4700 | 1 | 1 | 28 |
| Robotis `i101_Set.SLDASM`, FR05 + three native parts — XML6000 | 3 | 3 | 5,920 |
| SolidWorks `Horizontal Rig.SLDPRT` — CFB-v3 `_MO_VERSION_4100` | 29 | 29 | 16,358 |

The `_MO_VERSION_4100` and `_MO_VERSION_3400` CFB metadata & reference audit profiles (`src/native-solidworks-4100.js`, `bridge/solidworks-reference-audit.mjs`) also extend qualified local native opening to additional modern/legacy SolidWorks compound-file saves while preserving strict reference-closure checks and missing-child refusals. All preceding cases were replayed against the current HTML served by the project-root launcher. See [the compatibility repair](SOLIDWORKS_COMPATIBILITY_FIX.md) for profiles, source hashes and retained failures.

A material-split mesh occurrence can create multiple render Parts. KROSS's 128 Parts preserve 121 source mesh occurrences and every source node/mesh/primitive association; these counts are **not a native product/component inventory**. Its native-origin project was actually saved and reopened with exact geometry buffers, 203 source-hierarchy records, provider/source-set provenance, camera and X-ray state retained.

Actual GUI controls also verified: cancel the primary choice; reject a missing native fan subassembly; reject the missing declared STEP; reject a malformed native root; reject ambiguous native component paths; cancel active translation; and successfully retry the complete bundle without changing the pre-existing scene on refusal/cancellation.

## What the labels mean

- **Tessellated / mesh / unverified** is expected. This is viewing geometry, not lossless editable B-rep, regenerated features or independently certified all-entity coverage.
- A closed reference-file graph is not proof that every native body, configuration or entity was decoded. Unknown geometry completeness remains unknown; it is not relabeled complete or known incomplete.
- Units and placements were checked against authored USD length/axis metadata and independently transformed mesh points. Display bounds are not manufacturing tolerances or a complete native geometry inventory.
- glTF indices and USD paths identify structure within the produced artifacts. They are not persistent native CAD product UUIDs or proof of deduplicated application storage.
- A tree label ending in `.glb` can name the internal viewing carrier; original native name, source-set hashes and provider provenance remain recorded separately.

## Supported scope and refusals

The tested local reader route and bounded reference-audit profiles are qualified, not every possible SolidWorks/NX version, configuration, virtual component or feature graph. Unknown physical/Features profiles, unproved imported child graphs, unsupported neutral-reference syntax, missing/ambiguous references and unsafe aliases are explicitly refused. Existing absolute/UNC/device references outside the staged package can be refused even when a similarly named file is supplied. Do not remove declared obligations or rename unrelated files merely to force a load.

When the configured native decoder is unavailable, the application's older saved-display/structure fallback can remain available with its own warnings. Such a fallback is **not** a successful native-geometry conversion. A provider that actually attempts and refuses conversion must not silently become a saved-display success.

## Runtime and licence boundary

This local Windows installation uses the separately installed approved CPython 3.12 NVIDIA `usd-convert-cad` 0.3.0 runtime and the explicitly configured Node executable. The helper package does **not** include the proprietary translator runtime, its wheel, an authoring-CAD installation or a licence key. Installed runtime terms remain applicable. Local installation/testing approval does not establish commercial use or proprietary redistribution rights; no purchase, licence bypass or CAD upload is part of this workflow.

The earlier qualified v2.69.0 HTML and v2.68.5 rollback are preserved separately. Use the native helper launcher rather than assuming an old standalone HTML file includes the decoder.
