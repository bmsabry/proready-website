@echo off
setlocal DisableDelayedExpansion
if /i "%~1"=="--check" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bridge\Setup-Native-Helper.ps1" -CheckOnly
  exit /b %errorlevel%
)
if /i "%~1"=="-CheckOnly" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bridge\Setup-Native-Helper.ps1" %*
  exit /b %errorlevel%
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bridge\Setup-Native-Helper.ps1" %*
set "P3DW_ERR=%errorlevel%"
if not "%P3DW_ERR%"=="0" (
  pause
  exit /b %P3DW_ERR%
)
echo.
pause
endlocal
exit /b 0
