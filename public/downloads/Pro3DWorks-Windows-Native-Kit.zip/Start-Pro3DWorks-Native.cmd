@echo off
setlocal DisableDelayedExpansion
set "P3DW_APP_VERSION="
set "P3DW_VER_SRC=%~dp0package.json"
if exist "%~dp0native-kit\kit-manifest.json" set "P3DW_VER_SRC=%~dp0native-kit\kit-manifest.json"
if exist "%P3DW_VER_SRC%" (
  for /f "tokens=2 delims=:, " %%V in ('findstr /R /C:"^  \"version\":" "%P3DW_VER_SRC%" 2^>nul') do set "P3DW_APP_VERSION=%%~V"
)
if not defined P3DW_APP_VERSION set "P3DW_APP_VERSION=2.70.1"

set "P3DW_NATIVE_HELPER=%~dp0native-local"
if exist "%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-sw2800\bridge.config.json" set "P3DW_NATIVE_HELPER=%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-sw2800"
for /f "delims=" %%D in ('dir /b /ad /on "%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-v*" 2^>nul') do (
  if exist "%LOCALAPPDATA%\Pro3DWorks\%%D\bridge.config.json" set "P3DW_NATIVE_HELPER=%LOCALAPPDATA%\Pro3DWorks\%%D"
)
if exist "%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-v%P3DW_APP_VERSION%\bridge.config.json" set "P3DW_NATIVE_HELPER=%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-v%P3DW_APP_VERSION%"

if not exist "%P3DW_NATIVE_HELPER%\bridge.config.json" (
  if /i "%~1"=="--doctor" (
    echo The local native helper is not configured. Run Setup-Pro3DWorks-Native.cmd or see docs\LOCAL_NATIVE_GUIDE.md.
    exit /b 1
  )
  if exist "%~dp0Setup-Pro3DWorks-Native.cmd" (
    choice /C YN /M "The native CAD helper is not set up yet. Run Setup-Pro3DWorks-Native.cmd now?"
    if errorlevel 2 exit /b 1
    call "%~dp0Setup-Pro3DWorks-Native.cmd" -NoLaunch
    if errorlevel 1 exit /b 1
    if exist "%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-v%P3DW_APP_VERSION%\bridge.config.json" set "P3DW_NATIVE_HELPER=%LOCALAPPDATA%\Pro3DWorks\native-cad-helper-v%P3DW_APP_VERSION%"
  )
)
if not exist "%P3DW_NATIVE_HELPER%\bridge.config.json" (
  echo The local native helper is not configured. Run Setup-Pro3DWorks-Native.cmd or see docs\LOCAL_NATIVE_GUIDE.md.
  if /i not "%~1"=="--doctor" pause
  exit /b 1
)
set "P3DW_CAD_COMMAND="
rem Always open the newest build in this folder, not a copy saved when the helper was set up.
set "P3DW_CAD_APP_PATH=%~dp0dist\Pro3DWorks.html"
if not exist "%P3DW_CAD_APP_PATH%" (
  echo dist\Pro3DWorks.html is missing. Build the app first.
  if /i not "%~1"=="--doctor" pause
  exit /b 1
)
set "P3DW_CAD_BRIDGE_PORT="
set "P3DW_CAD_BRIDGE_CONFIG=%P3DW_NATIVE_HELPER%\bridge.config.json"
rem Keep private uploaded CAD and conversion output off the synced project drive.
set "TEMP=%LOCALAPPDATA%\Pro3DWorks\native-cad-work\project-native-compat-2.69.1"
if not exist "%TEMP%" mkdir "%TEMP%"
if not exist "%TEMP%" exit /b 1
set "TMP=%TEMP%"
set "TMPDIR=%TEMP%"

set "P3DW_NATIVE_NODE="
if exist "%LOCALAPPDATA%\hermes\tools\node-26.12.1-win32-x64\node.exe" set "P3DW_NATIVE_NODE=%LOCALAPPDATA%\hermes\tools\node-26.12.1-win32-x64\node.exe"
if not defined P3DW_NATIVE_NODE (
  for /f "delims=" %%N in ('where node.exe 2^>nul') do (
    if not defined P3DW_NATIVE_NODE set "P3DW_NATIVE_NODE=%%N"
  )
)
if not defined P3DW_NATIVE_NODE if exist "%ProgramFiles%\nodejs\node.exe" set "P3DW_NATIVE_NODE=%ProgramFiles%\nodejs\node.exe"
if not defined P3DW_NATIVE_NODE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "P3DW_NATIVE_NODE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined P3DW_NATIVE_NODE (
  echo Node.js 20 or newer was not found. Install Node.js LTS or run Setup-Pro3DWorks-Native.cmd.
  if /i not "%~1"=="--doctor" pause
  exit /b 1
)
set "P3DW_NODE_MAJOR="
for /f "tokens=1 delims=v." %%V in ('""%P3DW_NATIVE_NODE%" -v" 2^>nul') do set "P3DW_NODE_MAJOR=%%V"
if not defined P3DW_NODE_MAJOR (
  echo Could not verify the Node.js version at "%P3DW_NATIVE_NODE%".
  if /i not "%~1"=="--doctor" pause
  exit /b 1
)
if %P3DW_NODE_MAJOR% LSS 20 (
  echo Node.js 20 or newer is required; found v%P3DW_NODE_MAJOR% at "%P3DW_NATIVE_NODE%".
  if /i not "%~1"=="--doctor" pause
  exit /b 1
)

if /i "%~1"=="--doctor" (
  "%P3DW_NATIVE_NODE%" "%P3DW_NATIVE_HELPER%\bridge-server.mjs" --doctor --json
  exit /b %errorlevel%
)
echo Pro3DWorks project-local native CAD helper. Close this window to stop it.
echo Opening the newest build: dist\Pro3DWorks.html
"%P3DW_NATIVE_NODE%" "%P3DW_NATIVE_HELPER%\bridge-server.mjs" --open
if errorlevel 1 pause
endlocal
