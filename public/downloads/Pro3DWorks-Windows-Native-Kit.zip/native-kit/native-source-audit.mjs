// bridge/native-source-audit.mjs
import { lstat, opendir, open, realpath, writeFile, mkdir, rename, unlink } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { Worker, isMainThread, parentPort, workerData } from "node:worker_threads";

// src/native-jt.js
function nativeError(code, message) {
  return Object.assign(new Error(message), { code });
}
function checkCancelled(signal) {
  if (signal?.aborted) throw nativeError("IMPORT_CANCELLED", "Native import cancelled");
}
function nativeBytes(buffer) {
  if (buffer instanceof ArrayBuffer) return new Uint8Array(buffer);
  if (ArrayBuffer.isView(buffer)) return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
  throw nativeError("NATIVE_MALFORMED", "Expected an ArrayBuffer or an ArrayBuffer view");
}
function malformed(message) {
  throw nativeError("NATIVE_MALFORMED", message);
}
function requireNative(condition, message) {
  if (!condition) malformed(message);
}
function hexBytes(bytes) {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}
function equalBytes(a, b) {
  return a.length === b.length && a.every((v, i) => v === b[i]);
}
function nativeText(bytes, encoding = "utf-8") {
  try {
    return new TextDecoder(encoding, { fatal: true }).decode(bytes);
  } catch {
    malformed(`Invalid ${encoding} text`);
  }
}
var NativeCursor = class {
  constructor(bytes, label = "native data", position = 0, end = bytes.length) {
    this.bytes = bytes;
    this.view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    this.label = label;
    this.p = position;
    this.end = end;
    requireNative(Number.isSafeInteger(position) && Number.isSafeInteger(end) && position >= 0 && position <= end && end <= bytes.length, `${label}: invalid extent`);
  }
  need(n) {
    requireNative(Number.isSafeInteger(n) && n >= 0 && n <= this.end - this.p, `${this.label}: truncated field at ${this.p}`);
  }
  take(n) {
    this.need(n);
    const b = this.bytes.subarray(this.p, this.p + n);
    this.p += n;
    return b;
  }
  u8() {
    this.need(1);
    return this.bytes[this.p++];
  }
  u16(le = true) {
    this.need(2);
    const v = this.view.getUint16(this.p, le);
    this.p += 2;
    return v;
  }
  u32(le = true) {
    this.need(4);
    const v = this.view.getUint32(this.p, le);
    this.p += 4;
    return v;
  }
  i32() {
    this.need(4);
    const v = this.view.getInt32(this.p, true);
    this.p += 4;
    return v;
  }
  u64() {
    this.need(8);
    const n = this.view.getBigUint64(this.p, true);
    this.p += 8;
    requireNative(n <= BigInt(Number.MAX_SAFE_INTEGER), `${this.label}: integer cannot address this buffer exactly`);
    return Number(n);
  }
  f32() {
    this.need(4);
    const v = this.view.getFloat32(this.p, true);
    this.p += 4;
    requireNative(Number.isFinite(v), `${this.label}: nonfinite binary32`);
    return v;
  }
  count(width, signed = false) {
    const n = signed ? this.i32() : this.u32();
    requireNative(n >= 0 && n <= Math.floor((this.end - this.p) / width), `${this.label}: count exceeds containing extent`);
    return n;
  }
  expect(bytes) {
    requireNative(equalBytes(this.take(bytes.length), bytes), `${this.label}: invalid marker at ${this.p - bytes.length}`);
  }
};
function nativeResult(format, name) {
  return {
    format,
    sourceName: name,
    streams: [],
    components: [],
    meshes: [],
    units: null,
    warnings: [],
    coverage: { container: false, structure: false, geometry: "none", placements: false, exactBrep: false }
  };
}
function reportNativeProgress(callback, signal, phase, completed, total) {
  checkCancelled(signal);
  if (typeof callback === "function") callback({ phase, completed, total });
  checkCancelled(signal);
}
async function inflateNativeZlib(bytes, signal) {
  checkCancelled(signal);
  if (typeof DecompressionStream !== "function") throw nativeError("NATIVE_UNSUPPORTED", "This runtime has no DecompressionStream deflate decoder");
  requireNative(bytes.length >= 6 && (bytes[0] & 15) === 8 && bytes[0] >>> 4 <= 7 && (bytes[0] << 8 | bytes[1]) % 31 === 0, "Invalid zlib header");
  if (bytes[1] & 32) throw nativeError("NATIVE_UNSUPPORTED", "Preset-dictionary zlib is not supported");
  let reader;
  let abort;
  try {
    reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate")).getReader();
    abort = () => {
      reader.cancel().catch(() => {
      });
    };
    signal?.addEventListener("abort", abort, { once: true });
    const chunks = [];
    let size = 0;
    for (; ; ) {
      checkCancelled(signal);
      const { done, value } = await reader.read();
      checkCancelled(signal);
      if (done) break;
      chunks.push(value);
      size += value.length;
    }
    const decoded = new Uint8Array(size);
    let p = 0;
    for (const chunk of chunks) {
      decoded.set(chunk, p);
      p += chunk.length;
    }
    return decoded;
  } catch (error2) {
    checkCancelled(signal);
    if (["NATIVE_UNSUPPORTED", "NATIVE_MALFORMED", "IMPORT_CANCELLED"].includes(error2.code)) throw error2;
    if (error2 instanceof RangeError) throw nativeError("NATIVE_UNSUPPORTED", `Runtime allocation failed while inflating JT: ${error2.message}`);
    malformed(`Invalid zlib member: ${error2.message}`);
  } finally {
    if (abort) signal?.removeEventListener("abort", abort);
    reader?.releaseLock();
  }
}
var PREFIX = new TextEncoder().encode("Version ");
var PARTITION = "3e10dd10c82ad1119b6b0080c7bb5997";
var TRISTRIP = "ab10dd10c82ad1119b6b0080c7bb5997";
var STRING_PROPERTY = "6e10dd10c82ad1119b6b0080c7bb5997";
var END_TYPE = "ffffffffffffffffffffffffffffffff";
function elements(bytes, start, label, signal) {
  const c = new NativeCursor(bytes, label, start);
  const values = [];
  const ids = /* @__PURE__ */ new Set();
  while (c.p < c.end) {
    checkCancelled(signal);
    const offset = c.p;
    const n = c.u32();
    requireNative(n >= 16 && n <= c.end - c.p, `${label}: invalid element length`);
    const typeId = hexBytes(c.take(16));
    if (typeId === END_TYPE) {
      requireNative(n === 16, `${label}: noncanonical end element`);
      return { values, end: c.p };
    }
    requireNative(n >= 21, `${label}: undersized element`);
    const baseType = c.u8();
    const objectId = c.u32();
    requireNative(!ids.has(objectId), `${label}: duplicate element object ID ${objectId}`);
    ids.add(objectId);
    const bodyOffset = c.p;
    c.take(n - 21);
    values.push({ offset, storedBytes: n + 4, typeId, baseType, objectId, bodyOffset, bodyBytes: n - 21 });
  }
  malformed(`${label}: missing end element`);
}
function bodyCursor(bytes, element, label) {
  return new NativeCursor(bytes, label, element.bodyOffset, element.bodyOffset + element.bodyBytes);
}
function boundedBox(c) {
  const offset = c.p;
  const b = Array.from({ length: 6 }, () => c.f32());
  if (b.every((_, i) => c.view.getUint32(offset + i * 4, true) === (i < 3 ? 2139081118 : 4286564766))) return { unavailable: true, serialized: b };
  requireNative(b[0] <= b[3] && b[1] <= b[4] && b[2] <= b[5], `${c.label}: reversed bounds`);
  return b;
}
function partitionNode(c) {
  const groupVersion = c.u16();
  if (groupVersion !== 1) throw nativeError("NATIVE_UNSUPPORTED", `JT partition group version ${groupVersion}`);
  const childCount = c.count(4, true);
  const childIds = Array.from({ length: childCount }, () => c.u32());
  const flags = c.u32();
  requireNative((flags & ~1) === 0, "JT partition: unknown flags");
  const count = c.count(2, true);
  const fileName = nativeText(c.take(count * 2), "utf-16le");
  requireNative(!/[\u0000-\u001f\u007f-\u009f]/u.test(fileName), "JT partition: control character in filename");
  const reservedBounds = flags & 1 ? null : boundedBox(c);
  const transformedBounds = boundedBox(c);
  const area = c.f32();
  requireNative(area >= 0, "JT partition: negative area");
  const ranges = Array.from({ length: 3 }, () => {
    const low = c.i32();
    const high = c.i32();
    requireNative(low >= 0 && (high === -1 || high >= low), "JT partition: invalid count range");
    return [low, high];
  });
  const untransformedBounds = flags & 1 ? boundedBox(c) : null;
  requireNative(c.p === c.end, "JT partition: trailing bytes");
  return { childIds, fileName, flags, reservedBounds, transformedBounds, untransformedBounds, area, ranges };
}
function inspectScene(bytes, sequence, segment, result) {
  const nodes = [];
  const nodeIds = /* @__PURE__ */ new Set();
  const parentLinks = [];
  for (const element of sequence.values) {
    if (element.baseType > 2) continue;
    const c = bodyCursor(bytes, element, "JT common node");
    const version = c.u16();
    if (version !== 1) {
      result.warnings.push(`JT common node ${element.objectId}: version ${version} remains opaque`);
      continue;
    }
    const flags = c.u32();
    const count = c.count(4, true);
    const attributeIds = Array.from({ length: count }, () => c.u32());
    const node = { objectId: element.objectId, typeId: element.typeId, flags, attributeIds, familyOffset: c.p, familyBytes: c.end - c.p, partition: null };
    if (element.typeId === PARTITION) {
      try {
        node.partition = partitionNode(c);
      } catch (error2) {
        if (error2.code !== "NATIVE_UNSUPPORTED") throw error2;
        result.warnings.push(error2.message);
      }
    }
    nodeIds.add(node.objectId);
    nodes.push(node);
  }
  for (const node of nodes) for (const childId of node.partition?.childIds || []) {
    requireNative(nodeIds.has(childId), `JT partition ${node.objectId}: unresolved child ${childId}`);
    parentLinks.push({ parentId: node.objectId, childId });
  }
  const incoming = new Map(nodes.map((n) => [n.objectId, []]));
  const outgoing = new Map(nodes.map((n) => [n.objectId, []]));
  for (const edge of parentLinks) {
    incoming.get(edge.childId).push(edge.parentId);
    outgoing.get(edge.parentId).push(edge.childId);
  }
  const degrees = new Map([...incoming].map(([id, parents]) => [id, parents.length]));
  const queue = nodes.filter((n) => degrees.get(n.objectId) === 0).map((n) => n.objectId);
  for (let i = 0; i < queue.length; i++) for (const id of outgoing.get(queue[i])) {
    degrees.set(id, degrees.get(id) - 1);
    if (!degrees.get(id)) queue.push(id);
  }
  requireNative(queue.length === nodes.length, "JT scene: cycle in partition child graph");
  for (const node of nodes) {
    const parents = incoming.get(node.objectId);
    result.components.push({
      id: `${segment.id}:${node.objectId}`,
      name: node.partition?.fileName || `JT node ${node.objectId}`,
      sourcePath: node.partition?.fileName || null,
      parentId: parents.length === 1 ? `${segment.id}:${parents[0]}` : null,
      transform: null
    });
    if (parents.length > 1) result.warnings.push(`JT node ${node.objectId}: multiple parents retained as edges, not collapsed into one occurrence`);
  }
  segment.nodes = nodes;
  segment.parentLinks = parentLinks;
  result.coverage.structure ||= nodes.length > 0;
  const properties = elements(bytes, sequence.end, "JT scene properties");
  segment.propertyElements = properties.values;
  segment.propertyTable = { offset: properties.end, storedBytes: bytes.length - properties.end };
}
function inspectShape(bytes, sequence, segment) {
  for (const element of sequence.values) {
    requireNative(element.baseType === 4, "JT shape LOD: wrong element base type");
    if (element.typeId !== TRISTRIP) continue;
    const c = bodyCursor(bytes, element, "JT tri-strip header");
    const baseVersion = c.u16(), vertexVersion = c.u16();
    const bindings = hexBytes(c.take(8));
    const topologicalMeshVersion = c.u16(), vertexRecordsObjectId = c.u32(), compressedLODVersion = c.u16();
    if (baseVersion !== 1 || vertexVersion !== 1 || ![1, 2].includes(topologicalMeshVersion) || ![1, 2].includes(compressedLODVersion)) {
      element.unsupported = "Unimplemented tri-strip header version";
      continue;
    }
    element.triStrip = {
      baseVersion,
      vertexVersion,
      bindings,
      topologicalMeshVersion,
      vertexRecordsObjectId,
      compressedLODVersion,
      encodedMeshOffset: c.p,
      encodedMeshBytes: c.end - c.p
    };
    const valueCount = c.u32();
    const codec = valueCount ? c.u8() : null;
    element.triStrip.firstFaceDegreePacket = { valueCount, codec };
  }
  requireNative(equalBytes(bytes.subarray(sequence.end), new Uint8Array([1, 0, 0, 0, 0, 0])), "JT shape LOD: invalid segment tail");
  segment.meshCodec = "JT Int32CDP2 and dual-mesh topology not implemented";
}
function inspectStringProperties(bytes, sequence) {
  for (const element of sequence.values) {
    requireNative(element.typeId === STRING_PROPERTY && element.baseType === 5, "JT string property: unexpected element");
    const c = bodyCursor(bytes, element, "JT string property");
    c.expect(new Uint8Array([1, 0, 0, 0, 0, 64, 1, 0]));
    const count = c.count(2);
    element.value = nativeText(c.take(count * 2), "utf-16le");
    requireNative(c.p === c.end, "JT string property: trailing body bytes");
  }
}
async function readJT(buffer, { name = "", signal = null, onProgress = null } = {}) {
  checkCancelled(signal);
  const bytes = nativeBytes(buffer);
  if (!equalBytes(bytes.subarray(0, 8), PREFIX)) throw nativeError("NATIVE_UNSUPPORTED", "Not a JT Version header");
  const c = new NativeCursor(bytes, "JT header");
  const versionField = nativeText(c.take(80), "utf-8");
  requireNative(/^[\x09\x0a\x0d\x20-\x7e]+$/.test(versionField), "JT header: invalid version text");
  const match = /^Version (\d+)\.(\d+)\s/.exec(versionField);
  requireNative(match && Number(match[1]) <= 65535 && Number(match[2]) <= 65535, "JT header: invalid version numbers");
  const major = Number(match[1]), minor = Number(match[2]);
  if (major !== 9) throw nativeError("NATIVE_UNSUPPORTED", `JT ${major}.${minor}: only the JT 9 container layout is implemented`);
  const byteOrder = c.u8();
  if (byteOrder === 1) throw nativeError("NATIVE_UNSUPPORTED", "Big-endian JT is not implemented");
  requireNative(byteOrder === 0 && c.u32() === 0, "JT header: invalid byte order or reserved word");
  const tocOffset = c.u32();
  const sceneSegmentId = hexBytes(c.take(16));
  requireNative(tocOffset >= c.p && tocOffset <= bytes.length - 4, "JT: invalid TOC offset");
  const toc = new NativeCursor(bytes, "JT TOC", tocOffset);
  const count = toc.count(28);
  requireNative(count > 0, "JT: empty TOC");
  const result = nativeResult("jt", name);
  result.header = { major, minor, versionField, byteOrder, tocOffset, sceneSegmentId };
  result.segments = [];
  const ids = /* @__PURE__ */ new Set();
  const tocEnd = toc.p + count * 28;
  for (let i = 0; i < count; i++) {
    checkCancelled(signal);
    const id = hexBytes(toc.take(16)), offset = toc.u32(), storedBytes = toc.u32(), type = toc.u32(false);
    requireNative(!ids.has(id), "JT: duplicate TOC segment ID");
    ids.add(id);
    requireNative(storedBytes >= 24 && offset >= 105 && offset <= bytes.length - storedBytes && (offset + storedBytes <= tocOffset || offset >= tocEnd), "JT: segment outside document or overlapping header/TOC");
    const header = new NativeCursor(bytes, "JT segment", offset, offset + storedBytes);
    requireNative(hexBytes(header.take(16)) === id && header.u32() === type && header.u32() === storedBytes, "JT: segment header disagrees with TOC");
    result.segments.push({ id, type, offset, storedBytes, decodedBytes: null, compressed: false, payloadOffset: header.p, payloadBytes: storedBytes - 24, elements: [] });
  }
  const sorted = [...result.segments].sort((a, b) => a.offset - b.offset);
  for (let i = 1; i < sorted.length; i++) requireNative(sorted[i - 1].offset + sorted[i - 1].storedBytes <= sorted[i].offset, "JT: overlapping segments");
  requireNative(result.segments.some((s) => s.id === sceneSegmentId && s.type === 1), "JT: missing logical scene segment");
  reportNativeProgress(onProgress, signal, "jt-segments", 0, count);
  for (let i = 0; i < count; i++) {
    const segment = result.segments[i];
    const payload = bytes.subarray(segment.payloadOffset, segment.offset + segment.storedBytes);
    let decoded = payload;
    if (payload.length >= 4 && new DataView(payload.buffer, payload.byteOffset, payload.byteLength).getUint32(0, true) === 2) {
      const envelope = new NativeCursor(payload, "JT compressed envelope");
      envelope.u32();
      const packedLength = envelope.u32();
      const algorithm = envelope.u8();
      requireNative(packedLength === payload.length - 8, "JT: compressed envelope length mismatch");
      segment.compressed = true;
      if (algorithm !== 2) {
        segment.unsupported = `Compression algorithm ${algorithm} remains opaque`;
        result.warnings.push(`JT segment ${segment.id}: compression algorithm ${algorithm} remains opaque`);
        reportNativeProgress(onProgress, signal, "jt-segments", i + 1, count);
        continue;
      }
      try {
        decoded = await inflateNativeZlib(payload.subarray(9), signal);
      } catch (error2) {
        if (error2.code !== "NATIVE_UNSUPPORTED") throw error2;
        segment.unsupported = error2.message;
        result.warnings.push(`JT segment ${segment.id}: ${error2.message}`);
        reportNativeProgress(onProgress, signal, "jt-segments", i + 1, count);
        continue;
      }
    }
    checkCancelled(signal);
    segment.decodedBytes = decoded.length;
    if ([1, 6, 7, 24, 31].includes(segment.type)) {
      const sequence = elements(decoded, 0, `JT segment type ${segment.type}`, signal);
      segment.elements = sequence.values;
      segment.tail = { offset: sequence.end, storedBytes: decoded.length - sequence.end };
      if (segment.type === 1) inspectScene(decoded, sequence, segment, result);
      if (segment.type === 7 || segment.type === 6) inspectShape(decoded, sequence, segment);
      if (segment.type === 31) inspectStringProperties(decoded, sequence);
    }
    reportNativeProgress(onProgress, signal, "jt-segments", i + 1, count);
  }
  result.streams = result.segments.map((s) => ({ name: `segment:${s.id}:type:${s.type}`, offset: s.offset, storedBytes: s.storedBytes, decodedBytes: s.decodedBytes }));
  result.coverage.container = true;
  result.warnings.push("JT inspection only: Int32CDP2 entropy/predictor codecs, dual-mesh reconstruction, shape-property bindings and effective transforms/materials are not implemented; no render meshes were produced.");
  result.warnings.push("JT hierarchy is partial: only partition child lists are interpreted; other node-family edges and attribute transforms remain opaque. Units are not inferred from property strings.");
  checkCancelled(signal);
  return result;
}

// src/native-nx.js
var textBytes = (s) => new TextEncoder().encode(s);
var MAGIC = textBytes("SPLMSSTR");
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
var NO_FOOTER = 281474976710655;
var controlFree = (s) => !/[\u0000-\u001f\u007f-\u009f]/u.test(s);
function directory(bytes, offset, end, marker, signal) {
  const c = new NativeCursor(bytes, `NX ${marker} directory`, offset, end);
  c.expect(textBytes(marker));
  const count = c.count(26);
  const entries = [];
  for (let i = 0; i < count; i++) {
    checkCancelled(signal);
    const recordOffset = c.p;
    const size = c.u32();
    requireNative(size >= 6 && size <= c.end - c.p - 16, "NX: invalid directory name length");
    const nameBytes = c.take(size);
    requireNative(nameBytes.every((v) => v >= 32 && v <= 126), "NX: non-ASCII directory path");
    const name = nativeText(nameBytes);
    requireNative(name.startsWith("/Root/"), "NX: directory path outside /Root/");
    const payload = c.take(16);
    const isStorage = name.endsWith("/");
    const value = new NativeCursor(payload, `NX directory payload ${name}`);
    entries.push({
      name,
      recordOffset,
      directory: marker,
      storage: isStorage,
      offset: isStorage ? null : value.u64(),
      storedBytes: isStorage ? null : value.u64(),
      opaque: isStorage ? hexBytes(payload) : null
    });
  }
  return { entries, end: c.p };
}
function container(bytes, signal) {
  if (!equalBytes(bytes.subarray(0, 8), MAGIC)) throw nativeError("NATIVE_UNSUPPORTED", "Not an NX SPLMSSTR container (legacy CFB is not implemented)");
  const h = new NativeCursor(bytes, "NX header", 8);
  const version = h.u8();
  if (version !== 6) throw nativeError("NATIVE_UNSUPPORTED", `NX SPLMSSTR version ${version} is not implemented`);
  h.take(3);
  requireNative(h.take(5).every((v) => v === 0), "NX: invalid header reserved bytes");
  const pointer = h.take(6);
  let footerOffset = 0;
  for (let i = 5; i >= 0; i--) footerOffset = footerOffset * 256 + pointer[i];
  h.take(2);
  const boundary = footerOffset === NO_FOOTER ? bytes.length : footerOffset;
  requireNative(boundary >= 35 && boundary <= bytes.length, "NX: footer pointer outside file");
  const head = directory(bytes, 25, boundary, "HEADER", signal);
  const foot = footerOffset === NO_FOOTER ? null : directory(bytes, footerOffset, bytes.length, "FOOTER", signal);
  if (foot) requireNative(foot.end === bytes.length - 4, "NX: footer must end with exactly one four-byte fingerprint");
  const entries = [...head.entries, ...foot?.entries || []];
  const names = /* @__PURE__ */ new Set();
  const streams = [];
  for (const entry of entries) {
    requireNative(!names.has(entry.name), `NX: duplicate directory path ${entry.name}`);
    names.add(entry.name);
    if (entry.storage) continue;
    requireNative(entry.storedBytes > 0 && entry.offset >= head.end && entry.offset <= boundary - entry.storedBytes, `NX: stream outside payload region: ${entry.name}`);
    streams.push({ name: entry.name, offset: entry.offset, storedBytes: entry.storedBytes, decodedBytes: null });
  }
  const ordered = [...streams].sort((a, b) => a.offset - b.offset);
  const gaps = [];
  let end = head.end;
  for (const stream of ordered) {
    requireNative(stream.offset >= end, `NX: overlapping stream ${stream.name}`);
    if (stream.offset > end) gaps.push({ offset: end, storedBytes: stream.offset - end });
    end = stream.offset + stream.storedBytes;
  }
  if (end < boundary) gaps.push({ offset: end, storedBytes: boundary - end });
  return {
    streams,
    version,
    footerOffset: foot ? footerOffset : null,
    fingerprint: foot ? hexBytes(bytes.subarray(foot.end)) : null,
    headerEnd: head.end,
    entries,
    gaps
  };
}
function byteCount(c) {
  c.expect(new Uint8Array([1]));
  const count = c.u8() - 1;
  requireNative(count >= 0, `${c.label}: invalid one-based count`);
  return count;
}
function framedStrings(c, tag, count) {
  const values = [];
  for (let i = 0; i < count; i++) {
    c.expect(new Uint8Array([tag]));
    const n = c.u8();
    requireNative(n >= 2, `${c.label}: invalid text length`);
    const value = nativeText(c.take(n - 2));
    c.expect(new Uint8Array([0]));
    requireNative(value.length > 0 && controlFree(value), `${c.label}: empty or control-containing text`);
    values.push(value);
  }
  return values;
}
function compactIndex(c) {
  const first = c.u8();
  if (first < 128) return first;
  if (first === 255) return null;
  if (first >= 128 && first <= 143) return first - 128 << 8 | c.u8();
  if (first === 144) return c.u16(false);
  requireNative(false, "NX roster: unknown compact reference");
}
function occurrenceLane(bytes, start) {
  const c = new NativeCursor(bytes, "NX occurrence roster", start);
  const count = byteCount(c);
  requireNative(count > 0, "NX roster: empty occurrence lane");
  const markerOffset = c.p;
  const markers = Array.from(c.take(count));
  requireNative(markers.every((v) => v === 49 || v === 57), "NX roster: unsupported occurrence marker");
  c.expect(new Uint8Array([1, 2]));
  const referencesOffset = c.p;
  const references = Array.from({ length: 4 }, () => compactIndex(c));
  const prototypes = framedStrings(c, 4, byteCount(c));
  requireNative(byteCount(c) === count, "NX roster: prototype-use count mismatch");
  const prototypeIndices = Array.from(c.take(count));
  requireNative(prototypeIndices.every((i) => i >= 1 && i <= prototypes.length), "NX roster: prototype index out of range");
  const uuids = framedStrings(c, 3, byteCount(c));
  requireNative(uuids.every((s) => UUID.test(s)), "NX roster: invalid UUID");
  requireNative(byteCount(c) === count, "NX roster: UUID-use count mismatch");
  const uuidIndices = Array.from(c.take(count));
  requireNative(uuidIndices.every((i) => i >= 1 && i <= uuids.length), "NX roster: UUID index out of range");
  return {
    offset: start,
    storedBytes: c.p - start,
    prototypes,
    uuids,
    referencesOffset,
    references,
    occurrences: markers.map((marker, i) => ({
      ordinal: i,
      marker,
      markerOffset: markerOffset + i,
      prototypeIndex: prototypeIndices[i],
      uuidIndex: uuidIndices[i]
    }))
  };
}
function structure(bytes, stream, result, signal) {
  const c = new NativeCursor(bytes, "NX FastLoad Structure");
  c.expect(new Uint8Array([255, 255, 255, 255, 0, 0, 0, 0]));
  requireNative(c.u32(false) === bytes.length - 12, "NX Structure: envelope length mismatch");
  c.expect(new Uint8Array([79, 77, 1, 1]));
  const candidates = [];
  for (let p = c.p; p <= bytes.length - 4; p++) {
    checkCancelled(signal);
    if (bytes[p] !== 1 || bytes[p + 1] < 2 || ![49, 57].includes(bytes[p + 2])) continue;
    try {
      candidates.push(occurrenceLane(bytes, p));
    } catch (error2) {
      if (error2.code !== "NATIVE_MALFORMED") throw error2;
    }
  }
  requireNative(candidates.length <= 1, "NX Structure: ambiguous duplicate complete rosters");
  if (!candidates.length) {
    result.warnings.push("NX FastLoad Structure has no supported complete occurrence roster; absent/unknown/invalid roster data was not turned into components.");
    return;
  }
  const roster = candidates[0];
  result.roster = { ...roster, streamName: stream.name, streamOffset: stream.offset };
  result.components = roster.occurrences.map((o) => ({
    id: `nx-occurrence:${o.ordinal}`,
    name: roster.prototypes[o.prototypeIndex - 1],
    sourcePath: null,
    parentId: null,
    transform: null
  }));
  result.coverage.structure = true;
  result.warnings.push("NX occurrence order and repeated prototypes are retained. Hierarchy, placement, units, and joins to external references are unresolved; no identity matrices or guessed source paths were assigned.");
}
function stringTable(bytes, start) {
  const c = new NativeCursor(bytes, "NX external string table", start);
  c.expect(new Uint8Array([1]));
  const count = c.count(3);
  requireNative(count > 0, "NX external string table: empty candidate");
  const strings = [];
  for (let i = 0; i < count; i++) {
    const length = c.u16();
    requireNative(length > 0, "NX external string table: empty string");
    const offset = c.p;
    const value = nativeText(c.take(length));
    requireNative(controlFree(value), "NX external string table: control byte");
    strings.push({ ordinal: i, offset, value });
  }
  requireNative(c.p === c.end, "NX external string table: trailing bytes");
  return { offset: start, strings };
}
function externalReferences(bytes, stream, result, signal) {
  const c = new NativeCursor(bytes, "NX EXTREFSTREAM");
  c.expect(textBytes("EXTREFSTREAM"));
  const version = c.u32();
  if (version !== 3) throw nativeError("NATIVE_UNSUPPORTED", `EXTREFSTREAM version ${version} remains opaque`);
  const nominalPayloadSize = c.u32();
  requireNative(nominalPayloadSize <= bytes.length - 16, "NX EXTREFSTREAM: nominal payload exceeds stream");
  c.take(4);
  c.expect(new Uint8Array([0]));
  const records = [];
  const ids = /* @__PURE__ */ new Set();
  let firstRecord = bytes.length;
  for (; ; ) {
    checkCancelled(signal);
    requireNative(c.p + 4 <= firstRecord, "NX EXTREFSTREAM: directory overlaps records");
    const id = c.u32();
    if (!id) break;
    requireNative(!ids.has(id), "NX EXTREFSTREAM: duplicate record ID");
    ids.add(id);
    requireNative(c.p + 4 <= firstRecord, "NX EXTREFSTREAM: truncated directory pair");
    const offset = c.u32();
    requireNative(offset < bytes.length && (!records.length || offset > records.at(-1).offset), "NX EXTREFSTREAM: nonincreasing record offsets");
    firstRecord = Math.min(firstRecord, offset);
    records.push({ id, offset });
  }
  requireNative(c.p <= firstRecord, "NX EXTREFSTREAM: directory exceeds first record");
  const tables = [];
  for (let p = records.length ? records.at(-1).offset + 6 : c.p; p <= bytes.length - 8; p++) {
    checkCancelled(signal);
    if (bytes[p] !== 1) continue;
    try {
      tables.push(stringTable(bytes, p));
    } catch (error2) {
      if (error2.code !== "NATIVE_MALFORMED") throw error2;
    }
  }
  requireNative(tables.length === 1, "NX EXTREFSTREAM: missing or ambiguous complete string table");
  const table = tables[0];
  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    const end = records[i + 1]?.offset ?? table.offset;
    requireNative(end > record.offset, "NX EXTREFSTREAM: invalid record boundary");
    record.storedBytes = end - record.offset;
    const r = new NativeCursor(bytes, "NX external record", record.offset, end);
    const raw = bytes.subarray(record.offset, end);
    if (equalBytes(raw, new Uint8Array([1, 0, 0, 0, 0, 1])) || equalBytes(raw, new Uint8Array([1, 0, 0, 0, 0, 1, 1]))) {
      record.kind = "empty";
      continue;
    }
    record.kind = "opaque";
    if (raw.length < 25 || !equalBytes(raw.subarray(0, 4), new Uint8Array([1, 0, 0, 0])) || raw[6] !== 1 || raw[23] !== 1) continue;
    r.take(4);
    record.declaredN = r.u16(false);
    r.u8();
    const slots = Array.from({ length: 4 }, () => r.u32());
    r.u8();
    const count = r.u8();
    if (count < 1 || (count - 1) * 5 + 1 > r.end - r.p) continue;
    const handles = [];
    let valid = true;
    for (let j = 0; j < count - 1; j++) {
      if (r.u8() !== 224) valid = false;
      const handle = r.u32(false);
      if (handles.length && handle < handles.at(-1)) valid = false;
      handles.push(handle);
    }
    if (r.u8() !== count || !valid) continue;
    const closingDuplicate = handles.length > 1 && handles.at(-1) === handles.at(-2);
    if (closingDuplicate) handles.pop();
    Object.assign(record, { kind: "handle-set", slots, handles, closingDuplicate, tailOffset: r.p, tailBytes: r.end - r.p });
    if (!slots.every((slot) => slot < table.strings.length)) {
      result.warnings.push(`NX external record ${record.id}: out-of-range string slot, no reference binding`);
      continue;
    }
    const [child, referenceCode, directory2, loadMode] = slots.map((slot) => table.strings[slot].value);
    if (!/\.prt$/i.test(child)) continue;
    const separator = directory2.includes("\\") ? "\\" : "/";
    const sourcePath = directory2 ? directory2 + (/[\\/]$/.test(directory2) ? "" : separator) + child : child;
    result.references.push({
      id: `${stream.name}:${record.id}`,
      streamName: stream.name,
      recordId: record.id,
      offset: stream.offset + record.offset,
      storedBytes: record.storedBytes,
      name: child,
      directory: directory2,
      sourcePath,
      referenceCode,
      loadMode,
      slots,
      handles
    });
  }
  result.externalReferenceStreams.push({ streamName: stream.name, nominalPayloadSize, records, stringTable: table });
}
async function embeddedJT(bytes, stream, result, signal) {
  const c = new NativeCursor(bytes, "NX JT index");
  const version = c.u32();
  if (version !== 9) throw nativeError("NATIVE_UNSUPPORTED", `NX JT index version ${version} remains opaque`);
  const count = c.count(16);
  requireNative(count > 0, "NX JT index: empty row table");
  const end = c.p + count * 16;
  const rows = [];
  const fastLoad = stream.name === "/Root/FastLoad/JT";
  for (let i = 0; i < count; i++) {
    const rowOffset = c.p;
    const valueHigh = c.u32(), valueLow = c.u32(), offsetHigh = c.u32(), offset = c.u32();
    requireNative(valueHigh !== 0 || valueLow !== 0, "NX JT index: zero row value");
    requireNative(offsetHigh === 0 && offset >= end && offset <= bytes.length - 105, "NX JT index: invalid document offset");
    requireNative(!rows.length || (fastLoad ? offset >= rows.at(-1).offset : offset > rows.at(-1).offset), "NX JT index: duplicate or nonmonotone document offsets");
    requireNative(equalBytes(bytes.subarray(offset, offset + 8), textBytes("Version ")), "NX JT index: target is not a JT header");
    rows.push({ ordinal: i, rowOffset, value: (BigInt(valueHigh) << 32n | BigInt(valueLow)).toString(), offset });
  }
  const groups2 = [];
  for (const row of rows) {
    if (groups2.at(-1)?.offset === row.offset) groups2.at(-1).indexRows.push(row);
    else groups2.push({ offset: row.offset, indexRows: [row] });
  }
  for (let i = 0; i < groups2.length; i++) {
    const group = groups2[i];
    const end2 = groups2[i + 1]?.offset ?? bytes.length;
    const document = { streamName: stream.name, offset: stream.offset + group.offset, storedBytes: end2 - group.offset, indexRows: group.indexRows, inspection: null };
    try {
      document.inspection = await readJT(bytes.subarray(group.offset, end2), { name: `${stream.name}#JT[${i}]`, signal });
    } catch (error2) {
      if (error2.code !== "NATIVE_UNSUPPORTED") throw error2;
      document.unsupported = error2.message;
      result.warnings.push(`${stream.name}: ${error2.message}`);
    }
    result.jtDocuments.push(document);
  }
}
async function readNX(buffer, { name = "", signal = null, onProgress = null } = {}) {
  checkCancelled(signal);
  const bytes = nativeBytes(buffer);
  const parsed = container(bytes, signal);
  const result = nativeResult("nx", name);
  result.streams = parsed.streams;
  result.container = { ...parsed };
  delete result.container.streams;
  result.roster = null;
  result.references = [];
  result.externalReferenceStreams = [];
  result.jtDocuments = [];
  result.coverage.container = true;
  reportNativeProgress(onProgress, signal, "nx-streams", 0, result.streams.length);
  for (let i = 0; i < result.streams.length; i++) {
    const stream = result.streams[i];
    const payload = bytes.subarray(stream.offset, stream.offset + stream.storedBytes);
    try {
      if (stream.name === "/Root/FastLoad/Structure") {
        structure(payload, stream, result, signal);
        stream.decodedBytes = payload.length;
      } else if (stream.name === "/Root/FastLoad/ExternalReferences" || stream.name === "/Root/UG_PART/ExternalReferences") {
        externalReferences(payload, stream, result, signal);
        stream.decodedBytes = payload.length;
      } else if (stream.name === "/Root/FastLoad/JT" || stream.name === "/Root/UG_PART/DisplayJT") await embeddedJT(payload, stream, result, signal);
    } catch (error2) {
      if (error2.code !== "NATIVE_UNSUPPORTED") throw error2;
      result.warnings.push(`${stream.name}: ${error2.message}`);
    }
    reportNativeProgress(onProgress, signal, "nx-streams", i + 1, result.streams.length);
  }
  result.warnings.push("NX metadata/occurrence inspection only. Parasolid bodies, OM placement ownership, and JT mesh codecs are not implemented; no render meshes were produced.");
  if (result.jtDocuments.length) result.warnings.push("Embedded JT documents are inspected separately, not bound to NX component occurrences. See jtDocuments for TOC, zlib, shape-header and partial scene-graph evidence.");
  if (result.references.length) result.warnings.push("External reference paths are inert source metadata and may include this part itself. No files were fetched or matched to occurrences.");
  checkCancelled(signal);
  return result;
}

// src/native-solidworks-cfb.js
var FREE = 4294967295;
var END = 4294967294;
var FAT = 4294967293;
var DIF = 4294967292;
var MAGIC2 = Uint8Array.of(208, 207, 17, 224, 161, 177, 26, 225);
var ZLB = Uint8Array.of(35, 29, 213, 113, 218, 129, 72, 162, 168, 88, 152, 178, 27, 137, 239, 153);
var issue = (code, message) => Object.assign(new Error(message), { name: "NativeSolidWorksError", code });
var bad = (message) => {
  throw issue("NATIVE_MALFORMED", message);
};
var unsupported = (message) => {
  throw issue("NATIVE_UNSUPPORTED", message);
};
var need = (ok, message) => {
  if (!ok) bad(message);
};
var equal = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
var isCFB = (bytes) => bytes.length >= 8 && equal(bytes.subarray(0, 8), MAGIC2);
function control({ signal, onProgress } = {}) {
  let steps = 0;
  const check = () => {
    if (signal?.aborted) throw issue("IMPORT_CANCELLED", "SolidWorks import cancelled.");
  };
  const progress = (stage, completed, total, streamName = null) => {
    check();
    onProgress?.({ stage, completed, total, streamName });
    check();
  };
  return { signal, check, progress, async tick() {
    check();
    if ((++steps & 255) === 0) {
      await new Promise((r) => setTimeout(r, 0));
      check();
    }
  } };
}
function budget(usage, limits, field, n, limit2) {
  const total = (usage[field] ?? 0) + n;
  usage[field] = total;
  if (!Number.isSafeInteger(total) || total > (limits[limit2] ?? Infinity)) throw issue("NATIVE_AUDIT_LIMIT", `SolidWorks CFB ${field} byte/count budget exceeded (${limit2}).`);
}
function compare(a, b) {
  const x = a.toUpperCase(), y = b.toUpperCase();
  return a.length - b.length || (x < y ? -1 : x > y ? 1 : 0);
}
async function readCFBDirectory(bytes, { signal = null, onProgress = null, limits = {}, usage = {} } = {}) {
  const ctx = control({ signal, onProgress });
  ctx.check();
  need(bytes instanceof Uint8Array && bytes.length >= 512 && isCFB(bytes), "Invalid or truncated CFB header.");
  if (bytes.length > (limits.fileBytes ?? Infinity)) throw issue("NATIVE_AUDIT_LIMIT", "SolidWorks CFB input byte budget exceeded.");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), u16 = (o) => view.getUint16(o, true), u32 = (o) => view.getUint32(o, true);
  need(bytes.subarray(8, 24).every((b) => b === 0) && bytes.subarray(34, 40).every((b) => b === 0), "Invalid reserved CFB header fields.");
  if (u16(26) !== 3) unsupported("Only the qualified CFB major-version 3 metadata container is supported.");
  need(u16(24) === 62 && u16(28) === 65534 && u16(30) === 9 && u16(32) === 6 && u32(40) === 0 && u32(56) === 4096 && bytes.length % 512 === 0, "Invalid CFB-v3 header/sector pairing or alignment.");
  const count = bytes.length / 512 - 1, owners = /* @__PURE__ */ new Map(), miniOwners = /* @__PURE__ */ new Map();
  const valid = (i) => Number.isInteger(i) && i >= 0 && i < count;
  const sector = (i) => {
    need(valid(i), "CFB sector index is outside the physical input.");
    return (i + 1) * 512;
  };
  function claim(i, owner) {
    sector(i);
    need(!owners.has(i), "Overlapping or cyclic CFB physical-sector allocation.");
    owners.set(i, owner);
  }
  const nf = u32(44), nd = u32(72), nm = u32(64);
  need(nf > 0 && nf <= count && nd <= count && nm <= count, "CFB allocation counts exceed physical extents.");
  const fatIds = [], difIds = [];
  let freeSlot = false;
  function fatSlot(id) {
    if (id === FREE) {
      freeSlot = true;
      return;
    }
    need(!freeSlot && fatIds.length < nf, "Noncanonical or excessive CFB DIFAT entries.");
    claim(id, "FAT");
    fatIds.push(id);
  }
  for (let i = 0; i < 109; i++) {
    fatSlot(u32(76 + i * 4));
    await ctx.tick();
  }
  let next = u32(68);
  need(nd === Math.ceil(Math.max(0, nf - 109) / 127), "CFB DIFAT count does not match FAT roster extent.");
  for (let j = 0; j < nd; j++) {
    claim(next, "DIFAT");
    difIds.push(next);
    const at = sector(next);
    for (let i = 0; i < 127; i++) {
      fatSlot(u32(at + i * 4));
      await ctx.tick();
    }
    next = u32(at + 508);
  }
  need(next === END && fatIds.length === nf && nf * 128 >= count, "Invalid CFB DIFAT termination, FAT count or coverage.");
  const fat = (i) => {
    need(Number.isInteger(i) && i >= 0 && i < nf * 128, "CFB FAT lookup exceeds its indexed extent.");
    return u32(sector(fatIds[Math.floor(i / 128)]) + i % 128 * 4);
  };
  for (const i of fatIds) need(fat(i) === FAT, "CFB FAT sector has no FAT marker.");
  for (const i of difIds) need(fat(i) === DIF, "CFB DIFAT sector has no DIFAT marker.");
  for (let i = 0; i < nf * 128; i++) {
    const v = fat(i);
    need(i < count ? v === FREE || v === END || v === FAT || v === DIF || valid(v) : v === FREE, "Invalid CFB FAT entry or non-FREE table padding.");
    await ctx.tick();
  }
  async function chain(start, table, extent, owner, size = null, mini = false) {
    const unit = mini ? 64 : 512, expected = size == null ? null : Math.ceil(size / unit), seq = [];
    need(expected == null || expected <= extent, "CFB declared stream size exceeds allocation extent.");
    let at = start;
    while (at !== END) {
      need(Number.isInteger(at) && at >= 0 && at < extent && (expected == null || seq.length < expected), "Invalid CFB chain index, marker or exact length.");
      const ledger = mini ? miniOwners : owners;
      need(!ledger.has(at), "Overlapping or cyclic CFB stream chain.");
      ledger.set(at, owner);
      seq.push(at);
      at = table(at);
      await ctx.tick();
    }
    need(expected == null || seq.length === expected, "Truncated CFB chain or declared-size disagreement.");
    return seq;
  }
  const ds = await chain(u32(48), fat, count, "directory");
  need(ds.length > 0, "Missing CFB directory.");
  const entries = [], slots = ds.length * 4;
  let live = 0;
  ctx.progress("cfb-directory", 0, slots);
  for (let id = 0; id < slots; id++) {
    const at = sector(ds[Math.floor(id / 4)]) + id % 4 * 128, type = bytes[at + 66];
    if (type === 0) {
      entries.push(null);
      await ctx.tick();
      continue;
    }
    need([1, 2, 5].includes(type), "Invalid live CFB directory entry type.");
    if (++live > (limits.edges ?? Infinity)) throw issue("NATIVE_AUDIT_LIMIT", "SolidWorks CFB directory-entry budget exceeded.");
    const length = u16(at + 64);
    need(length >= 4 && length <= 64 && length % 2 === 0 && u16(at + length - 2) === 0, "Invalid CFB name length or terminator.");
    let name = "";
    for (let i = 0; i < length - 2; i += 2) {
      const c = u16(at + i);
      need(c !== 0 && !["/", "\\", ":", "!"].includes(String.fromCharCode(c)), "Invalid CFB directory name.");
      if (c > 127) unsupported("CFB names outside the qualified ASCII invariant-comparison profile are unsupported.");
      name += String.fromCharCode(c);
    }
    const e = { directoryId: id, physicalName: name, type, color: bytes[at + 67], left: u32(at + 68), right: u32(at + 72), child: u32(at + 76), start: u32(at + 116), storedBytes: u32(at + 120) };
    need(e.color === 0 || e.color === 1, "Invalid CFB red-black tree color.");
    need(u32(at + 124) === 0, "Invalid CFB-v3 high stream size.");
    if (type === 1) need(e.storedBytes === 0 && e.start === 0, "CFB storage has a stream size/start allocation.");
    if (type === 2) need(e.child === FREE, "CFB stream has a child directory.");
    entries.push(e);
    await ctx.tick();
  }
  const root = entries[0];
  need(root?.type === 5 && root.physicalName === "Root Entry" && root.left === FREE && root.right === FREE && entries.filter((e) => e?.type === 5).length === 1, "Invalid or ambiguous CFB root directory.");
  const reached = /* @__PURE__ */ new Set([0]), storages = [], streams = [], pending = [{ id: 0, name: "", depth: 0 }];
  while (pending.length) {
    const parent = pending.pop(), storage = entries[parent.id];
    if (parent.depth > (limits.depth ?? Infinity)) throw issue("NATIVE_AUDIT_LIMIT", "SolidWorks CFB storage-depth budget exceeded.");
    if (storage.child === FREE) continue;
    const start = entries[storage.child];
    need(start && start.color === 1, "CFB sibling-tree root is absent or not black.");
    const work = [{ id: storage.child, low: null, high: null, red: false, exit: false }];
    while (work.length) {
      const item = work.pop();
      await ctx.tick();
      if (item.id === FREE) continue;
      need(item.id > 0 && item.id < entries.length && entries[item.id], "CFB directory pointer targets an absent entry.");
      const e = entries[item.id];
      need(!reached.has(item.id) && e.type !== 5, "Cycle, alias or repeated root in CFB directory.");
      reached.add(item.id);
      need((item.low === null || compare(e.physicalName, item.low) > 0) && (item.high === null || compare(e.physicalName, item.high) < 0), "Unordered or case-equivalent duplicate CFB sibling name.");
      need(!item.red || e.color === 1, "CFB red node has a red child.");
      e.name = parent.name ? `${parent.name}/${e.physicalName}` : e.physicalName;
      e.parentId = parent.id;
      if (e.type === 1) {
        storages.push(e);
        pending.push({ id: item.id, name: e.name, depth: parent.depth + 1 });
      } else streams.push(e);
      work.push({ id: e.right, low: e.physicalName, high: item.high, red: e.color === 0 }, { id: e.left, low: item.low, high: e.physicalName, red: e.color === 0 });
    }
  }
  need(reached.size === live, "Unreachable live CFB directory entry (orphan); no flattening is permitted.");
  const rootSeq = await chain(root.start, fat, count, "mini-stream", root.storedBytes);
  need(root.storedBytes % 64 === 0, "CFB root mini-stream is not mini-sector aligned.");
  const miniSeq = await chain(u32(60), fat, count, "miniFAT", nm * 512), miniCount = root.storedBytes / 64;
  need(miniSeq.length * 128 >= miniCount, "CFB miniFAT cannot cover the root mini-stream.");
  const miniFat = (i) => {
    need(i >= 0 && i < miniSeq.length * 128, "CFB miniFAT lookup exceeds its indexed extent.");
    return u32(sector(miniSeq[Math.floor(i / 128)]) + i % 128 * 4);
  };
  for (let i = 0; i < miniSeq.length * 128; i++) {
    const v = miniFat(i);
    need(i < miniCount ? v === FREE || v === END || v < miniCount : v === FREE, "Invalid CFB miniFAT entry or padding.");
    await ctx.tick();
  }
  streams.sort((a, b) => a.directoryId - b.directoryId);
  storages.sort((a, b) => a.directoryId - b.directoryId);
  const indexed2 = /* @__PURE__ */ new Map();
  for (const e of streams) {
    ctx.check();
    e.allocation = e.storedBytes === 0 ? "none" : e.storedBytes < 4096 ? "miniFAT" : "FAT";
    e.sectors = await chain(e.start, e.allocation === "miniFAT" ? miniFat : fat, e.allocation === "miniFAT" ? miniCount : count, e.directoryId, e.storedBytes, e.allocation === "miniFAT");
    indexed2.set(e.directoryId, e);
  }
  for (let i = 0; i < count; i++) {
    need(owners.has(i) || fat(i) === FREE, "Allocated CFB physical sector has no live owner.");
    await ctx.tick();
  }
  for (let i = 0; i < miniCount; i++) {
    need(miniOwners.has(i) || miniFat(i) === FREE, "Allocated CFB mini-sector has no live owner.");
    await ctx.tick();
  }
  ctx.progress("cfb-directory", live, live);
  return {
    kind: "cfb",
    major: 3,
    minor: u16(24),
    sectorBytes: 512,
    miniSectorBytes: 64,
    liveEntries: live,
    storages,
    entries: streams,
    allocation: { physicalClaimed: owners.size, miniClaimed: miniOwners.size },
    async read(entry) {
      ctx.check();
      need(indexed2.get(entry.directoryId) === entry, "CFB stream read is not backed by the validated directory.");
      budget(usage, limits, "metadataBytes", entry.storedBytes, "xmlBytes");
      budget(usage, {}, "rawBytes", entry.storedBytes, "xmlBytes");
      const out = new Uint8Array(entry.storedBytes);
      let p = 0;
      ctx.progress("cfb-read", 0, out.length, entry.name);
      for (const id of entry.sectors) {
        const mini = entry.allocation === "miniFAT", offset = mini ? sector(rootSeq[Math.floor(id * 64 / 512)]) + id * 64 % 512 : sector(id), n = Math.min(mini ? 64 : 512, out.length - p);
        out.set(bytes.subarray(offset, offset + n), p);
        p += n;
        await ctx.tick();
      }
      need(p === out.length, "CFB read size disagreement.");
      ctx.progress("cfb-read", p, p, entry.name);
      return out;
    }
  };
}
async function inflateCFBZLB(raw, { signal = null, onProgress = null, limits = {}, usage = {}, name = "" } = {}) {
  const ctx = control({ signal, onProgress });
  ctx.check();
  need(raw.length >= 24 && equal(raw.subarray(0, 16), ZLB), "Invalid SolidWorks ZLB GUID or extent.");
  const view = new DataView(raw.buffer, raw.byteOffset, raw.byteLength), chunks = [];
  let p = 16, total = 0;
  while (p < raw.length - 8) {
    need(p + 8 <= raw.length - 8, "Truncated SolidWorks ZLB chunk header.");
    const decoded = view.getUint32(p, true), packed = view.getUint32(p + 4, true);
    p += 8;
    need(decoded > 0 && packed > 0 && packed <= raw.length - 8 - p, "Invalid SolidWorks ZLB chunk lengths.");
    budget(usage, limits, "metadataBytes", decoded, "xmlBytes");
    budget(usage, limits, "decodedBytes", decoded, "inflatedBytes");
    total += decoded;
    chunks.push({ offset: p, packed, decoded });
    p += packed;
    await ctx.tick();
  }
  need(p === raw.length - 8 && raw.subarray(p).every((b) => b === 0), "Invalid SolidWorks ZLB exact eight-zero trailer.");
  if (typeof DecompressionStream === "undefined") unsupported("This runtime lacks DecompressionStream(deflate) for CFB ZLB metadata.");
  const out = new Uint8Array(total);
  let written = 0;
  for (const chunk of chunks) {
    let decoder;
    try {
      decoder = new DecompressionStream("deflate");
    } catch {
      unsupported("This runtime does not implement zlib/deflate decompression.");
    }
    const source = new ReadableStream({ start(c) {
      c.enqueue(raw.subarray(chunk.offset, chunk.offset + chunk.packed));
      c.close();
    } }), reader = source.pipeThrough(decoder).getReader();
    const cancel = () => {
      reader.cancel().catch(() => {
      });
    };
    signal?.addEventListener("abort", cancel, { once: true });
    let size = 0;
    try {
      while (true) {
        ctx.check();
        const { done, value } = await reader.read();
        ctx.check();
        if (done) break;
        size += value.length;
        need(size <= chunk.decoded, "SolidWorks ZLB output exceeds declared chunk size.");
        out.set(value, written);
        written += value.length;
        ctx.progress("cfb-decompress", written, total, name);
        await ctx.tick();
      }
      need(size === chunk.decoded, "SolidWorks ZLB decoded chunk size mismatch.");
    } catch (e) {
      await reader.cancel().catch(() => {
      });
      ctx.check();
      if (["NATIVE_MALFORMED", "NATIVE_UNSUPPORTED", "NATIVE_AUDIT_LIMIT", "IMPORT_CANCELLED"].includes(e.code)) throw e;
      bad("Invalid SolidWorks ZLB zlib stream, checksum or exact consumption.");
    } finally {
      signal?.removeEventListener("abort", cancel);
      reader.releaseLock();
    }
  }
  return out;
}

// src/native-solidworks-2800-dcl.js
var issue2 = (code, message) => Object.assign(new Error(message), { name: "NativeSolidWorksError", code });
var need2 = (ok, message) => {
  if (!ok) throw issue2("NATIVE_MALFORMED", `SolidWorks __Zip DCL: ${message}`);
};
function codes(repeats) {
  const lengths = repeats.flatMap((n) => Array((n >>> 4) + 1).fill(n & 15)), out = Array.from({ length: 14 }, () => /* @__PURE__ */ new Map());
  let next = 0;
  for (let width = 1; width <= 13; width++) {
    for (let symbol2 = 0; symbol2 < lengths.length; symbol2++) if (lengths[symbol2] === width) out[width].set(next++, symbol2);
    next *= 2;
  }
  return out;
}
var LITERAL = codes([11, 124, 8, 7, 28, 7, 188, 13, 76, 4, 10, 8, 12, 10, 12, 10, 8, 23, 8, 9, 7, 6, 7, 8, 7, 6, 55, 8, 23, 24, 12, 11, 7, 9, 11, 12, 6, 7, 22, 5, 7, 24, 6, 11, 9, 6, 7, 22, 7, 11, 38, 7, 9, 8, 25, 11, 8, 11, 9, 12, 8, 12, 5, 38, 5, 38, 5, 11, 7, 5, 6, 21, 6, 10, 53, 8, 7, 24, 10, 27, 44, 253, 253, 253, 252, 252, 252, 13, 12, 45, 12, 45, 12, 61, 12, 45, 44, 173]);
var LENGTH = codes([2, 35, 36, 53, 38, 23]);
var DISTANCE = codes([2, 20, 53, 230, 247, 151, 248]);
var BASE = [3, 2, 4, 5, 6, 7, 8, 9, 10, 12, 16, 24, 40, 72, 136, 264];
var EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8];
async function monitoredOutput(chunks) {
  if (typeof DecompressionStream === "undefined") throw issue2("NATIVE_UNSUPPORTED", "This runtime lacks the native decompression accounting boundary.");
  const blocks = chunks.length ? chunks : [new Uint8Array(0)];
  let decoder;
  try {
    decoder = new DecompressionStream("deflate-raw");
  } catch {
    throw issue2("NATIVE_UNSUPPORTED", "This runtime lacks raw DEFLATE for native decompression accounting.");
  }
  const source = new ReadableStream({ start(c) {
    for (let i = 0; i < blocks.length; i++) {
      const block = blocks[i], h = new Uint8Array(5), v = new DataView(h.buffer);
      h[0] = i === blocks.length - 1 ? 1 : 0;
      v.setUint16(1, block.length, true);
      v.setUint16(3, block.length ^ 65535, true);
      c.enqueue(h);
      if (block.length) c.enqueue(block);
    }
    c.close();
  } }), reader = source.pipeThrough(decoder).getReader(), out = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      out.push(value);
      total += value.length;
    }
  } catch (e) {
    await reader.cancel().catch(() => {
    });
    throw e;
  } finally {
    reader.releaseLock();
  }
  const result = new Uint8Array(total);
  let p = 0;
  for (const b of out) {
    result.set(b, p);
    p += b.length;
  }
  return result;
}
async function inflate2800Zip(raw, { signal = null, onProgress = null, limits = {}, usage = {}, name = "" } = {}) {
  const check = () => {
    if (signal?.aborted) throw issue2("IMPORT_CANCELLED", "SolidWorks import cancelled.");
  };
  check();
  need2(raw instanceof Uint8Array && raw.length >= 4, "truncated header");
  need2(raw[0] === 0 || raw[0] === 1, "literal coding must be 0 or 1");
  need2([4, 5, 6].includes(raw[1]), "invalid dictionary bits");
  let bit = 16, total = 0, steps = 0;
  const chunks = [], window = new Uint8Array(4096);
  let pending = [];
  const bits = (n) => {
    need2(bit + n <= raw.length * 8, "truncated code/end marker");
    let value = 0;
    for (let i = 0; i < n; i++, bit++) value |= (raw[bit >>> 3] >>> (bit & 7) & 1) << i;
    return value;
  };
  const symbol2 = (table) => {
    let value = 0;
    for (let width = 1; width <= 13; width++) {
      value = value * 2 + (bits(1) ^ 1);
      if (table[width].has(value)) return table[width].get(value);
    }
    need2(false, "invalid Huffman code");
  };
  const emit = (value) => {
    for (const [field, limit2] of [["metadataBytes", "xmlBytes"], ["decodedBytes", "inflatedBytes"], ["zipInflatedBytes", "inflatedBytes"]]) {
      const n = (usage[field] ?? 0) + 1;
      usage[field] = n;
      if (!Number.isSafeInteger(n) || n > (limits[limit2] ?? Infinity)) throw issue2("NATIVE_AUDIT_LIMIT", `SolidWorks __Zip ${field} budget exceeded (${limit2}).`);
    }
    window[total & 4095] = value;
    total++;
    pending.push(value);
    if (pending.length === 4096) {
      chunks.push(Uint8Array.from(pending));
      pending = [];
    }
  };
  try {
    while (true) {
      check();
      if (bits(1) === 0) emit(raw[0] ? symbol2(LITERAL) : bits(8));
      else {
        const code = symbol2(LENGTH), length = BASE[code] + bits(EXTRA[code]);
        if (length === 519) break;
        const width = length === 2 ? 2 : raw[1], distance = (symbol2(DISTANCE) << width) + bits(width) + 1;
        need2(distance <= total && distance <= 4096, "copy precedes output");
        for (let i = 0; i < length; i++) emit(window[total - distance & 4095]);
      }
      if ((++steps & 255) === 0) {
        onProgress?.({ stage: "cfb-dcl-decompress", completed: total, total: null, streamName: name });
        await new Promise((r) => setTimeout(r, 0));
        check();
      }
    }
    need2(Math.ceil(bit / 8) === raw.length, "unconsumed trailing input");
    need2(raw[raw.length - 1] >>> (bit & 7 || 8) === 0, "nonzero end padding");
  } catch (e) {
    if (pending.length) chunks.push(Uint8Array.from(pending));
    await monitoredOutput(chunks);
    throw e;
  }
  if (pending.length) chunks.push(Uint8Array.from(pending));
  const out = await monitoredOutput(chunks);
  need2(out.length === total, "accounted output size disagreement");
  check();
  return out;
}

// src/native-solidworks-2800.js
var problem = (code, message) => Object.assign(new Error(`SolidWorks 2800: ${message}`), { name: "NativeSolidWorksError", code });
var need3 = (ok, message) => {
  if (!ok) throw problem("NATIVE_UNSUPPORTED", message);
};
var malformed2 = (ok, message) => {
  if (!ok) throw problem("NATIVE_MALFORMED", message);
};
var utf16 = new TextDecoder("utf-16le", { fatal: true });
var ascii = new TextDecoder("utf-8", { fatal: true });
function scope2800(directory2) {
  const carrier = /* @__PURE__ */ new Map([["ModelStamps", "ModelStamps"], ["Header2", "Header2"], ["Contents/Definition", "Contents/Definition"], ["Contents/CMgrHdr2", "Contents/CMgrHdr2"], ["Contents/CMgr", "Contents/CMgr"], ["Contents/OleItems", "Contents/OleItems"], ["ISolidWorksInformation", "ISolidWorksInformation"]]);
  const assembly = directory2.entries.some((e) => e.name === "swXmlContents/COMPINSTANCETREE__Zip");
  if (assembly) carrier.set("swXmlContents/COMPINSTANCETREE__Zip", "swXmlContents/COMPINSTANCETREE");
  const scopes = /* @__PURE__ */ new Set(["Contents", "swXmlContents", "_MO_VERSION_2800", "_DL_VERSION_2800", "ThirdPty", "ThirdPtyStore"]);
  need3(directory2.storages.every((e) => scopes.has(e.name)), "unqualified storage/member scope (including embedded OLE, imported or virtual sources)");
  need3(["_MO_VERSION_2800", "_DL_VERSION_2800"].every((n) => directory2.storages.some((e) => e.name === n)), "both exact 2800 version storages are required");
  const opaque = /^(?:Preview|\x05SummaryInformation|\x05DocumentSummaryInformation|_MO_VERSION_2800\/(?:Biography|History)|_DL_VERSION_2800\/DLUpdateStamp|ThirdPty\/(?:CimSwBrowserAssembly|CimSwBrowserPart|PBPDFlt|SWA_Schedules|HWDATA|MOLDFLOWXpress|SWWebPublisherPart)|Contents\/(?:DisplayLists__Zip|Printing|Config-(?:0|[1-9]\d*)(?:-Partition)?))$/;
  for (const e of directory2.entries) {
    need3(carrier.has(e.name) || opaque.test(e.name), "unknown, renamed or mixed-version semantic/reference carrier");
    if (e.name.startsWith("ThirdPty/")) need3(e.storedBytes === 0, "nonempty third-party source-bearing stream is unqualified");
  }
  for (const n of carrier.keys()) need3(directory2.entries.some((e) => e.name === n), `missing required typed carrier ${n}`);
  return carrier;
}
function reference2800Grammar(root, t) {
  const attrs = { swSolidWorks: ["swObjCount", "swVersion", ...Object.keys(root.attrs).filter((k) => k === "xmlns" || k.startsWith("xmlns:"))], swHeader: ["swObjCount"], swModelList: ["swObjCount"], swConfigurationList: ["swObjCount"], swFile: ["id", "swDocType", "swCreationTime", "swPath"], swModel: ["id", "swName", "swConfigurationName", "swConfigurationId", "swLastModifiedStamp", "swConfigurationFlags", "swFileRef", "swBoundingBox", "swAssemblyFeatureEffectedComponents"], swConfiguration: ["id", "swName", "swID", "swReference", "swMostRecentConfiguration", "swModelRef"], swReference: ["id", "swName", "swReferenceNumber", "swID", "swConfigurationId", "swConfigurationName", "swDisplayMode", "swHlrDisplayQuality", "swSuppressed", "swHidden", "swEdgesInShadedMode", "swFlexible", "swZone", "swModelRef", "swTransform", "swTransformStamp"] };
  const work = [root];
  while (work.length) {
    const n = work.pop();
    need3(attrs[n.name] && Object.keys(n.attrs).every((a) => attrs[n.name].includes(a)), `unknown XML2800 ${n.name} object/attribute`);
    work.push(...n.children);
  }
  for (const section of [root, ...root.children]) {
    const actual = section === root ? t.files.length + t.models.length + t.configurations.length + t.models.reduce((n, m) => n + m.references.length, 0) : section.children.length;
    malformed2(/^(?:0|[1-9]\d*)$/.test(section.attrs.swObjCount ?? "") && Number(section.attrs.swObjCount) === actual, "explicit XML2800 count is absent or contradictory");
  }
  need3(t.configurations.length === 1 && t.configurations[0].swMostRecentConfiguration === "YES", "only the observed single selected assembly XML2800 configuration is qualified");
  const files = new Map(t.files.map((f) => [f.id, f])), self = t.models.find((m) => m.id === t.configurations[0].swModelRef);
  need3(files.get(self.swFileRef).swDocType === "ASSEMBLY", "component-tree root must be an intrinsic ASSEMBLY");
  for (const f of t.files) need3(["PART", "ASSEMBLY"].includes(f.swDocType) && /^(?:0|[1-9]\d*)$/.test(f.swCreationTime ?? "") && typeof f.swPath === "string", "XML2800 file identity");
  for (const m of t.models) {
    need3(m === self || files.get(m.swFileRef).swDocType === "PART" && m.references.length === 0, "only flat physical PART occurrence models are qualified");
    need3(new Set(m.references.map((r) => r.swID)).size === m.references.length, "duplicate persistent local component identity");
    need3(["384", "389", "2176"].includes(m.swConfigurationFlags) && (m.swAssemblyFeatureEffectedComponents == null || m.swAssemblyFeatureEffectedComponents === ""), "unknown model flags or assembly feature effects");
    need3(typeof m.swConfigurationName === "string" && m.swConfigurationName && /^(?:0|[1-9]\d*)$/.test(m.swConfigurationId ?? "") && /^(?:0|[1-9]\d*)$/.test(m.swLastModifiedStamp ?? ""), "model configuration/save identity");
    for (const r of m.references) {
      const target = t.models.find((m2) => m2.id === r.swModelRef);
      need3(["NO", "YES"].includes(r.swSuppressed) && ["NO", "YES"].includes(r.swHidden) && r.swFlexible === "NO" && r.swZone === "NO" && r.swEdgesInShadedMode === "NO", "unqualified suppression/hidden/flexible/source flags");
      need3(r.swConfigurationName === target.swConfigurationName && r.swConfigurationId === target.swConfigurationId, "reference/target configuration disagreement");
      need3(/^\d+$/.test(r.swID ?? "") && /^\d+$/.test(r.swReferenceNumber ?? "") && typeof r.swName === "string" && r.swName.length && r.localTransform, "missing persistent component identity/transform");
      need3(r.swDisplayMode === "6" && r.swHlrDisplayQuality === "1", "unqualified display profile");
    }
  }
  t.rosterEvidence = { models: { declaredCountPresent: true, declaredCount: t.models.length, actualCount: t.models.length }, externalFeatures: { present: false, declaredCount: null, actualCount: 0 } };
}
var Archive = class {
  constructor(bytes, limits, label) {
    this.b = bytes;
    this.v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    this.p = 0;
    this.next = 1;
    this.classes = /* @__PURE__ */ new Map();
    this.objects = /* @__PURE__ */ new Map();
    this.limits = limits;
    this.label = label;
    this.count = 0;
  }
  require(ok, message) {
    need3(ok, `${this.label} at ${this.p}: ${message}`);
  }
  take(n) {
    this.require(Number.isSafeInteger(n) && n >= 0 && this.p + n <= this.b.length, "truncated field");
    const at = this.p;
    this.p += n;
    return this.b.subarray(at, this.p);
  }
  u(n = 4) {
    const at = this.p;
    this.take(n);
    return n === 1 ? this.v.getUint8(at) : n === 2 ? this.v.getUint16(at, true) : n === 3 ? this.v.getUint16(at, true) + this.v.getUint8(at + 2) * 65536 : this.v.getUint32(at, true);
  }
  exact(x = 0, n = 4) {
    this.require(this.u(n) === x, "unknown scalar/flags");
  }
  amount(n = 2) {
    const x = this.u(n);
    this.require(x <= (this.limits.edges ?? Infinity) && x <= this.b.length - this.p, "record count exceeds remaining input/budget");
    return x;
  }
  s() {
    this.exact(16776959, 3);
    let n = this.u(1);
    if (n === 255) n = this.u(2);
    this.require(n !== 65535, "unsupported extended CString length");
    const b = this.take(n * 2);
    try {
      const s = utf16.decode(b);
      this.require(!/[\u0000-\u001f]/.test(s), "control-bearing CString");
      return s;
    } catch {
      this.require(false, "invalid CString");
    }
  }
  o(name, schema = 1, { nullable = false, alias = false } = {}) {
    this.require(++this.count <= (this.limits.edges ?? Infinity), "object budget");
    const tag = this.u(2);
    if (tag === 0) {
      this.require(nullable, "absent required object");
      return null;
    }
    let actual, id;
    if (tag === 65535) {
      this.exact(schema, 2);
      const b = this.take(this.u(2));
      try {
        actual = ascii.decode(b);
      } catch {
        this.require(false, "invalid class encoding");
      }
      this.classes.set(this.next++, actual);
    } else if (tag & 32768) actual = this.classes.get(tag & 32767);
    else {
      const object2 = this.objects.get(tag);
      this.require(alias && object2?.name === name, "unknown/unsupported object alias");
      return { ...object2, alias: true };
    }
    this.require(actual === name, `unknown class; expected ${name}`);
    id = this.next++;
    const object = { id, name: actual };
    this.objects.set(id, object);
    return object;
  }
  handle() {
    const o = this.o("moCStringHandle_c", 1, { alias: true });
    if (!o.alias) o.value = this.s();
    return o.value;
  }
  eof() {
    this.require(this.p === this.b.length, "unknown trailing records");
  }
};
function fileDefinition(c) {
  c.o("moExtObject_c");
  c.o("moObjFileDef_c");
  const name = c.handle(), creation = c.u(), path2 = c.handle(), modified = c.u();
  c.exact();
  const kind = c.u(2);
  c.require([2, 3].includes(kind), "unknown document kind");
  return { name, path: path2, creation: String(creation), modified, kind: kind === 2 ? "PART" : "ASSEMBLY" };
}
function headerObject(c) {
  const f = fileDefinition(c);
  const flags = [c.u(), c.u(), c.u()];
  c.require(c.s() === "", "nonempty external-object source slot");
  c.exact(4294967295);
  c.exact();
  return { ...f, catalogueFlags: flags };
}
function header2800(bytes, limits = {}) {
  const c = new Archive(bytes, limits, "Header2");
  c.o("moHeader_c");
  c.o("su_CStringArray", 0);
  for (let n = c.amount(); n--; ) c.s();
  c.o("su_CStringArray", 0);
  for (let n = c.amount(); n--; ) c.require(c.s() === "", "nonempty auxiliary header/source slot");
  c.o("suObList");
  for (let n = c.amount(); n--; ) {
    c.o("moLogs_c");
    for (let k = c.amount(); k--; ) {
      c.o("moStamp_c");
      c.u(2);
      c.u();
      c.u();
      const event = c.s();
      c.require(["Created", "Modified", "Deleted", "Renamed", "Reordered", "Suppressed", "Unsuppressed", "Rollback", "Rolled back", "Changed"].includes(event), "unknown log event/source role");
    }
    c.u();
    c.s();
  }
  const original = c.u(), sequence = c.u(), catalog = [];
  if (c.v.getUint16(c.p, true) !== 0) {
    c.o("moExtObjectList_c");
    for (let n = c.amount(); n--; ) catalog.push(headerObject(c));
  } else c.exact(0, 2);
  const selectedSave = String(c.u()), self = headerObject(c), save = String(c.u());
  c.exact();
  c.exact();
  const creation = String(c.u());
  const lineage = c.u();
  c.require([0, 1, 2].includes(lineage), "unknown header lineage flag");
  c.exact();
  c.exact();
  c.exact(0, 2);
  c.eof();
  return { role: "fully-consumed-header-external-object-catalogue", self, catalog, selectedSave, save, creation, original, sequence, lineage };
}
function configurations2800(bytes, limits = {}) {
  const c = new Archive(bytes, limits, "CMgrHdr2");
  c.o("dmConfigMgrHeader_c");
  const configurations = [];
  for (let n = c.amount(); n--; ) {
    c.o("dmConfigHeader_c");
    const active = c.u();
    c.require(active === 0 || active === 1, "unknown configuration selection flag");
    const name = c.s(), id = String(c.u()), stamp = String(c.u());
    c.require(c.s() === name, "configuration/reference identity disagreement");
    const parent = c.u(), flags = c.u();
    c.require(flags === 0 || flags === 1, "unknown configuration flags");
    c.require(c.s() === "" && c.s() === "", "nonempty configuration source slot");
    configurations.push({ name, id, stamp, active: !!active, parent, flags });
  }
  c.eof();
  c.require(configurations.length > 0 && new Set(configurations.map((c2) => c2.id)).size === configurations.length && new Set(configurations.map((c2) => c2.name)).size === configurations.length, "empty/duplicate configuration roster");
  c.require(configurations.filter((c2) => c2.active).length === 1, "no unique selected configuration");
  c.require(configurations.every((k) => k.parent === 4294967295 || configurations.some((p) => p.id === String(k.parent) && p.id !== k.id)), "dangling/cyclic direct configuration parent");
  const byId = new Map(configurations.map((c2) => [c2.id, c2]));
  for (const start of configurations) {
    const seen = /* @__PURE__ */ new Set();
    let node = start;
    while (node) {
      c.require(!seen.has(node.id), "configuration parent cycle");
      seen.add(node.id);
      c.require(seen.size <= (limits.depth ?? Infinity), "configuration parent depth budget");
      node = node.parent === 4294967295 ? null : byId.get(String(node.parent));
    }
  }
  return configurations;
}
function qualify2800Headers(meta, extra, limits) {
  const h = header2800(extra.get("Header2"), limits), configurations = configurations2800(extra.get("Contents/CMgrHdr2"), limits), active = configurations.find((c) => c.active);
  need3(meta.stamps && meta.definitionType && meta.stamps[0] === h.self.creation && meta.stamps[0] === h.creation && meta.stamps[1] === h.selectedSave && meta.stamps[1] === active.stamp && meta.stamps[2] === h.save, "intrinsic Header2/CMgrHdr2/ModelStamps creation/save disagreement");
  need3(meta.definitionType === h.self.kind, "intrinsic type GUID/Header2 disagreement");
  const ole = extra.get("Contents/OleItems");
  need3(ole?.length === 4 && ole.every((b) => b === 0), "embedded/linked OLE obligations are unqualified");
  const table = meta.tables.COMPINSTANCETREE;
  if (table) {
    const configuration = table.configurations[0], model = table.models.find((m) => m.id === configuration.swModelRef), self = table.files.find((f) => f.id === model.swFileRef);
    need3(configuration.swName === active.name && configuration.swID === active.id && configuration.swReference === h.self.name && model.swName === h.self.name && self.swPath === h.self.path && self.swCreationTime === h.creation && self.swDocType === h.self.kind && model.swLastModifiedStamp === active.stamp, "intrinsic XML2800 self/configuration/type/save disagreement");
    need3(table.files.every((f) => f === self || h.catalog.filter((k) => k.path === f.swPath && k.creation === f.swCreationTime && k.kind === f.swDocType).length === 1), "component XML/Header2 catalogue identity disagreement");
  }
  meta.container.semantic.profile = table ? "cfb-v3-xml2800-component-metadata-v1" : "cfb-v3-binary2800-intrinsic-metadata-v1";
  meta.container.semantic.header = h;
  meta.container.semantic.configurations = configurations;
  meta.container.semantic.referenceClosure = { complete: false, reason: table ? "CMgr and Config-* binary component/feature-source obligations are not yet qualified; XML2800 has no external-feature roster" : "No typed XML source roster; binary CMgr and Config-* feature-source/leaf closure is unqualified" };
  meta.legacy2800Paths = [h.self.path, ...h.catalog.map((c) => c.path)].filter(Boolean);
  return meta;
}

// src/native-solidworks-4100.js
var issue3 = (code, message) => Object.assign(new Error(`SolidWorks 4100/3400: ${message}`), { name: "NativeSolidWorksError", code });
var need4 = (ok, message) => {
  if (!ok) throw issue3("NATIVE_UNSUPPORTED", message);
};
var malformed3 = (ok, message) => {
  if (!ok) throw issue3("NATIVE_MALFORMED", message);
};
var DECIMAL_RE = /^(?:0|[1-9]\d*)$/;
var is4100 = (directory2) => Array.isArray(directory2?.storages) && directory2.storages.some((e) => e.name === "_MO_VERSION_4100");
var is3400 = (directory2) => !is4100(directory2) && Array.isArray(directory2?.storages) && directory2.storages.some((e) => e.name === "_MO_VERSION_3400");
function baseLegacyCarriers(directory2, hasComp) {
  const carriers = /* @__PURE__ */ new Map([
    ["ModelStamps", "ModelStamps"],
    ["Header2", "Header2"],
    ["Contents/Definition", "Contents/Definition"],
    ["Contents/CMgrHdr2", "Contents/CMgrHdr2"],
    ["Contents/OleItems", "Contents/OleItems"],
    ["swXmlContents/KeyWords__ZLB", "swXmlContents/KeyWords"]
  ]);
  if (directory2.entries.some((e) => e.name === "swXmlContents/Tables__ZLB")) {
    carriers.set("swXmlContents/Tables__ZLB", "swXmlContents/Tables");
  }
  if (hasComp) {
    carriers.set("swXmlContents/COMPINSTANCETREE__ZLB", "swXmlContents/COMPINSTANCETREE");
  }
  for (const req of ["ModelStamps", "Header2", "Contents/Definition", "Contents/CMgrHdr2", "Contents/OleItems", "swXmlContents/KeyWords__ZLB"]) {
    need4(directory2.entries.some((e) => e.name === req), `missing required legacy carrier ${req}`);
  }
  return carriers;
}
function scope4100(directory2) {
  const hasComp = directory2.entries.some((e) => e.name === "swXmlContents/COMPINSTANCETREE__ZLB");
  const dl3400 = directory2.storages.some((e) => e.name === "_DL_VERSION_3400");
  const dl4100 = directory2.storages.some((e) => e.name === "_DL_VERSION_4100");
  need4(dl3400 !== dl4100, "exactly one companion _DL_VERSION_3400 or _DL_VERSION_4100 storage is required");
  for (const s of ["Contents", "swXmlContents", "_MO_VERSION_4100"]) {
    need4(directory2.storages.some((e) => e.name === s), `missing required storage ${s}`);
  }
  const fixedStorages = /* @__PURE__ */ new Set([
    "Contents",
    "swXmlContents",
    "_MO_VERSION_4100",
    "_DL_VERSION_3400",
    "_DL_VERSION_4100",
    "SwDocMgrTempStorage",
    "ThirdPty",
    "ThirdPtyStore"
  ]);
  need4(
    directory2.storages.every((e) => fixedStorages.has(e.name) || /^(?:ThirdPtyStore\/CosmosXpress(?:\/.+)?|Config-(?:0|[1-9]\d*)-FeatureBodies|Embedding [1-9]\d*(?:\/.+)?)$/.test(e.name)),
    "unqualified 4100 CFB storage scope"
  );
  const carriers = baseLegacyCarriers(directory2, hasComp);
  const opaque = /^(?:Preview|PreviewPNG|ISolidWorksInformation|\x05SummaryInformation|\x05DocumentSummaryInformation|Config-(?:0|[1-9]\d*)-Properties|Config-(?:0|[1-9]\d*)-FeatureBodies\/LocalBodies|_MO_VERSION_4100\/(?:Biography|History)|_DL_VERSION_(?:3400|4100)\/DLUpdateStamp|ThirdPtyStore\/(?:VisualStates__ZLB|VisualStates_DisplayPane|Animator__Zip|CosmosXpress\/.+)|ThirdPty\/(?:Animator__ZLB|CMMotionLoadMapU|CM_MOTION_LOAD_1|CimSwBrowserAssembly|CimSwBrowserPart|MOLDFLOWXpress|PBPDFlt|Pw2StorageStream\.1\.35|SWA_Schedules|SWWebPublisherAssembly|SWWebPublisherPart)|Embedding [1-9]\d*\/.+|Contents\/(?:DisplayLists__ZLB|Printing|eModelLic|CMgr|CnfgObjs|Config-(?:0|[1-9]\d*)(?:-(?:Attachment|GhostPartition|LWDATA|Partition|CnfgObjs|MatesList|ResolvedFeatures))?))$/;
  for (const e of directory2.entries) {
    if (carriers.has(e.name)) continue;
    need4(!/^swXmlContents\//i.test(e.name) && !/^3DCCXmlContents\//i.test(e.name), `unsupported 4100 semantic carrier ${e.name}`);
    need4(opaque.test(e.name), `unqualified 4100 CFB stream ${e.name}`);
  }
  return carriers;
}
function scope3400(directory2) {
  const hasComp = directory2.entries.some((e) => e.name === "swXmlContents/COMPINSTANCETREE__ZLB");
  need4(!hasComp, "3400 COMPINSTANCETREE assemblies are not yet qualified");
  const dl2800 = directory2.storages.some((e) => e.name === "_DL_VERSION_2800");
  const dl3400 = directory2.storages.some((e) => e.name === "_DL_VERSION_3400");
  need4(dl2800 !== dl3400, "exactly one companion _DL_VERSION_2800 or _DL_VERSION_3400 storage is required");
  for (const s of ["Contents", "swXmlContents", "_MO_VERSION_3400"]) {
    need4(directory2.storages.some((e) => e.name === s), `missing required storage ${s}`);
  }
  const fixedStorages = /* @__PURE__ */ new Set([
    "Contents",
    "swXmlContents",
    "_MO_VERSION_3400",
    "_DL_VERSION_2800",
    "_DL_VERSION_3400",
    "SwDocMgrTempStorage",
    "ThirdPty",
    "ThirdPtyStore"
  ]);
  need4(
    directory2.storages.every((e) => fixedStorages.has(e.name) || /^Config-(?:0|[1-9]\d*)-FeatureBodies$/.test(e.name)),
    "unqualified 3400 CFB storage scope"
  );
  const carriers = baseLegacyCarriers(directory2, false);
  const opaque = /^(?:Preview|PreviewPNG|ISolidWorksInformation|\x05SummaryInformation|\x05DocumentSummaryInformation|Config-(?:0|[1-9]\d*)-Properties|Config-(?:0|[1-9]\d*)-FeatureBodies\/LocalBodies|_MO_VERSION_3400\/(?:Biography|History)|_DL_VERSION_(?:2800|3400)\/DLUpdateStamp|ThirdPtyStore\/(?:VisualStates__ZLB|VisualStates_DisplayPane|Animator__Zip)|ThirdPty\/(?:Animator__ZLB|CimSwBrowserAssembly|CimSwBrowserPart|MOLDFLOWXpress|PBPDFlt|SWA_Schedules|SWPowerTransPart|SWWebPublisherAssembly|SWWebPublisherPart|TestCosmeticThreadsPart)|Contents\/(?:DisplayLists__ZLB|DisplayLists__Zip|Printing|eModelLic|CMgr|CnfgObjs|Config-(?:0|[1-9]\d*)(?:-(?:Attachment|GhostPartition|LWDATA|Partition|CnfgObjs|MatesList|ResolvedFeatures))?))$/;
  for (const e of directory2.entries) {
    if (carriers.has(e.name)) continue;
    need4(!/^swXmlContents\//i.test(e.name) && !/^3DCCXmlContents\//i.test(e.name), `unsupported 3400 semantic carrier ${e.name}`);
    need4(opaque.test(e.name), `unqualified 3400 CFB stream ${e.name}`);
  }
  return carriers;
}
function parseHeaderPrefix(c) {
  c.o("moHeader_c");
  c.o("su_CStringArray", 0);
  for (let n = c.amount(); n--; ) c.s();
  c.o("su_CStringArray", 0);
  for (let n = c.amount(); n--; ) {
    c.require(c.s() === "", "nonempty auxiliary header/source slot");
  }
  c.o("suObList");
  for (let n = c.amount(); n--; ) {
    c.o("moLogs_c");
    for (let k = c.amount(); k--; ) {
      c.o("moStamp_c");
      c.u(2);
      c.u();
      c.u();
      const event = c.s();
      c.require(event.length > 0 && !/[\\/]/.test(event), "unsafe/invalid log event name");
    }
    c.u();
    c.s();
  }
  return { original: c.u(), sequence: c.u() };
}
function extObjectCommon(c, version) {
  c.o("moExtObject_c");
  let path2, name, kind, creation, modified, flagA = 0, flagB = 0;
  if (version === 3400) {
    c.o("moObjFileDef_c");
    name = c.handle();
    creation = String(c.u());
    path2 = c.handle();
    modified = c.u();
    c.exact();
    kind = c.u(2);
  } else {
    path2 = c.handle();
    name = c.handle();
    kind = c.u(2);
    flagA = c.u(1);
    creation = String(c.u());
    flagB = c.u(1);
    modified = c.u();
  }
  c.require([2, 3].includes(kind), "unknown document kind");
  c.require([0, 1].includes(flagA) && [0, 1, 2].includes(flagB), "unknown moExtObject flags");
  const catalogueFlags = [c.u(), c.u(), c.u()];
  const slot = c.s();
  const slotConfigId = c.u();
  c.exact(0);
  const tag = version === 4100 ? c.u() : null;
  return {
    name,
    path: path2,
    creation,
    modified,
    kind: kind === 2 ? "PART" : "ASSEMBLY",
    catalogueFlags,
    slot,
    slotConfigId,
    tag
  };
}
function parseHeaderLegacy(bytes, limits = {}, version = 4100) {
  const label = `Header2-${version}`;
  const c = new Archive(bytes, limits, label);
  const { original, sequence } = parseHeaderPrefix(c);
  const catalog = [];
  if (c.v.getUint16(c.p, true) !== 0) {
    c.o("moExtObjectList_c");
    for (let n = c.amount(); n--; ) catalog.push(extObjectCommon(c, version));
  } else c.exact(0, 2);
  const selectedSave = String(c.u());
  const self = extObjectCommon(c, version);
  const save = String(c.u());
  c.exact(0);
  c.exact(0);
  const creation = String(c.u());
  const lineage = c.u();
  c.require([0, 1, 2].includes(lineage), "unknown header lineage flag");
  c.exact(0);
  c.exact(0);
  c.exact(0, 2);
  if (version === 4100) {
    c.u();
    c.exact(0);
    c.u();
    if (c.o("suObList", 1, { nullable: true })) {
      c.require(c.amount() === 0, "nonempty trailing header suObList is unqualified");
    }
  } else {
    c.exact(0);
    c.u();
  }
  c.eof();
  return {
    role: `fully-consumed-header-${version}`,
    self,
    catalog,
    selectedSave,
    save,
    creation,
    original,
    sequence,
    lineage
  };
}
function parseConfigurationsLegacy(bytes, limits = {}, version = 4100) {
  const label = `CMgrHdr2-${version}`;
  const c = new Archive(bytes, limits, label);
  c.o("dmConfigMgrHeader_c");
  const configurations = [];
  for (let n = c.amount(); n--; ) {
    c.o("dmConfigHeader_c");
    const active = c.u();
    c.require(active === 0 || active === 1, "unknown configuration selection flag");
    const name = c.s();
    const id = String(c.u());
    const stamp = String(c.u());
    c.require(c.s() === name, "configuration/reference identity disagreement");
    const parent = c.u();
    const flags = c.u();
    c.require(flags === 0 || flags === 1, "unknown configuration flags");
    const s1 = c.s();
    const s2 = c.s();
    c.require(s1 === "" && typeof s2 === "string", "nonempty configuration source slot");
    const extraFlags = version === 4100 ? c.u() : null;
    configurations.push({ name, id, stamp, active: !!active, parent, flags, extraFlags });
  }
  if (version === 4100) c.u();
  c.eof();
  c.require(
    configurations.length > 0 && new Set(configurations.map((x) => x.id)).size === configurations.length && new Set(configurations.map((x) => x.name)).size === configurations.length,
    "empty/duplicate configuration roster"
  );
  c.require(configurations.filter((x) => x.active).length === 1, "no unique selected configuration");
  c.require(
    configurations.every((k) => k.parent === 4294967295 || configurations.some((p) => p.id === String(k.parent) && p.id !== k.id)),
    "dangling/cyclic direct configuration parent"
  );
  const byId = new Map(configurations.map((x) => [x.id, x]));
  for (const start of configurations) {
    const seen = /* @__PURE__ */ new Set();
    let node = start;
    while (node) {
      c.require(!seen.has(node.id), "configuration parent cycle");
      seen.add(node.id);
      c.require(seen.size <= (limits.depth ?? Infinity), "configuration parent depth budget");
      node = node.parent === 4294967295 ? null : byId.get(String(node.parent));
    }
  }
  return configurations;
}
function reference4100Grammar(root, table, idsCount) {
  const attrs = {
    swSolidWorks: ["swObjCount", "swVersion", ...Object.keys(root.attrs).filter((k) => k === "xmlns" || k.startsWith("xmlns:"))],
    swHeader: ["swObjCount"],
    swModelList: ["swObjCount"],
    swConfigurationList: ["swObjCount"],
    swExtFeatureList: ["swObjCount"],
    swFile: ["id", "swDocType", "swCreationTime", "swPath"],
    swModel: [
      "id",
      "swName",
      "swConfigurationName",
      "swConfigurationId",
      "swConfigurationAlternateName",
      "swLastModifiedStamp",
      "swConfigurationFlags",
      "swFileRef",
      "swBoundingBox",
      "swAssemblyFeatureEffectedComponents"
    ],
    swConfiguration: ["id", "swName", "swID", "swReference", "swMostRecentConfiguration", "swConfigurationNeedsUpdate", "swModelRef"],
    swReference: [
      "id",
      "swName",
      "swReferenceNumber",
      "swID",
      "swIsVirtualComponent",
      "swConfigurationId",
      "swConfigurationName",
      "swDisplayMode",
      "swHlrDisplayQuality",
      "swSuppressed",
      "swHidden",
      "swEdgesInShadedMode",
      "swFlexible",
      "swExcludeFromBOM",
      "swZone",
      "swModelRef",
      "swTransform",
      "swTransformStamp"
    ],
    swPropertyList: ["id"],
    swProperty: ["id", "swReference", "swColor"],
    swUserComponentList: ["id"],
    swUserComponent: ["id", "swReference", "swValue"],
    swDisplayStateList: ["id", "swCompNameList"],
    swDisplayState: ["id", "swDisplayStateName", "swShowState"]
  };
  const work = [root];
  while (work.length) {
    const n = work.pop();
    need4(attrs[n.name] && Object.keys(n.attrs).every((a) => attrs[n.name].includes(a)), `unknown XML4100 ${n.name} object/attribute`);
    work.push(...n.children);
  }
  const sectionCounts = [
    [root, idsCount],
    [root.children.find((n) => n.name === "swHeader"), table.files.length],
    [root.children.find((n) => n.name === "swModelList"), table.models.length],
    [root.children.find((n) => n.name === "swConfigurationList"), table.configurations.length]
  ];
  for (const [node, actual] of sectionCounts) {
    malformed3(node && DECIMAL_RE.test(node.attrs.swObjCount ?? "") && Number(node.attrs.swObjCount) === actual, "explicit XML4100 object count mismatch");
  }
  need4(table.externalFeatures.length === 0 && (!table.rosterEvidence?.externalFeatures?.present || table.rosterEvidence.externalFeatures.declaredCount === 0), "XML4100 external features are unqualified");
  need4(table.configurations.length > 0 && table.configurations.filter((c) => c.swMostRecentConfiguration === "YES").length === 1, "no unique selected XML4100 configuration");
  const selected = table.configurations.find((c) => c.swMostRecentConfiguration === "YES");
  const files = new Map(table.files.map((f) => [f.id, f]));
  const models = new Map(table.models.map((m) => [m.id, m]));
  for (const f of table.files) {
    need4(["PART", "ASSEMBLY"].includes(f.swDocType) && DECIMAL_RE.test(f.swCreationTime ?? "") && typeof f.swPath === "string", "XML4100 file identity");
  }
  for (const m of table.models) {
    need4(m.swAssemblyFeatureEffectedComponents == null || m.swAssemblyFeatureEffectedComponents === "", "assembly-feature affected components remain unqualified");
    need4(
      typeof m.swConfigurationName === "string" && m.swConfigurationName.length > 0 && DECIMAL_RE.test(m.swConfigurationId ?? "") && (m.id === selected.swModelRef ? DECIMAL_RE.test(m.swLastModifiedStamp ?? "") : m.swLastModifiedStamp == null || DECIMAL_RE.test(m.swLastModifiedStamp)),
      "XML4100 model configuration/save identity"
    );
    for (const r of m.references) {
      const target = models.get(r.swModelRef);
      const tFile = target && files.get(target.swFileRef);
      need4(target && tFile, "dangling XML4100 reference target");
      need4((r.swSuppressed == null || ["NO", "YES"].includes(r.swSuppressed)) && (r.swHidden == null || ["NO", "YES"].includes(r.swHidden)) && r.swIsVirtualComponent === "NO" && (r.swFlexible == null || r.swFlexible === "NO"), "unqualified XML4100 suppression/virtual/flexible flags");
      const refCfgOk = r.swConfigurationName == null && r.swConfigurationId == null || r.swConfigurationName === "" && r.swConfigurationId === "-1" || r.swConfigurationName === target.swConfigurationName && r.swConfigurationId === target.swConfigurationId;
      need4(refCfgOk, "XML4100 reference/target configuration disagreement");
      need4(DECIMAL_RE.test(r.swID ?? "") && DECIMAL_RE.test(r.swReferenceNumber ?? "") && typeof r.swName === "string" && r.swName.length > 0 && r.localTransform, "missing XML4100 persistent component identity/transform");
    }
  }
}
function validateKeywordsDoc(keywordsNode, expectedId, selfName, configurations, requireEmptyRefs, version) {
  need4(keywordsNode && keywordsNode.tag === "Keywords", "missing valid KeyWords XML");
  const cfgs = keywordsNode.children.filter((c) => c.name === "Configuration");
  need4(cfgs.length <= configurations.length, "KeyWords contains unexpected configurations");
  if (version === 3400) {
    need4(keywordsNode.attrs?.id == null && keywordsNode.attrs?.Model === selfName, "KeyWords 3400 Model name disagreement");
    for (const kc of cfgs) {
      need4(kc.attrs?.id == null && configurations.some((c) => c.name === kc.attrs?.Name), "KeyWords 3400 configuration disagreement");
    }
  } else {
    need4(keywordsNode.attrs?.id === expectedId, "KeyWords creation stamp disagreement");
    for (const kc of cfgs) {
      need4(configurations.some((c) => c.id === kc.attrs?.id && c.name === kc.attrs?.Name), "KeyWords configuration disagreement");
    }
  }
  if (requireEmptyRefs) {
    const refs = keywordsNode.children.filter((c) => c.name === "Reference" || c.name === "ExternalSource");
    need4(refs.length === 0, "PART KeyWords contains external/component reference entries");
  }
}
function validateConfigEntries(directory2, configurations) {
  const validIds = new Set(configurations.map((c) => c.id));
  for (const e of [...directory2.storages || [], ...directory2.entries || []]) {
    const m = /(?:^|\/)Config-(\d+)(?:-|$)/.exec(e.name);
    need4(!m || validIds.has(m[1]), `raw configuration storage/stream ${e.name} is outside CMgrHdr2 roster`);
  }
}
function qualifyLegacy4100Or3400(meta, extra, directory2, limits, version) {
  const h = parseHeaderLegacy(extra.get("Header2"), limits, version);
  const configurations = parseConfigurationsLegacy(extra.get("Contents/CMgrHdr2"), limits, version);
  const active = configurations.find((c) => c.active);
  const ole = extra.get("Contents/OleItems");
  need4(ole?.length === 4 && ole.every((b) => b === 0), "embedded/linked OLE obligations are unqualified");
  const keywordsRoot = extra.get("Keywords") || meta.keywordsRoot;
  need4(meta.stamps && meta.definitionType && keywordsRoot, "intrinsic stamps/Definition/KeyWords required");
  need4(meta.stamps[0] === h.self.creation && meta.stamps[0] === h.creation, "intrinsic Header2/ModelStamps creation disagreement");
  need4(meta.stamps[1] === h.selectedSave && meta.stamps[1] === active.stamp, "intrinsic Header2/CMgrHdr2/ModelStamps active save disagreement");
  need4(meta.stamps[2] === h.save, "intrinsic Header2/ModelStamps save disagreement");
  need4(meta.definitionType === h.self.kind, "intrinsic Definition GUID/Header2 kind disagreement");
  need4(
    h.self.slot === "" ? h.self.slotConfigId === 4294967295 : configurations.some((c) => c.name === h.self.slot && c.id === String(h.self.slotConfigId)),
    "Header2 active slot configuration disagreement"
  );
  validateConfigEntries(directory2, configurations);
  if (h.self.kind === "PART") {
    need4(!meta.tables?.COMPINSTANCETREE && !meta.tables?.Features, "unexpected component XML table inside physical PART leaf");
    need4(h.catalog.length === 0, "PART declares external/catalogue references in Header2");
    validateKeywordsDoc(keywordsRoot, meta.stamps[0], h.self.name, configurations, true, version);
    meta.container.semantic.profile = version === 4100 ? "cfb-v3-sw4100-physical-part-leaf-v1" : "cfb-v3-sw3400-physical-part-leaf-v1";
    meta.container.semantic.header = h;
    meta.container.semantic.configurations = configurations;
    meta.container.semantic.emptyExternalCatalog = true;
    meta.container.semantic.referenceClosure = {
      complete: true,
      reason: `Qualified SolidWorks ${version} physical PART leaf (zero Header2 catalog, zero OLE items).`
    };
    meta.legacy2800Paths = [h.self.path].filter(Boolean);
    return meta;
  }
  need4(version === 4100, "only 4100 COMPINSTANCETREE assemblies are qualified here");
  const table = meta.tables?.COMPINSTANCETREE;
  need4(table && table.version === "4100", "4100 assembly missing COMPINSTANCETREE table");
  validateKeywordsDoc(keywordsRoot, meta.stamps[0], h.self.name, configurations, false, version);
  const selected = table.configurations.find((c) => c.swMostRecentConfiguration === "YES");
  const model = table.models.find((m) => m.id === selected.swModelRef);
  const files = new Map(table.files.map((f) => [f.id, f]));
  const self = files.get(model.swFileRef);
  need4(
    selected.swName === active.name && selected.swID === active.id && selected.swReference === h.self.name && model.swName === h.self.name && self.swPath === h.self.path && self.swCreationTime === h.creation && self.swDocType === "ASSEMBLY" && meta.keywords?.Name === h.self.name,
    "intrinsic XML4100 self/Header2/CMgrHdr2/KeyWords disagreement"
  );
  need4(
    h.catalog.every((k) => ["PART", "ASSEMBLY"].includes(k.kind) && typeof k.path === "string"),
    "unsupported external object kind in 4100 Header2 catalog"
  );
  const modelsById = new Map(table.models.map((m) => [m.id, m]));
  const directFileIds = new Set(model.references.map((r) => modelsById.get(r.swModelRef)?.swFileRef).filter(Boolean));
  need4(
    [...directFileIds].every((fid) => {
      const f = files.get(fid);
      return f && h.catalog.some((k) => k.path === f.swPath && k.creation === f.swCreationTime && k.kind === f.swDocType);
    }),
    "XML4100 file table disagrees with Header2 external catalog"
  );
  meta.container.semantic.profile = "cfb-v3-xml4100-selected-physical-assembly-v1";
  meta.container.semantic.header = h;
  meta.container.semantic.configurations = configurations;
  meta.legacy2800Paths = [h.self.path, ...h.catalog.map((c) => c.path)].filter(Boolean);
  return meta;
}
var qualify4100 = (meta, extra, directory2, limits) => qualifyLegacy4100Or3400(meta, extra, directory2, limits, 4100);
var qualify3400 = (meta, extra, directory2, limits) => qualifyLegacy4100Or3400(meta, extra, directory2, limits, 3400);

// src/native-solidworks-2800-current.js
var hex = (s) => {
  if (!/^(?:[0-9a-f]{2})*$/.test(s)) throw new Error("Invalid internal grammar literal");
  return Uint8Array.from(s.match(/../g) ?? [], (x) => Number.parseInt(x, 16));
};
var MANAGER = hex("00000000000000000000ffffffff000000000000000000000000000000006500000000000000000000000000000000f00a0000000000000000000007951e000000fffeff0000ffff000001ffffffffffffffff00000000000000000000000000000000");
var STATE = hex("00000000000000000000000000006500000000000000000000000000000000f00a0000000000000000000007951e000000fffeff0000ffff000001ffffffffffffffff00000000000000000000000000000000");
var CONFIG_NUMERIC = hex("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000d0e39e25000000000000");
var CONFIG_TAIL = hex("0000000065000000000000000000ffffffff00000000");
var ORIGIN_SKETCH = hex("0100000000000000000001000000ffff070001ffffffffffffffff01000000000004000200010000000000000004000000000000000000001f000000000000000000000000000000000001000000000000000000feffffff0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000ffffffff0000000000000000110000000200000000000000feff0000");
var ORIGIN_SUFFIX = hex("00000000000000000200010001000000020000000100000001000000010000000100000001000000010000000100000001000000010000000100000000000000000000000000fffeff00ffffffffffffffff01000000ffffffff0000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000300000001000000000000a086010000000000");
var SURFACE_COUNTS = { moFromSktEntSurfIdRep_c: 1, moEndFaceSurfIdRep_c: 2, moFromSktEnt3IntSurfIdRep_c: 3, moEndFace3IntSurfIdRep_c: 3, moFaceBlendSurfIdRep_c: 1, moWzdHoleSurfIdRep_c: 2 };
var SURFACE_NAMES = [...Object.keys(SURFACE_COUNTS), "moLPatternSurfIdRep_c"];

// src/native-solidworks.js
var NativeSolidWorksError = class extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = "NativeSolidWorksError";
    this.code = code;
    this.details = details;
  }
};
var fail = (message, details) => {
  throw new NativeSolidWorksError("NATIVE_MALFORMED", message, details);
};
var unsupported2 = (message) => {
  throw new NativeSolidWorksError("NATIVE_UNSUPPORTED", message);
};
var utf8 = new TextDecoder("utf-8", { fatal: true });
var encoder = new TextEncoder();
var CRC_TABLE = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let j = 0; j < 8; j++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
  CRC_TABLE[i] = c >>> 0;
}
function crcUpdate(crc, bytes) {
  for (const b of bytes) crc = CRC_TABLE[(crc ^ b) & 255] ^ crc >>> 8;
  return crc >>> 0;
}
function bytesEqual(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
function decodeText(bytes, context2) {
  try {
    return utf8.decode(bytes);
  } catch {
    fail(`Invalid UTF-8 in ${context2}.`);
  }
}
function memberName(bytes) {
  const decoded = new Uint8Array(bytes.length);
  for (let i = 0; i < bytes.length; i++) decoded[i] = bytes[i] >>> 4 | (bytes[i] & 15) << 4;
  const name = decodeText(decoded, "native member name");
  if (!name || /[\u0000-\u001f]/.test(name)) fail("Empty or control-bearing native member name.");
  return name;
}
function context(signal, onProgress) {
  const check = () => {
    if (signal?.aborted) throw new NativeSolidWorksError("IMPORT_CANCELLED", "SolidWorks import cancelled.");
  };
  return {
    check,
    signal,
    progress(stage, completed, total, streamName = null) {
      check();
      onProgress?.({ stage, completed, total, streamName });
      check();
    },
    async yield() {
      check();
      await new Promise((resolve) => setTimeout(resolve, 0));
      check();
    }
  };
}
async function nativeDirectory(bytes, ctx) {
  if (bytes.length < 8) unsupported2("Not a supported SolidWorks native container.");
  if (bytesEqual(bytes.subarray(0, 8), Uint8Array.of(208, 207, 17, 224, 161, 177, 26, 225))) unsupported2("Legacy compound-file SolidWorks envelopes are not supported by this reader.");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const u16 = (o) => view.getUint16(o, true), u32 = (o) => view.getUint32(o, true);
  const version = view.getUint32(4, false);
  if (version !== 4) unsupported2(`Unsupported SolidWorks outer version ${version}.`);
  const roots = [];
  for (let r = 8; r + 22 <= bytes.length; r++) {
    if ((r & 1048575) === 0) {
      ctx.progress("directory", r, bytes.length);
      await ctx.yield();
    }
    if (u32(r + 4) !== 0) continue;
    const count = u16(r + 8);
    if (!count || count !== u16(r + 10) || u16(r + 20) !== 0) continue;
    const start = u32(r + 16) + 8;
    if (start < 8 || start + 46 > r || start + u32(r + 12) !== r) continue;
    if (count > Math.floor((r - start) / 46)) continue;
    roots.push({ offset: r, centralOffset: start, count });
  }
  if (!roots.length) fail("No consistent native end-of-directory root (truncated or corrupt container).");
  const valid = [], errors = [];
  for (const root of roots) {
    try {
      let c = root.centralOffset;
      const entries = [], names = /* @__PURE__ */ new Set();
      for (let i = 0; i < root.count; i++) {
        ctx.check();
        if (c + 46 > root.offset) fail("Central directory exceeds its declared extent.");
        const n = u16(c + 28), extra = u16(c + 30), comment = u16(c + 32), next = c + 46 + n + extra + comment;
        if (next > root.offset || !n) fail("Invalid central member name/extra/comment extent.");
        const flags = u16(c + 8), method = u16(c + 10), needed = u16(c + 6);
        if (needed !== 20 || method !== 8 || (flags & ~2054) !== 0) unsupported2(`Unsupported native member profile: version=${needed}, flags=${flags}, method=${method}.`);
        if (u16(c + 34) !== 0) unsupported2("Multi-disk native containers are not supported.");
        const storedBytes = u32(c + 20), decodedBytes = u32(c + 24), localOffset = u32(c + 42) + 8;
        if (storedBytes === 4294967295 || decodedBytes === 4294967295 || localOffset === 4294967295 + 8) unsupported2("ZIP64 native members are not supported.");
        if (localOffset < 8 || localOffset + 30 > root.centralOffset) fail("Local header offset is outside the member area.");
        const localNameBytes = u16(localOffset + 26), localExtraBytes = u16(localOffset + 28);
        const offset = localOffset + 30 + localNameBytes + localExtraBytes, end = offset + storedBytes;
        if (offset > root.centralOffset || end > root.centralOffset) fail("Compressed member exceeds the member area.");
        if (!bytesEqual(bytes.subarray(c + 6, c + 28), bytes.subarray(localOffset + 4, localOffset + 26)) || n !== localNameBytes || !bytesEqual(bytes.subarray(c + 46, c + 46 + n), bytes.subarray(localOffset + 30, localOffset + 30 + n))) fail("Local and central member fields disagree.", { centralOffset: c, localOffset });
        const name = memberName(bytes.subarray(c + 46, c + 46 + n));
        if (names.has(name)) fail("Duplicate native member name.", { name });
        names.add(name);
        entries.push({ name, offset, storedBytes, decodedBytes, crc32: u32(c + 16), localOffset, end });
        c = next;
      }
      const physical = [...entries].sort((a, b) => a.localOffset - b.localOffset);
      for (let i = 1; i < physical.length; i++) if (physical[i].localOffset < physical[i - 1].end) fail("Overlapping native members.");
      valid.push({ ...root, centralEnd: c, entries });
    } catch (e) {
      if (!(e instanceof NativeSolidWorksError) || e.code === "IMPORT_CANCELLED") throw e;
      errors.push(e);
    }
  }
  if (valid.length > 1) fail("Ambiguous native end-of-directory roots.");
  if (!valid.length) throw errors[0];
  return valid[0];
}
async function inflateMember(bytes, entry, ctx) {
  if (typeof DecompressionStream === "undefined") unsupported2("This runtime lacks DecompressionStream(deflate-raw).");
  let decoder;
  try {
    decoder = new DecompressionStream("deflate-raw");
  } catch {
    unsupported2("This runtime does not implement raw DEFLATE decompression.");
  }
  const source = new ReadableStream({ start(controller) {
    controller.enqueue(bytes.subarray(entry.offset, entry.offset + entry.storedBytes));
    controller.close();
  } });
  const reader = source.pipeThrough(decoder).getReader();
  const cancelled = () => {
    reader.cancel().catch(() => {
    });
  };
  ctx.signal?.addEventListener("abort", cancelled, { once: true });
  let size = 0, crc = 4294967295;
  const chunks = [];
  try {
    while (true) {
      ctx.check();
      const { done, value } = await reader.read();
      ctx.check();
      if (done) break;
      size += value.length;
      if (size > entry.decodedBytes) fail("DEFLATE output exceeds its declared size.", { name: entry.name });
      crc = crcUpdate(crc, value);
      chunks.push(value);
    }
    if (size !== entry.decodedBytes) fail("DEFLATE decoded-size mismatch.", { name: entry.name, expected: entry.decodedBytes, actual: size });
    if ((crc ^ 4294967295) >>> 0 !== entry.crc32) fail("DEFLATE CRC-32 mismatch.", { name: entry.name });
    const result = new Uint8Array(size);
    let p = 0;
    for (const chunk of chunks) {
      result.set(chunk, p);
      p += chunk.length;
    }
    return result;
  } catch (e) {
    await reader.cancel().catch(() => {
    });
    ctx.check();
    if (e instanceof NativeSolidWorksError) throw e;
    fail("Invalid raw-DEFLATE member.", { name: entry.name, reason: String(e.message || e) });
  } finally {
    ctx.signal?.removeEventListener("abort", cancelled);
    reader.releaseLock();
  }
}
function xmlUnescape(value) {
  return value.replace(/&([^;]*);|&/g, (all, entity) => {
    const named = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
    if (Object.hasOwn(named, entity)) return named[entity];
    if (/^#(?:[0-9]+|x[0-9a-fA-F]+)$/.test(entity || "")) {
      const n = entity[1] === "x" ? Number.parseInt(entity.slice(2), 16) : Number(entity.slice(1));
      if (n === 9 || n === 10 || n === 13 || n >= 32 && n <= 1114111 && !(n >= 55296 && n <= 57343) && n !== 65534 && n !== 65535) return String.fromCodePoint(n);
    }
    fail("Invalid or unsupported XML entity.");
  });
}
function parseXML(text, { allowText = false } = {}) {
  const document = { children: [] }, stack = [document];
  let p = 0;
  text = text.replace(/^\ufeff/, "");
  while (p < text.length) {
    const lt = text.indexOf("<", p), plain = text.slice(p, lt < 0 ? text.length : lt);
    if (plain.trim()) {
      if (!allowText || stack.length === 1) fail("Unexpected text in component-instance XML.");
      xmlUnescape(plain);
      if (allowText === "dimension-only" && stack.at(-1).name !== "Dimension") unsupported2("Unknown XML6000 Keywords text outside a typed Dimension.");
    }
    if (lt < 0) break;
    if (text.startsWith("<!--", lt)) {
      const end2 = text.indexOf("-->", lt + 4);
      if (end2 < 0) fail("Unterminated XML comment.");
      p = end2 + 3;
      continue;
    }
    if (text.startsWith("<?", lt)) {
      const end2 = text.indexOf("?>", lt + 2);
      if (end2 < 0) fail("Unterminated XML processing instruction.");
      p = end2 + 2;
      continue;
    }
    if (text.startsWith("<!", lt)) unsupported2("DTD and other XML declarations are not supported in the component tree.");
    let end = lt + 1, quote = null;
    for (; end < text.length; end++) {
      const ch = text[end];
      if (quote) {
        if (ch === quote) quote = null;
      } else if (ch === '"' || ch === "'") quote = ch;
      else if (ch === ">") break;
      else if (ch === "<") fail("Malformed XML tag.");
    }
    if (end === text.length) fail("Unterminated XML tag.");
    let body = text.slice(lt + 1, end);
    p = end + 1;
    if (body.startsWith("/")) {
      const tag2 = body.slice(1).trim();
      if (stack.length === 1 || stack.pop().tag !== tag2) fail("Mismatched XML closing tag.");
      continue;
    }
    const selfClose = body.endsWith("/");
    if (selfClose) body = body.slice(0, -1);
    const match = /^[A-Za-z_][\w.:-]*/.exec(body);
    if (!match) fail("Invalid XML element name.");
    const tag = match[0];
    let rest = body.slice(tag.length);
    const attrs = /* @__PURE__ */ Object.create(null);
    while (rest.length) {
      if (!rest.trim()) break;
      const attr = /^\s+([A-Za-z_][\w.:-]*)\s*=\s*("[^"<]*"|'[^'<]*')/.exec(rest);
      if (!attr || Object.hasOwn(attrs, attr[1])) fail("Malformed or duplicate XML attribute.");
      attrs[attr[1]] = xmlUnescape(attr[2].slice(1, -1));
      rest = rest.slice(attr[0].length);
    }
    const node = { tag, name: tag.split(":").at(-1), attrs, children: [] };
    stack.at(-1).children.push(node);
    if (!selfClose) stack.push(node);
  }
  if (stack.length !== 1 || document.children.length !== 1) fail("Incomplete or multiple-root component-instance XML.");
  return document.children[0];
}
var children = (node, name) => node.children.filter((n) => n.name === name);
function only(node, name) {
  const result = children(node, name);
  if (result.length !== 1) fail(`Expected exactly one ${name} in the component tree.`);
  return result[0];
}
function matrix(value) {
  if (value === void 0) return null;
  const parts = value.trim().split(/\s+/);
  if (parts.length !== 16 || parts.some((s) => !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(s))) fail("Malformed swTransform; expected 16 decimal numbers.");
  const result = parts.map(Number);
  if (!result.every(Number.isFinite) || result[3] !== 0 || result[7] !== 0 || result[11] !== 0 || result[15] !== 1) fail("Nonfinite or non-affine swTransform.");
  return result;
}
function declaration(name) {
  const token = encoder.encode(name), pattern = new Uint8Array(6 + token.length);
  pattern.set([255, 255, 1, 0, token.length, 0]);
  pattern.set(token, 6);
  return pattern;
}
var FACE = declaration("uoTempFaceTessData_c");
var DESCRIPTOR = Uint8Array.of(4, 0, 0, 0, 8, 0, 0, 0, 2, 0, 0, 0);
function referenceTable(payload, limits) {
  if (payload.length > limits.xmlBytes) unsupported2("SolidWorks reference XML byte budget exceeded.");
  const root = parseXML(decodeText(payload, "SolidWorks reference metadata"));
  const prefix = root.tag.includes(":") ? root.tag.split(":")[0] + ":" : "";
  if (root.name !== "swSolidWorks" || root.attrs[prefix ? `xmlns:${prefix.slice(0, -1)}` : "xmlns"] !== "http://www.solidworks.com/sw2003/schema") unsupported2("Unsupported SolidWorks reference XML namespace/root.");
  const work = [{ node: root, depth: 0 }];
  let count = 0;
  while (work.length) {
    const { node, depth } = work.pop();
    if (++count > limits.edges || depth > limits.depth) unsupported2("SolidWorks reference XML count/depth budget exceeded.");
    if (node.tag !== prefix + node.name || node !== root && Object.keys(node.attrs).some((k) => k === "xmlns" || k.startsWith("xmlns:"))) unsupported2("Unsupported rebound XML namespace in SolidWorks metadata.");
    for (const child of node.children) work.push({ node: child, depth: depth + 1 });
  }
  const allowed = /* @__PURE__ */ new Set(["swHeader", "swModelList", "swConfigurationList", "swExtFeatureList"]);
  if (root.children.some((n) => !allowed.has(n.name))) unsupported2("Unsupported SolidWorks reference-table section.");
  const files = children(only(root, "swHeader"), "swFile").map((n) => ({ ...n.attrs }));
  const models = children(only(root, "swModelList"), "swModel").map((n) => ({ ...n.attrs, references: children(n, "swReference").map((r) => ({ ...r.attrs, localTransform: matrix(r.attrs.swTransform) })) }));
  const configurations = children(only(root, "swConfigurationList"), "swConfiguration").map((n) => ({ ...n.attrs }));
  const lists = children(root, "swExtFeatureList");
  if (lists.length > 1) fail("Multiple SolidWorks external-feature lists.");
  const externalFeatures = lists.flatMap((l) => children(l, "swExtFeature").map((n) => ({ ...n.attrs })));
  if (lists.length && (!/^(?:0|[1-9]\d*)$/.test(lists[0].attrs.swObjCount ?? "") || Number(lists[0].attrs.swObjCount) !== externalFeatures.length)) fail("SolidWorks external-feature declared count mismatch.");
  for (const [section, name] of [[only(root, "swHeader"), "swFile"], [only(root, "swModelList"), "swModel"], [only(root, "swConfigurationList"), "swConfiguration"], ...lists.map((l) => [l, "swExtFeature"])]) {
    if (section.children.some((n) => n.name !== name)) unsupported2("Unknown object in SolidWorks reference-table section.");
    if (!["swModel", "swConfiguration"].includes(name) && section.children.some((n) => n.children.length)) unsupported2("Nested object inside a typed SolidWorks reference leaf.");
    if (section.attrs.swObjCount != null && (!/^(?:0|[1-9]\d*)$/.test(section.attrs.swObjCount) || name !== "swModel" && Number(section.attrs.swObjCount) !== section.children.length)) fail("SolidWorks reference-table declared count mismatch.");
  }
  const properties = [];
  for (const configuration of children(only(root, "swConfigurationList"), "swConfiguration")) {
    if (configuration.children.some((n) => n.name !== "swDisplayStateList")) unsupported2("Unknown nested SolidWorks configuration object.");
    for (const list of configuration.children) {
      if (Object.keys(list.attrs).some((k) => !["id", "swCompNameList"].includes(k)) || list.children.some((n) => n.name !== "swDisplayState" || n.children.length || Object.keys(n.attrs).some((k) => !["id", "swDisplayStateName", "swShowState"].includes(k)))) unsupported2("Unknown SolidWorks display-state metadata object.");
      properties.push(list.attrs, ...list.children.map((n) => n.attrs));
    }
  }
  for (const n of children(only(root, "swModelList"), "swModel")) {
    const allowedModelChild = root.attrs.swVersion === "4100" ? ["swReference", "swPropertyList", "swUserComponentList"] : ["swReference", "swPropertyList"];
    if (n.children.some((r) => !allowedModelChild.includes(r.name))) unsupported2("Unknown SolidWorks model-reference object.");
    if (children(n, "swReference").some((r) => r.children.length)) unsupported2("Nested object inside a SolidWorks component-reference leaf.");
    for (const list of children(n, "swPropertyList")) {
      if (list.children.some((r) => r.name !== "swProperty" || r.children.length || Object.keys(r.attrs).some((k) => !["id", "swReference", "swColor"].includes(k)))) unsupported2("Unsupported SolidWorks display-property record.");
      properties.push(list.attrs, ...list.children.map((r) => r.attrs));
    }
    if (root.attrs.swVersion === "4100") {
      for (const list of children(n, "swUserComponentList")) {
        if (list.children.some((r) => r.name !== "swUserComponent" || r.children.length || Object.keys(r.attrs).some((k) => !["id", "swReference", "swValue"].includes(k)))) unsupported2("Unsupported SolidWorks user-component record.");
        properties.push(list.attrs, ...list.children.map((r) => r.attrs));
      }
    }
  }
  const ids = /* @__PURE__ */ new Set();
  for (const row of [...files, ...models, ...configurations, ...externalFeatures, ...properties, ...models.flatMap((m) => m.references)]) {
    if (!/^\d+$/.test(row.id ?? "") || ids.has(row.id)) fail("Nondecimal or duplicate SolidWorks reference metadata identity.");
    ids.add(row.id);
  }
  const fs = new Map(files.map((f) => [f.id, f])), ms = new Map(models.map((m) => [m.id, m]));
  for (const m of models) {
    if (!fs.has(m.swFileRef)) fail("Dangling SolidWorks model-to-file reference.");
    for (const r of m.references) if (!ms.has(r.swModelRef)) fail("Dangling SolidWorks component-to-model reference.");
  }
  for (const r of [...configurations, ...externalFeatures]) if (!ms.has(r.swModelRef)) fail("Dangling SolidWorks configuration/feature-to-model reference.");
  const done = /* @__PURE__ */ new Set(), pending = /* @__PURE__ */ new Set();
  for (const start of models) {
    const stack = [{ id: start.id, exit: false, depth: 0 }];
    while (stack.length) {
      const item = stack.pop();
      if (item.exit) {
        pending.delete(item.id);
        done.add(item.id);
        continue;
      }
      if (pending.has(item.id)) fail("Cycle in SolidWorks reference model graph.");
      if (done.has(item.id)) continue;
      if (item.depth > limits.depth) unsupported2("SolidWorks model graph depth budget exceeded.");
      pending.add(item.id);
      stack.push({ ...item, exit: true });
      for (const r of ms.get(item.id).references) stack.push({ id: r.swModelRef, exit: false, depth: item.depth + 1 });
    }
  }
  const result = { version: root.attrs.swVersion ?? null, files, models, configurations, externalFeatures };
  if (result.version === "2800") reference2800Grammar(root, result);
  if (["15000", "4700", "6000", "4100"].includes(result.version)) {
    const declaredModelCount = only(root, "swModelList").attrs.swObjCount;
    result.rosterEvidence = {
      models: { declaredCountPresent: declaredModelCount != null, declaredCount: declaredModelCount != null ? Number(declaredModelCount) : null, actualCount: models.length },
      externalFeatures: { present: lists.length === 1, declaredCount: lists.length && lists[0].attrs.swObjCount != null ? Number(lists[0].attrs.swObjCount) : null, actualCount: externalFeatures.length }
    };
  }
  if (result.version === "4100") reference4100Grammar(root, result, ids.size);
  if (result.version === "6000") {
    const evidence = (node, actualCount) => ({ declaredCountPresent: node.attrs.swObjCount != null, declaredCount: node.attrs.swObjCount != null ? Number(node.attrs.swObjCount) : null, actualCount });
    result.rosterEvidence.root = evidence(root, ids.size);
    result.rosterEvidence.files = evidence(only(root, "swHeader"), files.length);
    result.rosterEvidence.configurations = evidence(only(root, "swConfigurationList"), configurations.length);
    reference6000Grammar(root, result);
  }
  return result;
}
function profile6000(ok, message) {
  if (!ok) unsupported2(`Unsupported XML6000 physical profile: ${message}.`);
}
function reference6000Grammar(root, table) {
  const attrs = {
    swSolidWorks: ["swObjCount", "swVersion", ...Object.keys(root.attrs).filter((k) => k === "xmlns" || k.startsWith("xmlns:"))],
    swHeader: ["swObjCount"],
    swModelList: ["swObjCount"],
    swConfigurationList: ["swObjCount"],
    swExtFeatureList: ["swObjCount"],
    swFile: ["id", "swDocType", "swCreationTime", "swPath"],
    swModel: ["id", "swName", "swConfigurationName", "swConfigurationId", "swLastModifiedStamp", "swConfigurationFlags", "swFileRef", "swBoundingBox", "swAssemblyFeatureEffectedComponents"],
    swConfiguration: ["id", "swName", "swID", "swReference", "swMostRecentConfiguration", "swConfigurationNeedsUpdate", "swModelRef"],
    swReference: ["id", "swName", "swReferenceNumber", "swID", "swIsVirtualComponent", "swConfigurationId", "swConfigurationName", "swDisplayMode", "swHlrDisplayQuality", "swSuppressed", "swHidden", "swEdgesInShadedMode", "swFlexible", "swExcludeFromBOM", "swZone", "swModelRef", "swTransform", "swTransformStamp"]
  };
  const work = [root];
  while (work.length) {
    const n = work.pop();
    profile6000(attrs[n.name] && Object.keys(n.attrs).every((k) => attrs[n.name].includes(k)), `unknown ${n.name} record/attribute`);
    if (n.attrs.swObjCount != null) profile6000(/^(?:0|[1-9]\d*)$/.test(n.attrs.swObjCount), "noncanonical explicit count");
    work.push(...n.children);
  }
  for (const [name, e] of Object.entries(table.rosterEvidence)) if (name !== "externalFeatures") profile6000(e.declaredCountPresent && Number.isSafeInteger(e.declaredCount) && e.declaredCount === e.actualCount, `explicit ${name} count is absent or contradictory`);
  const ext = table.rosterEvidence.externalFeatures;
  profile6000(ext.present && ext.declaredCount === 0 && ext.actualCount === 0, "explicit typed zero external-feature roster required");
  for (const f of table.files) profile6000(["PART", "ASSEMBLY"].includes(f.swDocType) && /^(?:0|[1-9]\d*)$/.test(f.swCreationTime ?? "") && typeof f.swPath === "string", "file type/creation/path");
  for (const m of table.models) {
    const kind = table.files.find((f) => f.id === m.swFileRef).swDocType, configuration = table.configurations.find((c) => c.swModelRef === m.id);
    profile6000(m.swConfigurationFlags == null || m.swConfigurationFlags === (kind === "PART" ? "4194688" : configuration?.swMostRecentConfiguration === "YES" ? "262528" : "262272"), "unknown model role/configuration flags");
    profile6000(m.swAssemblyFeatureEffectedComponents == null || m.swAssemblyFeatureEffectedComponents === "", "assembly-feature affected components");
    for (const r of m.references) {
      profile6000(["YES", "NO"].includes(r.swSuppressed) && ["YES", "NO"].includes(r.swHidden) && r.swIsVirtualComponent === "NO", "unknown suppression/hidden/virtual flags");
      for (const field of ["swFlexible", "swExcludeFromBOM", "swZone", "swEdgesInShadedMode"]) profile6000(r[field] == null || r[field] === "NO", `unknown/unsupported ${field}`);
      profile6000(/^\d+$/.test(r.swID ?? "") && /^\d+$/.test(r.swReferenceNumber ?? "") && typeof r.swName === "string" && r.swName.length > 0, "component persistent identity");
      const target = table.models.find((m2) => m2.id === r.swModelRef);
      profile6000(r.swConfigurationName != null && r.swConfigurationId != null && r.swTransform != null && r.swConfigurationName === target.swConfigurationName && r.swConfigurationId === target.swConfigurationId, "component/target configuration disagreement");
      profile6000(r.swDisplayMode == null || r.swDisplayMode === "6", "unknown display mode");
      profile6000(r.swHlrDisplayQuality == null || r.swHlrDisplayQuality === "1", "unknown display quality");
    }
  }
  for (const c of table.configurations) profile6000(["YES", "NO"].includes(c.swMostRecentConfiguration) && (c.swConfigurationNeedsUpdate == null || c.swConfigurationNeedsUpdate === "NO"), "unknown configuration selection/update flags");
}
function keywords6000(root, table, limits) {
  const attrs = { Keywords: ["id", "Name"], Configuration: ["id", "Name", "Description", "Type", "Material"], Reference: ["id", "Name", "Type"], Feature: ["id", "Name", "Type"], Sketch: ["id", "Name", "Type", "Dissectable"], Extrusion: ["id", "Name", "Dissectable", "DissectableChildren", "DissectableRoot"], HoleWizard: ["id", "Name", "Dissectable", "DissectableChildren", "DissectableRoot"], Dimension: ["Name"] };
  const types = /* @__PURE__ */ new Set(["Exploded Views", "Live Section Planes", "Mates", "Ambient", "Directional", "Equations", "Sensors", "Favorites", "Annotations", "Axis", "PLANE", "Plane", "Lights, Cameras and Scene", "Design Binder", "Comments", "Solid Bodies", "Surface Bodies", "SolidWorks Materials", "Revolve", "Chamfer", "Sketch", "Origin"]);
  const work = [{ n: root, d: 0 }];
  let count = 0;
  while (work.length) {
    const { n, d } = work.pop();
    profile6000(++count <= limits.edges && d <= limits.depth, "Keywords count/depth budget");
    profile6000(n.tag === n.name && attrs[n.name] && Object.keys(n.attrs).every((k) => attrs[n.name].includes(k)), "unknown Keywords record/attribute");
    profile6000(n === root ? n.children.every((c) => c.name !== "Keywords" && c.name !== "Dimension") : n.children.every((c) => c.name === "Dimension") && ["Feature", "Sketch", "Extrusion", "HoleWizard"].includes(n.name) || n.children.length === 0, "unknown nested Keywords object");
    if (n.name === "Feature" || n.name === "Sketch") profile6000(n.attrs.Type == null || types.has(n.attrs.Type), "unknown Keywords feature/source type");
    if (n.name === "Configuration") profile6000(n.attrs.Type === "ConfigurationManager", "unknown Keywords configuration type");
    for (const f of ["Dissectable", "DissectableRoot"]) profile6000(n.attrs[f] == null || n.attrs[f] === "true", "unknown Keywords dissection flag");
    work.push(...n.children.map((n2) => ({ n: n2, d: d + 1 })));
  }
  const cs = children(root, "Configuration");
  profile6000(cs.length === table.configurations.length && table.configurations.every((c) => cs.filter((k) => k.attrs.id === c.swID && k.attrs.Name === c.swName).length === 1), "Keywords configuration roster disagreement");
  const refs = children(root, "Reference"), all = table.models.flatMap((m) => m.references), unique = /* @__PURE__ */ new Map();
  for (const r of all) {
    const identity = JSON.stringify([r.swName, r.swReferenceNumber]);
    profile6000(!unique.has(r.swID) || unique.get(r.swID) === identity, "inconsistent persistent occurrence identity");
    unique.set(r.swID, identity);
  }
  profile6000(refs.length === unique.size && refs.every((k) => all.some((r) => k.attrs.id === r.swID && k.attrs.Name === `${r.swName}-${r.swReferenceNumber}` && k.attrs.Type === `${r.swName}-`)) && new Set(refs.map((k) => k.attrs.id)).size === refs.length, "Keywords reference roster disagreement");
  return { configurations: cs.map((n) => ({ ...n.attrs })), references: refs.map((n) => ({ ...n.attrs })), featureNames: root.children.filter((n) => ["Feature", "Sketch", "Extrusion", "HoleWizard"].includes(n.name)).map((n) => n.attrs.Name) };
}
function material6000(payload, table, limits) {
  profile6000(payload.length >= 2 && payload[0] === 255 && payload[1] === 254 && payload.length % 2 === 0, "exact UTF-16LE material framing");
  let text;
  try {
    text = new TextDecoder("utf-16le", { fatal: true }).decode(payload);
  } catch {
    fail("Invalid UTF-16LE in XML6000 MATERIALTREE.");
  }
  const root = parseXML(text);
  profile6000(root.tag === "mstns:materials" && root.attrs["xmlns:mstns"] === "http://www.solidworks.com/sldmaterials" && root.attrs["xmlns:sldcolorswatch"] === "http://www.solidworks.com/sldcolorswatch" && root.attrs.version === "2008.03", "unknown material namespace/version");
  const schema = { materials: [["xmlns:mstns", "xmlns:msdata", "xmlns:sldcolorswatch", "xmlns:xsi", "version"], ["curves", "classification", "configurationslist"]], curves: [["id"], ["point"]], point: [["x", "y"], []], classification: [["name"], ["material"]], material: [["name", "failurecriteria"], ["shaders", "swatchcolor", "xhatch", "physicalproperties", "custom"]], shaders: [[], ["pwshader2", "cgshader2", "swtexture"]], pwshader2: [["isNewShader"], []], cgshader2: [["name"], []], swtexture: [[], []], swatchcolor: [["RGB"], ["Optical"]], Optical: [["Ambient", "Transparency", "Diffuse", "Specularity", "Shininess", "Emission"], []], xhatch: [["name", "angle", "scale"], []], physicalproperties: [[], ["EX", "NUXY", "GXY", "DENS", "KX", "C", "SIGXT", "SIGYLD"]], custom: [[], []], configurationslist: [[], ["configuration"]], configuration: [["name", "material"], []] };
  for (const k of ["EX", "NUXY", "GXY", "DENS", "KX", "C", "SIGXT", "SIGYLD"]) schema[k] = [["displayname", "value"], []];
  const work = [{ n: root, d: 0 }];
  let count = 0;
  while (work.length) {
    const { n, d } = work.pop(), s = schema[n.name];
    profile6000(++count <= limits.edges && d <= limits.depth, "MATERIALTREE budget");
    profile6000(s && Object.keys(n.attrs).every((k) => s[0].includes(k)) && n.children.every((c) => s[1].includes(c.name)), "unknown MATERIALTREE record/attribute");
    profile6000(n.tag === n.name || n === root && n.tag === "mstns:materials" || n.name === "Optical" && n.tag === "sldcolorswatch:Optical", "rebound material namespace");
    if (n.name === "cgshader2") profile6000(n.attrs.name === "", "external material shader");
    work.push(...n.children.map((n2) => ({ n: n2, d: d + 1 })));
  }
  for (const c of children(only(root, "configurationslist"), "configuration")) profile6000(table.configurations.some((k) => k.swName === c.attrs.name), "unknown material configuration");
  return { role: "material-appearance-only", externalTextures: 0 };
}
async function contentManager6000(bytes, meta, table, ctx, limits) {
  let p = 0, next = 1, objects = 0;
  const classes = /* @__PURE__ */ new Map(), v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), projection = [];
  const need5 = (ok, message) => profile6000(ok, `SwDocContentMgrInfo at ${p}: ${message}`);
  const take = (n) => {
    ctx.check();
    need5(Number.isSafeInteger(n) && n >= 0 && p + n <= bytes.length, "truncated field");
    const at = p;
    p += n;
    return at;
  };
  const u = (n = 4) => {
    const at = take(n);
    return n === 1 ? v.getUint8(at) : n === 2 ? v.getUint16(at, true) : v.getUint32(at, true);
  };
  const exact = (value = 0, n = 4) => need5(u(n) === value, "unknown field/flags");
  const count = (n = 4) => {
    const x = u(n);
    need5(x <= limits.edges && x <= bytes.length - p, "record count exceeds bounded input");
    return x;
  };
  const str = () => {
    exact(255, 1);
    exact(254, 1);
    exact(255, 1);
    const n = u(1);
    need5(n < 255, "unsupported CString length encoding");
    const at = take(n * 2);
    try {
      return new TextDecoder("utf-16le", { fatal: true }).decode(bytes.subarray(at, p));
    } catch {
      need5(false, "invalid CString encoding");
    }
  };
  const obj = (name2, schema = 1) => {
    need5(++objects <= limits.edges, "object budget");
    const tag = u(2);
    let actual;
    if (tag === 65535) {
      exact(schema, 2);
      const n = u(2), at = take(n);
      actual = decodeText(bytes.subarray(at, p), "MFC class");
      classes.set(next++, actual);
    } else {
      need5((tag & 32768) !== 0, "object alias or unknown class tag");
      actual = classes.get(tag & 32767);
    }
    need5(actual === name2, `unknown class (expected ${name2})`);
    next++;
  };
  const decimal = (s) => /^(?:0|[1-9]\d*)$/.test(s ?? "");
  const configNames = new Set(table.configurations.map((c) => c.swName));
  const cfg = () => {
    const s = str();
    need5(configNames.has(s), "unknown configuration key");
    return s;
  };
  const map = (fn) => {
    const n = count(), seen = /* @__PURE__ */ new Set();
    for (let i = 0; i < n; i++) {
      const key3 = cfg();
      need5(!seen.has(key3), "duplicate configuration map key");
      seen.add(key3);
      fn(key3);
    }
  };
  const selected = table.configurations.filter((c) => c.swMostRecentConfiguration === "YES");
  need5(selected.length === 1, "no unique selected configuration");
  const selectedModel = table.models.find((m) => m.id === selected[0].swModelRef), self = table.files.find((f) => f.id === selectedModel.swFileRef), assembly = self.swDocType === "ASSEMBLY";
  obj("moBCModeInfo_c");
  const path2 = str();
  exact(Number(self.swCreationTime));
  const name = str();
  need5(assembly ? path2 === self.swPath && name === meta.keywords.Name : path2 === "" && name === "", "intrinsic cache identity");
  exact();
  const configurations = count(2);
  need5(configurations === (assembly ? table.configurations.length : 0), "cache configuration roster count");
  const seenConfigurations = /* @__PURE__ */ new Set();
  for (let ci = 0; ci < configurations; ci++) {
    await ctx.yield();
    obj("moBCConfigurationInfo_c");
    const cname = cfg(), active = str(), c = table.configurations.find((c2) => c2.swName === cname), model = table.models.find((m) => m.id === c.swModelRef);
    need5(!seenConfigurations.has(cname), "duplicate cached configuration");
    seenConfigurations.add(cname);
    need5(active === (c.swMostRecentConfiguration === "YES" ? "ACTIVE" : "NON-ACTIVE"), "cache active configuration");
    exact();
    exact();
    obj("moBCConfigObjMapInfo_c");
    const nodes = count(2);
    need5(nodes === model.references.length + 1, "cache flat node roster count");
    const persistent = /* @__PURE__ */ new Set();
    for (let ni = 0; ni < nodes; ni++) {
      obj(ni ? "moBCPartNode_c" : "moBCNode_c");
      const sid = u();
      exact(ni ? 4294967295 : 0);
      exact(ni ? 1 : 0);
      exact(ni ? 1 : 5);
      const nname = str(), state = u(), requested = str(), token = str();
      let reference = null;
      if (ni) {
        reference = model.references.find((r) => r.swID === String(sid));
        need5(reference && !persistent.has(sid), "unknown/duplicate cached component");
        persistent.add(sid);
        const target = table.models.find((m) => m.id === reference.swModelRef), file = table.files.find((f) => f.id === target.swFileRef);
        need5(file.swDocType === "PART" && target.references.length === 0 && token === file.swPath && requested === target.swConfigurationName && nname === reference.swName, "cached component path/type/configuration/identity disagreement");
        need5(state === (reference.swSuppressed === "YES" ? 0 : 2), "cached suppression disagreement");
      } else need5(sid === 0 && state === 2 && nname === name && requested === cname && token === self.swPath, "cache root identity");
      exact(ni ? 0 : 1);
      const transform = u(1);
      need5(transform === 0 || transform === 1, "unknown transform encoding");
      for (let i = 0; i < (transform ? 13 : 4); i++) need5(Number.isFinite(v.getFloat64(take(8), true)), "nonfinite cache transform");
      exact(0, 1);
      exact(0, 2);
      const mates = count(2);
      need5(!ni || mates === 0, "PART cache has nested mates/obligations");
      for (let mi = 0; mi < mates; mi++) {
        if ((mi & 255) === 0) await ctx.yield();
        obj("moBCMate_c");
        need5(str() === cname, "mate configuration");
        exact();
        str();
        exact(2);
        const kind = u();
        need5(kind === 0 || kind === 1, "unknown mate kind");
        need5(str() === (kind ? "moMateConcentric" : "moMateCoincident"), "unknown mate source class");
        str();
        exact();
        u();
      }
      exact();
      exact(1);
      exact();
      exact(0, 2);
      if (ni) {
        const nc = count(2);
        need5(nc === (state === 2 ? 1 : 0), "cached active component configuration count");
        for (let k = 0; k < nc; k++) {
          obj("moConfigSpecificInfo");
          need5(str() === requested, "cached component configuration");
          exact(1);
        }
      }
      projection.push({ configuration: cname, persistentLocalId: ni ? String(sid) : null, path: token, requestedConfiguration: requested, suppressed: reference?.swSuppressed ?? null });
    }
    exact(c.swMostRecentConfiguration === "YES" ? 1 : 0);
    need5(decimal(model.swConfigurationFlags), "cache configuration flags absent");
    exact(Number(model.swConfigurationFlags));
    exact();
    exact();
  }
  map(() => str());
  map(() => str());
  map(() => exact());
  need5(str() === selected[0].swName, "selected cache configuration");
  obj("su_CStringArray", 0);
  exact(0, 2);
  u();
  const names = count();
  need5(names === table.configurations.length, "cache name roster count");
  const seenNames = /* @__PURE__ */ new Set();
  for (let i = 0; i < names; i++) {
    const n = cfg();
    need5(!seenNames.has(n), "duplicate cache name");
    seenNames.add(n);
    need5(str() === "", "unknown configuration name mapping");
  }
  exact();
  exact(assembly ? 4 : 3);
  exact(1);
  map(() => {
    const n = count();
    exact(1);
    for (let i = 0; i < n; i++) {
      u();
      const feature = str();
      need5(meta.keywordEvidence.featureNames.includes(feature), "unknown cached feature");
    }
  });
  map(() => {
    const n = count();
    exact(1);
    for (let i = 0; i < n; i++) {
      u();
      exact(1);
    }
  });
  exact(Number(meta.stamps[1]));
  map((key3) => {
    const m = table.models.find((m2) => m2.swConfigurationName === key3 && m2.swFileRef === self.id);
    need5(m && decimal(m.swConfigurationFlags), "unknown cached flags configuration");
    exact(Number(m.swConfigurationFlags));
  });
  map(() => need5(Number.isFinite(v.getFloat64(take(8), true)), "nonfinite material density"));
  map(() => exact());
  map(() => exact());
  need5(p === bytes.length, "unknown trailing record");
  return { role: "fully-consumed-redundant-reference-cache", objects, bytesConsumed: p, references: projection };
}
async function readSolidWorksMetadata(buffer, { name = "", signal = null, onProgress = null, limits = {}, usage = {} } = {}) {
  limits = { xmlBytes: 16 * 1024 * 1024, edges: 1e5, depth: 64, ...limits };
  const ctx = context(signal, onProgress), bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  ctx.check();
  const legacy = isCFB(bytes);
  const directory2 = legacy ? await readCFBDirectory(bytes, { signal, onProgress, limits, usage }) : await nativeDirectory(bytes, ctx);
  if (directory2.entries.length > limits.edges) unsupported2("SolidWorks member count budget exceeded.");
  const result = { sourceName: name, outerVersion: legacy ? null : 4, directory: directory2.entries.map((e) => ({ ...e })), tables: {}, embeddedMembers: [], definitionType: null, stamps: null, keywords: null };
  const carriers = /* @__PURE__ */ new Map([["swXmlContents/Features__ZLB", "swXmlContents/Features"], ["swXmlContents/KeyWords__ZLB", "swXmlContents/KeyWords"], ["swXmlContents/Tables__ZLB", "swXmlContents/Tables"], ["Contents/Definition", "Contents/Definition"], ["ModelStamps", "ModelStamps"]]);
  let xml6000 = false, xml2800 = false, sw4100 = false, sw3400 = false;
  const extraPayloads = /* @__PURE__ */ new Map();
  if (legacy) {
    sw4100 = is4100(directory2);
    sw3400 = is3400(directory2);
    xml2800 = !sw4100 && !sw3400 && directory2.storages.some((e) => e.name === "_MO_VERSION_2800" || e.name === "_DL_VERSION_2800");
    xml6000 = !sw4100 && !sw3400 && directory2.storages.some((e) => e.name === "_MO_VERSION_6000" || e.name === "_DL_VERSION_6000");
    if (sw4100) {
      const observed = scope4100(directory2);
      carriers.clear();
      for (const [physical, logical] of observed) carriers.set(physical, logical);
    } else if (sw3400) {
      const observed = scope3400(directory2);
      carriers.clear();
      for (const [physical, logical] of observed) carriers.set(physical, logical);
    } else if (xml2800) {
      const observed = scope2800(directory2);
      carriers.clear();
      for (const [physical, logical] of observed) carriers.set(physical, logical);
    } else if (xml6000) {
      const assembly = directory2.entries.some((e) => e.name === "swXmlContents/COMPINSTANCETREE__ZLB");
      if (assembly) {
        carriers.delete("swXmlContents/Features__ZLB");
        carriers.set("swXmlContents/COMPINSTANCETREE__ZLB", "swXmlContents/COMPINSTANCETREE");
      }
      carriers.set("SwDocContentMgr/SwDocContentMgrInfo", "SwDocContentMgr/SwDocContentMgrInfo");
      if (!assembly && directory2.entries.some((e) => e.name === "swXmlContents/MATERIALTREE")) carriers.set("swXmlContents/MATERIALTREE", "swXmlContents/MATERIALTREE");
      const scopes = /* @__PURE__ */ new Set(["Contents", "swXmlContents", "_MO_VERSION_6000", "_DL_VERSION_6000", "3DCCXmlContents", "ThirdPtyStore", "ThirdPty", "SwDocMgrTempStorage", "SwDocContentMgr", assembly ? "Attachments" : "SWIFT"]);
      profile6000(directory2.storages.every((e) => scopes.has(e.name)), "unknown storage role");
      profile6000(["_MO_VERSION_6000", "_DL_VERSION_6000"].every((n) => directory2.storages.some((e) => e.name === n)), "missing version storage");
      const opaque = /^(?:Header2|ISolidWorksInformation|Preview|PreviewPNG|\x05SummaryInformation|\x05DocumentSummaryInformation|Config-(?:0|[1-9]\d*)-Properties|_MO_VERSION_6000\/(?:AssyVisualData|Biography|History)|_DL_VERSION_6000\/DLUpdateStamp|ThirdPtyStore\/VisualStates__ZLB|ThirdPty\/(?:SWA_Schedules|CMMotionLoadMapU|CM_MOTION_LOAD_1|Animator__ZLB)|Contents\/(?:DisplayLists__ZLB|User Units Table__ZLB|View Orientation Data__ZLB|OleItems|eModelLic|CMgr|CMgrHdr2|CnfgObjs|Config-(?:0|[1-9]\d*)(?:-(?:MatesList|Attachment|ResolvedFeatures|LWDATA|GhostPartition|Partition))?))$/;
      profile6000(directory2.entries.every((e) => carriers.has(e.name) || opaque.test(e.name)), "unknown raw stream/reference-carrier role");
    } else {
      const storages = /* @__PURE__ */ new Set(["Contents", "swXmlContents", "_MO_VERSION_4700", "_DL_VERSION_4700", "3DCCXmlContents", "ThirdPtyStore", "ThirdPty", "SwDocMgrTempStorage"]);
      if (directory2.storages.some((e) => !storages.has(e.name))) unsupported2("Unsupported CFB storage/member scope; imported, virtual and unknown legacy profiles are not admitted.");
    }
    if (!sw4100 && !sw3400) {
      for (const e of directory2.entries) {
        if (!xml2800 && /__Zip$/i.test(e.name) || /^(?:swxmlcontents|3dccxmlcontents)\//i.test(e.name) && !carriers.has(e.name)) unsupported2("Unsupported or renamed SolidWorks CFB semantic carrier.");
      }
      for (const physical of carriers.keys()) if (!directory2.entries.some((e) => e.name === physical)) unsupported2(`Missing required SolidWorks CFB typed carrier: ${physical}.`);
    }
    result.container = { kind: "cfb", major: directory2.major, minor: directory2.minor, sectorBytes: directory2.sectorBytes, miniSectorBytes: directory2.miniSectorBytes, liveEntries: directory2.liveEntries, storages: directory2.storages.length, semantic: {} };
  }
  for (const indexedEntry of directory2.entries) {
    ctx.check();
    if (legacy && !carriers.has(indexedEntry.name)) continue;
    const entry = legacy ? { ...indexedEntry, name: carriers.get(indexedEntry.name) } : indexedEntry;
    let payload = legacy ? await directory2.read(indexedEntry) : await inflateMember(bytes, entry, ctx);
    if (legacy && indexedEntry.name.endsWith("__ZLB")) payload = await inflateCFBZLB(payload, { signal, onProgress, limits, usage, name: indexedEntry.name });
    if (xml2800 && indexedEntry.name.endsWith("__Zip")) payload = await inflate2800Zip(payload, { signal, onProgress, limits, usage, name: indexedEntry.name });
    if (xml2800 && !["swXmlContents/COMPINSTANCETREE", "Contents/Definition", "ModelStamps"].includes(entry.name)) {
      extraPayloads.set(entry.name, payload);
      continue;
    }
    if ((sw4100 || sw3400) && ["Header2", "Contents/CMgrHdr2", "Contents/OleItems"].includes(entry.name)) {
      extraPayloads.set(entry.name, payload);
      continue;
    }
    if (xml6000 && ["SwDocContentMgr/SwDocContentMgrInfo", "swXmlContents/MATERIALTREE"].includes(entry.name)) {
      extraPayloads.set(entry.name, payload);
      continue;
    }
    if (legacy && entry.name === "swXmlContents/Tables") {
      if (indexedEntry.storedBytes !== 24 || payload.length !== 0) unsupported2("Nonempty or unknown SolidWorks CFB Tables carrier is unsupported.");
      result.container.semantic.emptyTables = true;
      continue;
    }
    if (entry.name.startsWith("swXmlContents/") && !["swXmlContents/COMPINSTANCETREE", "swXmlContents/Features", "swXmlContents/KeyWords", "swXmlContents/MATERIALTREE"].includes(entry.name)) unsupported2(`Unsupported SolidWorks semantic XML carrier: ${entry.name.slice(0, 384)} (name length ${entry.name.length}).`);
    if (entry.name === "swXmlContents/COMPINSTANCETREE" || entry.name === "swXmlContents/Features") {
      const table = referenceTable(payload, limits);
      result.tables[entry.name.split("/").at(-1)] = table;
      if (legacy) {
        if (table.version !== (xml2800 ? "2800" : xml6000 ? "6000" : sw4100 ? "4100" : "4700")) unsupported2("Unsupported SolidWorks CFB reference XML/version-storage pairing.");
        const roster = table.rosterEvidence.externalFeatures;
        result.container.semantic.explicitEmptyExternalFeatures = roster.present && roster.declaredCount === 0 && roster.actualCount === 0;
      }
    }
    if (entry.name === "Contents/Definition" && payload.length >= 36) {
      const offset = xml2800 || sw4100 || sw3400 ? 16 : 20;
      if (xml2800 || sw4100 || sw3400) {
        const v = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
        if (v.getUint32(0, true) !== 26 || v.getUint32(4, true) !== 4 || v.getUint32(8, true) !== 25 || ![0, 1].includes(v.getUint32(12, true))) unsupported2("Unsupported legacy intrinsic Definition framing.");
      }
      const guid = Array.from(payload.subarray(offset, offset + 16), (b) => b.toString(16).padStart(2, "0")).join("");
      result.definitionType = { "303da383c527ce11bfd400400513bb57": "PART", "363da383c527ce11bfd400400513bb57": "ASSEMBLY" }[guid] ?? null;
    }
    if (entry.name === "ModelStamps" && payload.length === 12) {
      const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
      result.stamps = [0, 4, 8].map((o) => String(view.getUint32(o, true)));
    }
    if (entry.name === "swXmlContents/KeyWords") {
      if (payload.length > limits.xmlBytes) unsupported2("SolidWorks keyword XML byte budget exceeded.");
      const xml = payload[0] === 134 ? payload.subarray(1) : payload;
      const root = parseXML(decodeText(xml, "SolidWorks KeyWords"), { allowText: xml6000 ? "dimension-only" : true });
      if (root.tag !== "Keywords") unsupported2("Unsupported SolidWorks Keywords root.");
      result.keywords = { ...root.attrs };
      if (xml6000) {
        profile6000(payload[0] === 134, "missing exact KeyWords wrapper");
        extraPayloads.set("Keywords", root);
      }
      if (sw4100 || sw3400) extraPayloads.set("Keywords", root);
    }
    if (entry.name.startsWith("ImportedComp/") || entry.name.startsWith("VirtualComp/")) result.embeddedMembers.push({ ...entry, payload });
  }
  if (sw4100) qualify4100(result, extraPayloads, directory2, limits);
  if (sw3400) qualify3400(result, extraPayloads, directory2, limits);
  if (xml2800) qualify2800Headers(result, extraPayloads, limits);
  if (xml6000) {
    const tables = Object.values(result.tables);
    profile6000(tables.length === 1 && tables[0].version === "6000", "single distinct reference carrier required");
    const table = tables[0];
    profile6000(result.stamps && result.definitionType && extraPayloads.has("Keywords"), "intrinsic GUID/stamps/Keywords required");
    result.keywordEvidence = keywords6000(extraPayloads.get("Keywords"), table, limits);
    result.container.semantic.contentManager = await contentManager6000(extraPayloads.get("SwDocContentMgr/SwDocContentMgrInfo"), result, table, ctx, limits);
    if (extraPayloads.has("swXmlContents/MATERIALTREE")) result.container.semantic.material = material6000(extraPayloads.get("swXmlContents/MATERIALTREE"), table, limits);
    const ids = new Set(table.configurations.map((c) => c.swID));
    for (const e of directory2.entries) {
      const m = /(?:^|\/)Config-(\d+)/.exec(e.name);
      profile6000(!m || ids.has(m[1]), "raw configuration cache not in typed roster");
    }
    result.container.semantic.profile = result.tables.COMPINSTANCETREE ? "cfb-v3-xml6000-selected-physical-assembly-v1" : "cfb-v3-xml6000-physical-part-leaf-v1";
  }
  return result;
}

// bridge/solidworks-reference-audit.mjs
var error = (code, message) => Object.assign(new Error(message), { code });
var requireProfile = (ok, message) => {
  if (!ok) throw error("NATIVE_UNSUPPORTED", message);
};
var literal = (value) => typeof value === "string" && value.length > 384 ? `${JSON.stringify(value.slice(0, 384))} [length=${value.length}]` : JSON.stringify(value);
var key = (s) => s.replaceAll("\\", "/").toLowerCase();
var tableOf = (d) => d.meta.tables.COMPINSTANCETREE || d.meta.tables.Features;
var indexed = (t) => ({ files: new Map(t.files.map((f) => [f.id, f])), models: new Map(t.models.map((m) => [m.id, m])) });
var requestOf = (m) => m.swConfigurationName != null && m.swConfigurationId != null ? { name: m.swConfigurationName, id: m.swConfigurationId } : null;
function select(doc, requested) {
  const table = tableOf(doc);
  const semantic = doc.meta.container?.semantic;
  if (!table && (semantic?.profile === "cfb-v3-sw4100-physical-part-leaf-v1" || semantic?.profile === "cfb-v3-sw3400-physical-part-leaf-v1")) {
    const header = semantic.header, configurations = semantic.configurations;
    requireProfile(Array.isArray(configurations) && configurations.length > 0 && semantic.emptyExternalCatalog === true, "SolidWorks legacy PART configuration/catalog metadata is absent");
    const active2 = configurations.filter((c) => c.active);
    requireProfile(active2.length === 1, "No unique active SolidWorks configuration; empty closure was not assumed");
    const chosen = requested ? configurations.find((c) => c.name === requested.name && c.id === requested.id) : active2[0];
    requireProfile(chosen, "Requested SolidWorks configuration is not present in the physical PART roster");
    return { table: null, header, configurations, active: active2[0], configuration: { swName: chosen.name, swID: chosen.id }, model: { id: chosen.id, references: [] }, file: { id: "0", swDocType: "PART", swPath: header.self.path, swCreationTime: header.creation } };
  }
  requireProfile(table, "SolidWorks has no supported typed self/configuration metadata; no empty physical leaf closure was assumed");
  const active = table.configurations.filter((c) => c.swMostRecentConfiguration === "YES");
  requireProfile(active.length === 1, "No unique active SolidWorks configuration; empty closure was not assumed");
  const configuration = active[0], { files, models } = indexed(table), model = models.get(configuration.swModelRef), file = files.get(model.swFileRef);
  requireProfile(typeof configuration.swName === "string" && configuration.swName.length > 0 && typeof configuration.swID === "string" && configuration.swID.length > 0, "SolidWorks active configuration identity is absent");
  requireProfile(table.configurations.filter((c) => c.swName === configuration.swName || c.swID === configuration.swID).length === 1, "SolidWorks active configuration name/ID association is not unique");
  requireProfile(configuration.swName === model.swConfigurationName && configuration.swID === model.swConfigurationId, "SolidWorks configuration/model identity disagreement");
  requireProfile(table.models.filter((m) => m.swFileRef === file.id && m.swConfigurationName === configuration.swName && m.swConfigurationId === configuration.swID).length === 1, "SolidWorks selected configuration/self-model association is not unique");
  if (requested) requireProfile(configuration.swName === requested.name && configuration.swID === requested.id && model.swConfigurationName === requested.name && model.swConfigurationId === requested.id, "Requested SolidWorks configuration is not the unique supported active configuration");
  return { table, configuration, model, file };
}
function intrinsic(doc, requested, token) {
  const own = select(doc, requested), { table, model, file } = own;
  if (!table) {
    const profile = doc.meta.container?.semantic?.profile;
    requireProfile(profile === "cfb-v3-sw4100-physical-part-leaf-v1" || profile === "cfb-v3-sw3400-physical-part-leaf-v1", "Unsupported header-only SolidWorks reference profile");
    const h = own.header, active = own.active;
    requireProfile(doc.depth === 0 && doc.meta.outerVersion === null && doc.meta.container?.kind === "cfb" && doc.meta.container.major === 3 && Object.keys(doc.meta.tables).length === 0 && doc.meta.embeddedMembers.length === 0 && doc.meta.definitionType === "PART" && h?.self?.kind === "PART" && h.catalog.length === 0, "Unsupported legacy PART leaf envelope or non-empty catalog");
    requireProfile(/\.sldprt$/i.test(doc.id) && (h.self.path === "" || /\.sldprt$/i.test(h.self.path)), "SolidWorks physical/member extension contradicts intrinsic document kind");
    if (h.self.path !== "") requireProfile(token(h.self.path), "Unsafe legacy intrinsic self path token");
    requireProfile(doc.meta.stamps && h.self.creation === doc.meta.stamps[0] && h.creation === doc.meta.stamps[0] && (profile === "cfb-v3-sw3400-physical-part-leaf-v1" ? doc.meta.keywords?.Model === h.self.name && doc.meta.keywords?.id == null : h.self.creation === doc.meta.keywords?.id) && h.selectedSave === doc.meta.stamps[1] && active.stamp === doc.meta.stamps[1] && h.save === doc.meta.stamps[2], "Legacy intrinsic creation/ModelStamps/KeyWords disagreement");
    return own;
  }
  if (table.version === "15000") requireProfile(
    doc.depth === 0 && doc.meta.outerVersion === 4 && table === doc.meta.tables.Features && file.swDocType === "PART" && table.files.length === 1 && table.models.length === 1 && table.configurations.length === 1 && model.references.length === 0 && table.externalFeatures.length === 0 && table.rosterEvidence?.externalFeatures.present === true && table.rosterEvidence.externalFeatures.declaredCount === 0 && (!table.rosterEvidence.models.declaredCountPresent || table.rosterEvidence.models.declaredCount === 1) && file.swImportedPath == null && doc.meta.embeddedMembers.length === 0,
    "Unsupported SolidWorks 15000 reference profile; only a physical single-configuration Features leaf without imported/component/feature-source obligations is supported"
  );
  else if (table.version === "4700") requireProfile(
    doc.depth === 0 && doc.meta.outerVersion === null && doc.meta.container?.kind === "cfb" && doc.meta.container.major === 3 && table === doc.meta.tables.Features && file.swDocType === "PART" && table.files.length === 1 && table.models.length === 1 && table.configurations.length === 1 && model.references.length === 0 && table.externalFeatures.length === 0 && table.rosterEvidence?.externalFeatures.present === true && table.rosterEvidence.externalFeatures.declaredCount === 0 && (!table.rosterEvidence.models.declaredCountPresent || table.rosterEvidence.models.declaredCount === 1) && doc.meta.container.semantic.emptyTables === true && doc.meta.container.semantic.explicitEmptyExternalFeatures === true && typeof file.swPath === "string" && !file.swPath.includes("^") && file.swIsVirtualComponent == null && model.swIsVirtualComponent == null && file.swImportedPath == null && doc.meta.embeddedMembers.length === 0,
    "Unsupported cfb-v3-xml4700-physical-part-leaf-v1 reference profile; legacy assemblies, multiple configurations, imported/virtual members and nonempty/absent typed reference rosters are not supported"
  );
  else if (table.version === "2800") {
    requireProfile(doc.depth === 0 && doc.meta.outerVersion === null && doc.meta.container?.kind === "cfb" && doc.meta.container.major === 3 && table === doc.meta.tables.COMPINSTANCETREE && file.swDocType === "ASSEMBLY" && doc.meta.container.semantic.profile === "cfb-v3-xml2800-component-metadata-v1" && doc.meta.embeddedMembers.length === 0, "Unsupported XML2800 physical/component metadata profile");
    const header = doc.meta.container.semantic.header, configuration = doc.meta.container.semantic.configurations.find((c) => c.active);
    requireProfile(header?.self.path === file.swPath && header.self.creation === file.swCreationTime && header.self.kind === file.swDocType && header.selectedSave === model.swLastModifiedStamp && configuration?.name === own.configuration.swName && configuration.id === own.configuration.swID, "XML2800 intrinsic self/configuration/type/save disagreement");
  } else if (table.version === "6000") {
    const assembly = file.swDocType === "ASSEMBLY", profile = assembly ? "cfb-v3-xml6000-selected-physical-assembly-v1" : "cfb-v3-xml6000-physical-part-leaf-v1";
    requireProfile(doc.depth === 0 && doc.meta.outerVersion === null && doc.meta.container?.kind === "cfb" && doc.meta.container.major === 3 && doc.meta.container.semantic.profile === profile && doc.meta.container.semantic.emptyTables === true && doc.meta.container.semantic.explicitEmptyExternalFeatures === true && doc.meta.container.semantic.contentManager?.role === "fully-consumed-redundant-reference-cache" && doc.meta.embeddedMembers.length === 0, `Unsupported ${profile} physical/carrier scope; embedded6000 is not admitted`);
    const { files, models } = indexed(table), selfModels = new Set(table.configurations.map((c) => c.swModelRef));
    requireProfile(table.configurations.every((c) => {
      const m = models.get(c.swModelRef);
      return m.swFileRef === file.id && c.swName === m.swConfigurationName && c.swID === m.swConfigurationId;
    }) && new Set(table.configurations.map((c) => c.swID)).size === table.configurations.length && new Set(table.configurations.map((c) => c.swName)).size === table.configurations.length, "XML6000 all-configuration/self association disagreement");
    requireProfile(table.files.every((f) => f.swImportedPath == null && typeof f.swPath === "string" && !f.swPath.includes("^")), "XML6000 imported/virtual file profile");
    requireProfile(assembly ? table === doc.meta.tables.COMPINSTANCETREE && table.models.every((m) => selfModels.has(m.id) ? m.swFileRef === file.id : files.get(m.swFileRef).swDocType === "PART" && m.references.length === 0) : table === doc.meta.tables.Features && table.files.length === 1 && table.models.length === 1 && table.configurations.length === 1 && model.references.length === 0, "XML6000 only flat physical PART dependencies or a single PART leaf are admitted");
    const self = token(file.swPath), stem = (s) => s.replace(/\.sld(?:prt|asm)$/i, "");
    requireProfile(self && doc.meta.keywords?.Name === stem(self.basename) && own.configuration.swReference === doc.meta.keywords.Name && (model.swName === file.swPath || model.swName === doc.meta.keywords.Name), "XML6000 intrinsic self/model/Keywords identity disagreement");
  } else if (table.version === "4100") {
    requireProfile(doc.depth === 0 && doc.meta.outerVersion === null && doc.meta.container?.kind === "cfb" && doc.meta.container.major === 3 && table === doc.meta.tables.COMPINSTANCETREE && file.swDocType === "ASSEMBLY" && doc.meta.container.semantic.profile === "cfb-v3-xml4100-selected-physical-assembly-v1" && doc.meta.embeddedMembers.length === 0, "Unsupported XML4100 physical/carrier scope");
    requireProfile(table.files.every((f) => f.swImportedPath == null && typeof f.swPath === "string" && !f.swPath.includes("^")), "XML4100 imported/virtual file profile");
  } else requireProfile(table.version === "17000", "Unsupported or missing SolidWorks reference XML version");
  requireProfile(doc.meta.definitionType === file.swDocType && ["PART", "ASSEMBLY"].includes(file.swDocType), "SolidWorks definition type GUID contradicts intrinsic self XML");
  const extension = file.swDocType === "PART" ? /\.sldprt$/i : /\.sldasm$/i;
  requireProfile(extension.test(doc.id) && extension.test(file.swPath), "SolidWorks physical/member extension contradicts intrinsic document kind");
  requireProfile(file.swDocType !== "ASSEMBLY" || doc.meta.tables.COMPINSTANCETREE, "ImportedComp assembly has no component graph");
  requireProfile(file.swDocType !== "PART" || doc.meta.tables.Features, "ImportedComp part has no typed Features metadata");
  requireProfile(token(file.swPath), "Unsafe ImportedComp intrinsic self path token");
  if (file.swImportedPath != null) requireProfile(token(file.swImportedPath), "Unsafe ImportedComp intrinsic imported-path literal");
  requireProfile(doc.meta.stamps && file.swCreationTime === doc.meta.stamps[0] && (table.version === "2800" || file.swCreationTime === doc.meta.keywords?.id), "ImportedComp intrinsic creation/ModelStamps/KeyWords disagreement");
  requireProfile(model.swLastModifiedStamp === doc.meta.stamps[1], "ImportedComp intrinsic save stamp disagreement");
  requireProfile(own.configuration.swName === model.swConfigurationName && own.configuration.swID === model.swConfigurationId, "ImportedComp configuration/model identity disagreement");
  return own;
}
function signatures(table, model, token) {
  const { files, models } = indexed(table), out = /* @__PURE__ */ new Map();
  for (const ref of model.references) {
    const target = models.get(ref.swModelRef), file = files.get(target.swFileRef), path2 = token(file.swPath);
    requireProfile(path2 && ref.swID && ref.swIsVirtualComponent === "NO" && ["YES", "NO"].includes(ref.swSuppressed), "Unsupported imported contextual graph token/virtual/suppression profile");
    requireProfile(!out.has(ref.swID), "Duplicate persistent local ID in imported contextual graph");
    const fields = ["swComponentName", "swName", "swReferenceNumber", "swConfigurationName", "swConfigurationId", "swSuppressed", "swHidden", "swIsVirtualComponent"];
    requireProfile(fields.filter((f) => f !== "swConfigurationId").every((f) => typeof ref[f] === "string"), "Incomplete imported contextual graph identity");
    out.set(ref.swID, { signature: JSON.stringify([fields.map((f) => ref[f] ?? null), ref.localTransform, key(path2.basename), file.swDocType, file.swCreationTime, target.swConfigurationName, target.swConfigurationId, target.swLastModifiedStamp]), ref, model: target, file });
  }
  return out;
}
async function auditSolidWorksReferences(bytes, { name, referenceToken: referenceToken2, limits, requestedConfiguration = null } = {}) {
  const refs = [], unsupported4 = [], embeddedReferenceEvidence = [], externalFeatureEvidence = [];
  const usage = { documents: 0, edges: 0, embeddedBytes: 0 };
  const loaded = /* @__PURE__ */ new Map(), visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set(), admitted = /* @__PURE__ */ new Set();
  function edge() {
    if (++usage.edges > limits.edges) throw error("NATIVE_AUDIT_LIMIT", "SolidWorks global reference edge budget exceeded");
  }
  async function load(id, payload, depth) {
    if (loaded.has(id)) return loaded.get(id);
    if (depth > limits.depth) throw error("NATIVE_AUDIT_LIMIT", "SolidWorks embedded depth budget exceeded");
    if (++usage.documents > limits.documents) throw error("NATIVE_AUDIT_LIMIT", "SolidWorks global document budget exceeded");
    if (depth) {
      usage.embeddedBytes += payload.length;
      if (payload.length > limits.fileBytes || usage.embeddedBytes > limits.totalBytes) throw error("NATIVE_AUDIT_LIMIT", "SolidWorks global embedded input byte budget exceeded");
    }
    const doc = { id, depth, meta: await readSolidWorksMetadata(payload, { name: id, limits, usage }) };
    loaded.set(id, doc);
    for (const table of Object.values(doc.meta.tables)) for (const file of table.files) for (const field of ["swPath", "swImportedPath"]) {
      if (field === "swImportedPath" && file[field] == null) continue;
      if (referenceToken2(file[field])) guard(doc, file[field], `literal-${field}`);
      else unsupported4.push(`${doc.id}: Unsafe original typed SolidWorks ${field} literal ${literal(file[field])}`);
    }
    for (const path2 of doc.meta.legacy2800Paths || []) {
      if (referenceToken2(path2)) guard(doc, path2, "literal-legacy-catalogue");
      else unsupported4.push(`${doc.id}: Unsafe original typed SolidWorks legacy catalogue literal ${literal(path2)}`);
    }
    return doc;
  }
  function guard(doc, token, role = "component") {
    refs.push({ token, embedded: true, owner: doc.id, role });
  }
  async function bind(owner, table, model, file, context2 = null) {
    const source = referenceToken2(file.swPath);
    requireProfile(source, "Unsafe literal imported reference token");
    requireProfile(typeof file.swImportedPath === "string" && referenceToken2(file.swImportedPath), "ImportedComp reference is not explicitly imported or has unsafe imported-path metadata");
    const candidates = owner.meta.embeddedMembers.filter((e) => key(e.name) === key(`ImportedComp/${source.basename}`));
    requireProfile(candidates.length === 1, "Missing or ambiguous ImportedComp directory-backed member");
    const entry = candidates[0], id = `${owner.id}!${entry.name}`, child = await load(id, entry.payload, owner.depth + 1), requested = requestOf(model);
    requireProfile(requested, "ImportedComp requested configuration is absent");
    const own = intrinsic(child, requested, referenceToken2), self = referenceToken2(own.file.swPath);
    requireProfile(key(self.basename) === key(source.basename), "ImportedComp member name contradicts intrinsic self name");
    requireProfile(file.swDocType === own.file.swDocType && file.swCreationTime === own.file.swCreationTime, "ImportedComp incoming type/creation identity mismatch");
    for (const f of ["swConfigurationName", "swConfigurationId", "swLastModifiedStamp"]) requireProfile(model[f] != null && model[f] === own.model[f], `ImportedComp incoming configuration/save stamp mismatch: ${f}`);
    if (context2) requireProfile(context2.file.swPath === own.file.swPath, "Contextual sibling bridge requires exact intrinsic full path");
    if (file.swDocType === "PART") requireProfile(model.references.length === 0 && own.model.references.length === 0, "ImportedComp PART has unsupported contextual/native component children");
    let bridge = null;
    if (file.swDocType === "ASSEMBLY") {
      const pairs = [{ outer: model, inner: own.model }], compared = /* @__PURE__ */ new Set();
      while (pairs.length) {
        const pair = pairs.pop(), pairId = `${pair.outer.id}/${pair.inner.id}`;
        if (compared.has(pairId)) continue;
        compared.add(pairId);
        edge();
        const outer = signatures(table, pair.outer, referenceToken2), inner = signatures(own.table, pair.inner, referenceToken2);
        requireProfile(outer.size === inner.size && [...inner].every(([sid, v]) => outer.get(sid)?.signature === v.signature), "ImportedComp contextual assembly graph disagreement");
        if (pair.outer === model) bridge = new Map([...inner].map(([sid, v]) => [v.ref.id, { owner, table, ...outer.get(sid) }]));
        for (const [sid, value] of inner) pairs.push({ outer: outer.get(sid).model, inner: value.model });
      }
    }
    admitted.add(id);
    if (context2) embeddedReferenceEvidence.push({ owner: owner.id, member: id, fileId: file.id, modelId: model.id, configuration: requested, binding: "intrinsic-self-config-type-stamps", persistentLocalId: null, intrinsicSelfPath: own.file.swPath, geometry: "unverified" });
    embeddedReferenceEvidence.push({ owner: context2?.ownerId || owner.id, member: id, fileId: context2?.file.id || file.id, modelId: context2?.model.id || model.id, configuration: requested, binding: context2 ? "contextual-sibling-graph" : "intrinsic-self-config-type-stamps", persistentLocalId: context2?.persistentLocalId ?? null, intrinsicSelfPath: own.file.swPath, geometry: "unverified" });
    await visit(child, requested, bridge);
    return child;
  }
  async function featureEdges(doc, selected) {
    const table = doc.meta.tables.Features || doc.meta.tables.COMPINSTANCETREE;
    if (!table) return;
    const { files, models } = indexed(table);
    for (const feature of table.externalFeatures) {
      edge();
      const model = models.get(feature.swModelRef), file = files.get(model.swFileRef);
      externalFeatureEvidence.push({ owner: doc.id, featureId: feature.id, modelId: model.id, fileId: file.id, featureType: feature.swFeatureType ?? null, suppressionRaw: feature.swSuppressed ?? null, sourceRequired: true, sourceToken: file.swPath ?? null, geometry: "unverified" });
      if (table.version !== "17000" || feature.swFeatureType !== "MBimport" || feature.swSuppressed !== "0" || feature.swConfigurationName !== selected?.configuration.swName) unsupported4.push(`${doc.id}: Unsupported external-feature type/version/suppression/configuration profile; declared feature-source remains required`);
      const token = referenceToken2(file.swPath);
      if (!token) {
        unsupported4.push(`${doc.id}: Unsafe declared feature-source literal: ${JSON.stringify(file.swPath)}`);
        continue;
      }
      refs.push({ token: file.swPath, owner: doc.id, role: "feature-source", configuration: null });
      if (model.references.length) unsupported4.push(`${doc.id}: Unsupported typed feature-source model child graph: feature ${feature.id}, model ${model.id}, ${model.references.length} direct children; descendant obligations are unverified`);
    }
  }
  async function walk(doc, table, start, bridge) {
    const { files, models } = indexed(table), work = [{ model: start, depth: 0 }];
    while (work.length) {
      const item = work.pop();
      if (item.depth > limits.depth) throw error("NATIVE_AUDIT_LIMIT", "SolidWorks occurrence depth budget exceeded");
      for (const ref of item.model.references) {
        const suppressed = table.version === "4100" && ref.swSuppressed == null ? "NO" : ref.swSuppressed;
        edge();
        if (suppressed === "YES") continue;
        const model = models.get(ref.swModelRef), file = files.get(model.swFileRef), token = referenceToken2(file.swPath);
        if (suppressed !== "NO") unsupported4.push(`${doc.id}: Unknown SolidWorks component suppression ${JSON.stringify(ref.swSuppressed)}`);
        if (!token) {
          unsupported4.push(`${doc.id}: Unsafe literal SolidWorks reference ${JSON.stringify(file.swPath)}`);
          continue;
        }
        guard(doc, file.swPath);
        if (!["PART", "ASSEMBLY"].includes(file.swDocType)) {
          unsupported4.push(`${doc.id}: Unsupported SolidWorks component type`);
          continue;
        }
        if (ref.swIsVirtualComponent === "YES" || token.basename.includes("^")) {
          unsupported4.push(`${doc.id}: Unverified virtual SolidWorks component`);
          continue;
        }
        if (ref.swIsVirtualComponent != null && ref.swIsVirtualComponent !== "NO") unsupported4.push(`${doc.id}: Unsupported SolidWorks virtual flag`);
        const unset4100Cfg = table.version === "4100" && ref.swConfigurationName === "" && ref.swConfigurationId === "-1";
        if (!unset4100Cfg && (ref.swConfigurationName != null && ref.swConfigurationName !== model.swConfigurationName || ref.swConfigurationId != null && ref.swConfigurationId !== model.swConfigurationId)) unsupported4.push(`${doc.id}: Component/reference requested configuration disagreement`);
        const local = doc.meta.embeddedMembers.some((e) => key(e.name) === key(`ImportedComp/${token.basename}`));
        const context2 = bridge?.get(ref.id);
        let embeddedBound = false;
        if (local || file.swImportedPath || context2) {
          try {
            if (context2 && !local) await bind(context2.owner, context2.table, context2.model, context2.file, { ownerId: doc.id, file, model, persistentLocalId: ref.swID });
            else await bind(doc, table, model, file);
            embeddedBound = true;
          } catch (e) {
            if (e.code !== "NATIVE_UNSUPPORTED") throw e;
            unsupported4.push(`${doc.id}: ImportedComp binding refused: ${e.message}`);
          }
        } else refs.push({ token: file.swPath, owner: doc.id, role: "component", configuration: requestOf(model) });
        if (!embeddedBound && model.references.length) work.push({ model, depth: item.depth + 1 });
      }
    }
  }
  async function visit(doc, requested, bridge = null) {
    let selected;
    requireProfile(Object.keys(doc.meta.tables).length <= 1, "Simultaneous Features/COMPINSTANCETREE ownership profile is unsupported");
    try {
      selected = intrinsic(doc, requested, referenceToken2);
    } catch (e) {
      if (e.code !== "NATIVE_UNSUPPORTED") throw e;
      unsupported4.push(`${doc.id}: ${e.message}`);
      return;
    }
    const identity = `${doc.id}\0${selected?.configuration.id ?? ""}\0${selected?.model.id ?? ""}`;
    requireProfile(!active.has(identity), "Cycle in recursively bound ImportedComp documents");
    if (visited.has(identity)) return;
    active.add(identity);
    try {
      if (doc.meta.container?.semantic.referenceClosure?.complete === false) unsupported4.push(`${doc.id}: ${doc.meta.container.semantic.referenceClosure.reason}`);
      if (selected?.table) {
        await walk(doc, selected.table, selected.model, bridge);
      }
      await featureEdges(doc, selected);
      visited.add(identity);
    } finally {
      active.delete(identity);
    }
  }
  let root;
  try {
    root = await load(name, bytes, 0);
    await visit(root, requestedConfiguration);
  } catch (e) {
    e.usage = { ...usage };
    throw e;
  }
  for (const doc of loaded.values()) for (const e of doc.meta.embeddedMembers) if (!admitted.has(`${doc.id}!${e.name}`)) unsupported4.push(`${doc.id}: Unbound or unsupported ImportedComp/virtual member ${JSON.stringify(e.name)}`);
  const kind = { PART: "part", ASSEMBLY: "assembly" }[root.meta.definitionType] || "unknown";
  const unique = (rows) => [...new Map(rows.map((row) => [JSON.stringify(row), row])).values()];
  return { kind, refs, unsupported: unsupported4, usage, embeddedReferenceEvidence: unique(embeddedReferenceEvidence), externalFeatureEvidence: unique(externalFeatureEvidence) };
}

// bridge/step-reference-audit.mjs
import { createHash } from "node:crypto";
var digest = (value) => createHash("sha256").update(value).digest("hex");
var diagnostic = (message) => {
  if (message.length <= 512) return message;
  const tail = `... [${message.length} characters; sha256 ${digest(message)}]`;
  return message.slice(0, 512 - tail.length) + tail;
};
var symbol = (value) => value.length <= 96 ? value : `${value.slice(0, 96)}... [${value.length} characters; sha256 ${digest(value)}]`;
var fail2 = (message) => {
  throw Object.assign(new Error(diagnostic(`STEP feature-source: ${message}`)), { code: "NATIVE_MALFORMED" });
};
var unsupported3 = (message) => {
  throw Object.assign(new Error(diagnostic(`STEP feature-source: ${message}`)), { code: "NATIVE_UNSUPPORTED" });
};
var limit = (message) => {
  throw Object.assign(new Error(diagnostic(`STEP feature-source ${message} budget exceeded`)), { code: "NATIVE_AUDIT_LIMIT" });
};
var SIMPLE = { ADVANCED_BREP_SHAPE_REPRESENTATION: 3, ADVANCED_FACE: 4, APPLICATION_CONTEXT: 1, APPLICATION_PROTOCOL_DEFINITION: 4, APPROVAL: 2, APPROVAL_DATE_TIME: 2, APPROVAL_PERSON_ORGANIZATION: 3, APPROVAL_ROLE: 1, APPROVAL_STATUS: 1, AXIS2_PLACEMENT_3D: 4, B_SPLINE_CURVE_WITH_KNOTS: 9, B_SPLINE_SURFACE_WITH_KNOTS: 13, CALENDAR_DATE: 3, CARTESIAN_POINT: 2, CC_DESIGN_APPROVAL: 2, CC_DESIGN_DATE_AND_TIME_ASSIGNMENT: 3, CC_DESIGN_PERSON_AND_ORGANIZATION_ASSIGNMENT: 3, CC_DESIGN_SECURITY_CLASSIFICATION: 2, CIRCLE: 3, CLOSED_SHELL: 2, CONICAL_SURFACE: 4, CONTEXT_DEPENDENT_SHAPE_REPRESENTATION: 2, COORDINATED_UNIVERSAL_TIME_OFFSET: 3, DATE_AND_TIME: 2, DATE_TIME_ROLE: 1, DESIGN_CONTEXT: 3, DIRECTION: 2, EDGE_CURVE: 5, EDGE_LOOP: 2, FACE_BOUND: 3, FACE_OUTER_BOUND: 3, ITEM_DEFINED_TRANSFORMATION: 4, LINE: 3, LOCAL_TIME: 4, MANIFOLD_SOLID_BREP: 2, MECHANICAL_CONTEXT: 3, NEXT_ASSEMBLY_USAGE_OCCURRENCE: 6, ORGANIZATION: 3, ORIENTED_EDGE: 5, PERSON: 6, PERSON_AND_ORGANIZATION: 2, PERSON_AND_ORGANIZATION_ROLE: 1, PLANE: 2, PRODUCT: 4, PRODUCT_DEFINITION: 4, PRODUCT_DEFINITION_FORMATION_WITH_SPECIFIED_SOURCE: 4, PRODUCT_DEFINITION_SHAPE: 3, PRODUCT_RELATED_PRODUCT_CATEGORY: 3, SECURITY_CLASSIFICATION: 3, SECURITY_CLASSIFICATION_LEVEL: 1, SHAPE_DEFINITION_REPRESENTATION: 2, SHAPE_REPRESENTATION: 3, SHAPE_REPRESENTATION_RELATIONSHIP: 4, UNCERTAINTY_MEASURE_WITH_UNIT: 4, VECTOR: 3, VERTEX_POINT: 2 };
var COMPLEX = { BOUNDED_CURVE: 0, BOUNDED_SURFACE: 0, B_SPLINE_CURVE: 5, B_SPLINE_CURVE_WITH_KNOTS: 3, B_SPLINE_SURFACE: 7, B_SPLINE_SURFACE_WITH_KNOTS: 5, CURVE: 0, GEOMETRIC_REPRESENTATION_CONTEXT: 1, GEOMETRIC_REPRESENTATION_ITEM: 0, GLOBAL_UNCERTAINTY_ASSIGNED_CONTEXT: 1, GLOBAL_UNIT_ASSIGNED_CONTEXT: 1, LENGTH_UNIT: 0, NAMED_UNIT: 1, PLANE_ANGLE_UNIT: 0, RATIONAL_B_SPLINE_CURVE: 1, RATIONAL_B_SPLINE_SURFACE: 1, REPRESENTATION_CONTEXT: 2, REPRESENTATION_ITEM: 1, REPRESENTATION_RELATIONSHIP: 4, REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION: 1, SHAPE_REPRESENTATION_RELATIONSHIP: 0, SI_UNIT: 2, SOLID_ANGLE_UNIT: 0, SURFACE: 0 };
var groups = [
  ["BOUNDED_CURVE", "B_SPLINE_CURVE", "B_SPLINE_CURVE_WITH_KNOTS", "CURVE", "GEOMETRIC_REPRESENTATION_ITEM", "RATIONAL_B_SPLINE_CURVE", "REPRESENTATION_ITEM"],
  ["BOUNDED_SURFACE", "B_SPLINE_SURFACE", "B_SPLINE_SURFACE_WITH_KNOTS", "GEOMETRIC_REPRESENTATION_ITEM", "RATIONAL_B_SPLINE_SURFACE", "REPRESENTATION_ITEM", "SURFACE"],
  ["GEOMETRIC_REPRESENTATION_CONTEXT", "GLOBAL_UNCERTAINTY_ASSIGNED_CONTEXT", "GLOBAL_UNIT_ASSIGNED_CONTEXT", "REPRESENTATION_CONTEXT"],
  ["REPRESENTATION_RELATIONSHIP", "REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION", "SHAPE_REPRESENTATION_RELATIONSHIP"],
  ...["LENGTH_UNIT", "PLANE_ANGLE_UNIT", "SOLID_ANGLE_UNIT"].map((u) => [u, "NAMED_UNIT", "SI_UNIT"])
].map((g) => g.sort().join("|"));
function auditStepReferences(bytes, { limits = {} } = {}) {
  const bounds = { fileBytes: 64 * 1024 * 1024, stepRecords: 2e5, stepTokens: 4e6, stepReferences: 2e6, stepString: 4096, stepTokenLength: 4096, depth: 64, ...limits };
  if (bytes.length > bounds.fileBytes) limit("input byte");
  if (bytes.some((b) => b > 126 || b < 32 && ![9, 10, 13].includes(b))) unsupported3("non-ASCII/control-bearing P21 encoding");
  const text = new TextDecoder("ascii").decode(bytes);
  let p = 0, look = null, tokens = 0, references = 0, records = 0;
  const ids = /* @__PURE__ */ new Set(), targets = /* @__PURE__ */ new Set(), types = /* @__PURE__ */ new Map();
  function token(value2, start) {
    if (value2.length > bounds.stepTokenLength) limit(`token length (${value2.length} characters at byte ${start}; sha256 ${digest(value2)})`);
    return value2;
  }
  const boundary = (at, extra = "") => at === text.length || /[ \t\r\n,);]/.test(text[at]) || extra.includes(text[at]) || text.startsWith("/*", at);
  function lex() {
    while (p < text.length) {
      if (/[ \t\r\n]/.test(text[p])) {
        p++;
        continue;
      }
      if (text.startsWith("/*", p)) {
        const end = text.indexOf("*/", p + 2);
        if (end < 0 || text.slice(p + 2, end).includes("/*")) fail2("invalid P21 comment");
        p = end + 2;
        continue;
      }
      break;
    }
    if (++tokens > bounds.stepTokens) limit("token");
    if (p === text.length) return { type: "eof", value: "" };
    const start = p, ch = text[p++];
    if ("(),;=$*".includes(ch)) return { type: ch, value: ch };
    if (ch === "'") {
      let s = "";
      while (p < text.length) {
        const c = text[p++];
        if (c === "'") {
          if (text[p] === "'") {
            p++;
            s += "'";
          } else return { type: "string", value: s };
        } else {
          if (c === "\\") unsupported3("escaped P21 strings are outside this bounded reference profile");
          if (c < " ") fail2("control inside P21 string");
          s += c;
        }
        if (s.length > bounds.stepString) limit("string length");
      }
      fail2("unterminated P21 string");
    }
    if (ch === "#") {
      const m = /^[1-9]\d*/.exec(text.slice(p));
      if (!m) fail2("invalid P21 instance identity");
      p += m[0].length;
      token(text.slice(start, p), start);
      if (!boundary(p, "=")) fail2(`invalid P21 instance identity suffix at byte ${p}`);
      if (m[0].length > 16 || m[0].length === 16 && m[0] > "9007199254740991") fail2("oversized P21 instance identity");
      return { type: "ref", value: m[0] };
    }
    if (ch === "." && /[A-Z]/.test(text[p] ?? "")) {
      const m = /^[A-Z][A-Z0-9_]*\./.exec(text.slice(p));
      if (!m) fail2("invalid P21 enumeration");
      p += m[0].length;
      token(text.slice(start, p), start);
      return { type: "enum", value: m[0].slice(0, -1) };
    }
    const number = /^[+-]?\d+(?:\.\d*(?:E[+-]?\d+)?)?/.exec(text.slice(start));
    if (number) {
      p = start + number[0].length;
      token(number[0], start);
      if (!boundary(p)) fail2(`invalid P21 numeric suffix at byte ${p}`);
      const value2 = Number(number[0]);
      if (!Number.isFinite(value2)) fail2("nonfinite P21 number");
      return { type: "number", value: value2 };
    }
    const word = /^[A-Z][A-Z0-9_-]*/.exec(text.slice(start));
    if (word) {
      p = start + word[0].length;
      return { type: "word", value: token(word[0], start) };
    }
    fail2(`unexpected P21 token at byte ${start}`);
  }
  const peek = () => look ??= lex();
  const pop = () => {
    const t = peek();
    look = null;
    return t;
  };
  const take = (type, value2) => {
    const t = pop();
    if (t.type !== type || value2 != null && t.value !== value2) fail2(`expected ${value2 ?? type} at byte ${p}`);
    return t.value;
  };
  function list(depth = 0) {
    if (depth > bounds.depth) limit("nesting depth");
    take("(");
    const out = [];
    if (peek().type !== ")") while (true) {
      out.push(value(depth + 1));
      if (peek().type !== ",") break;
      pop();
    }
    take(")");
    return out;
  }
  function value(depth) {
    if (depth > bounds.depth) limit("nesting depth");
    const t = peek();
    if (t.type === "(") return list(depth);
    pop();
    if (["string", "number", "enum", "$", "*"].includes(t.type)) return { kind: t.type, value: t.value };
    if (t.type === "ref") {
      if (++references > bounds.stepReferences) limit("reference count");
      targets.add(t.value);
      return { kind: "ref", value: t.value };
    }
    if (t.type === "word") {
      if (t.value !== "LENGTH_MEASURE") unsupported3(`unknown P21 typed value ${symbol(t.value)}`);
      const args = list(depth);
      if (args.length !== 1 || args[0].kind !== "number") fail2("malformed LENGTH_MEASURE");
      return { kind: "typed", value: t.value, args };
    }
    fail2("malformed P21 parameter");
  }
  function entity(complex = false) {
    const type = take("word"), args = list();
    const expected = (complex ? COMPLEX : SIMPLE)[type];
    if (expected == null) unsupported3(`unknown/external-reference entity ${symbol(type)}`);
    if (args.length !== expected) fail2(`wrong ${type} parameter count`);
    if (["CARTESIAN_POINT", "DIRECTION"].includes(type) && (!Array.isArray(args[1]) || args[1].length < 2 || args[1].length > 3 || args[1].some((v) => v.kind !== "number"))) fail2(`malformed ${type} coordinate list`);
    types.set(type, (types.get(type) || 0) + 1);
    return type;
  }
  take("word", "ISO-10303-21");
  take(";");
  take("word", "HEADER");
  take(";");
  const headers = {};
  for (const name of ["FILE_DESCRIPTION", "FILE_NAME", "FILE_SCHEMA"]) {
    take("word", name);
    headers[name] = list();
    take(";");
  }
  const string = (v) => v?.kind === "string";
  const strings = (v) => Array.isArray(v) && v.every(string);
  const description = headers.FILE_DESCRIPTION, filename = headers.FILE_NAME, schema = headers.FILE_SCHEMA;
  if (description.length !== 2 || !strings(description[0]) || !string(description[1])) fail2("malformed FILE_DESCRIPTION");
  if (!["1", "2;1"].includes(description[1].value)) unsupported3("unsupported P21 implementation level/version");
  if (filename.length !== 7 || ![0, 1, 4, 5, 6].every((i) => string(filename[i])) || !strings(filename[2]) || !strings(filename[3])) fail2("malformed FILE_NAME");
  if (schema.length !== 1 || !strings(schema[0]) || schema[0].length !== 1 || schema[0][0].value !== "CONFIG_CONTROL_DESIGN") unsupported3("only CONFIG_CONTROL_DESIGN AP203 is admitted");
  if (targets.size) fail2("instance references are not admitted in the P21 header");
  take("word", "ENDSEC");
  take(";");
  take("word", "DATA");
  take(";");
  while (peek().type === "ref") {
    const id = take("ref");
    if (ids.has(id)) fail2("duplicate P21 instance identity");
    ids.add(id);
    if (++records > bounds.stepRecords) limit("record count");
    take("=");
    if (peek().type === "(") {
      pop();
      const group = [];
      while (peek().type === "word") {
        if (group.length && peek().value <= group.at(-1)) fail2("complex P21 partial-entity names must be unique and ascending");
        group.push(entity(true));
      }
      take(")");
      if (!groups.includes(group.join("|"))) unsupported3("unsupported complex P21 entity profile");
    } else entity();
    take(";");
  }
  if (!records) fail2("empty P21 DATA section");
  take("word", "ENDSEC");
  take(";");
  take("word", "END-ISO-10303-21");
  take(";");
  take("eof");
  for (const id of targets) if (!ids.has(id)) fail2(`dangling P21 instance reference #${id}`);
  return { kind: "neutral-feature-source", refs: [], unsupported: [], usage: { documents: 1, edges: 0, embeddedBytes: 0 }, neutralReferenceEvidence: [{ profile: "AP203-CONFIG_CONTROL_DESIGN-self-contained/1", records, referenceCount: references, entityTypes: [...types.keys()].sort(), externalReferences: [], geometry: "unverified", expressConformance: "unverified", headerFileName: filename[0].value }] };
}

// bridge/native-source-audit.mjs
var MiB = 1024 * 1024;
var LIMIT = { entries: 4096, depth: 64, documents: 1024, fileBytes: 64 * MiB, totalBytes: 512 * MiB, edges: 1e5, inflatedBytes: 256 * MiB, workerMs: 3e4, totalMs: 12e4 };
var issue4 = (code, message) => Object.assign(new Error(message), { code });
var refused = (message) => issue4("NATIVE_AUDIT_LIMIT", message);
var slash = (s) => s.replaceAll("\\", "/");
var key2 = (s) => slash(s).toLowerCase();
var within = (root, target) => {
  const r = path.relative(root, target);
  return r === "" || !r.startsWith(`..${path.sep}`) && r !== ".." && !path.isAbsolute(r);
};
var cadName = (s) => /\.(?:prt|sldprt|sldasm|step|stp)$/i.test(s);
var unc = (s) => /^[\\/]{2}|^[\\/]\?\?|^[\\/]\?/.test(s);
function referenceToken(value) {
  if (typeof value !== "string" || !value || value.length > 4096 || /[\u0000-\u001f\u007f-\u009f]/u.test(value) || unc(value)) return null;
  const s = slash(value), drive = /^[A-Za-z]:\//.test(s), absolute = drive || s.startsWith("/");
  if (!drive && s.includes(":") || value.startsWith("\\") && !drive) return null;
  const tail = drive ? s.slice(3) : s.startsWith("/") ? s.slice(1) : s, parts = tail.split("/");
  if (parts.some((p) => !p || p === "." || p === ".." || /[<>:"|?*]/u.test(p) || /[ .]$/.test(p) || /^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(p))) return null;
  return { value, s, parts, basename: parts.at(-1), absolute, drive };
}
async function noLinks(absolute) {
  if (unc(absolute)) throw issue4("NATIVE_AUDIT_INPUT", "UNC/device paths are not admitted");
  const parsed = path.parse(absolute);
  let p = parsed.root;
  for (const part of absolute.slice(parsed.root.length).split(path.sep).filter(Boolean)) {
    p = path.join(p, part);
    const st = await lstat(p);
    if (st.isSymbolicLink()) throw issue4("NATIVE_AUDIT_INPUT", `Symlink/junction is not admitted: ${p}`);
  }
}
async function externalExists(token, sourceRoot) {
  if (!token.absolute || token.drive && process.platform !== "win32") return false;
  const absolute = path.resolve(token.s);
  if (within(sourceRoot, absolute)) return false;
  const parsed = path.parse(absolute);
  let p = parsed.root;
  for (const part of absolute.slice(parsed.root.length).split(path.sep).filter(Boolean)) {
    p = path.join(p, part);
    try {
      if ((await lstat(p)).isSymbolicLink()) return true;
    } catch (e) {
      if (e.code === "ENOENT" || e.code === "ENOTDIR") return false;
      throw e;
    }
  }
  return true;
}
function nxLeafProfile(bytes, stream) {
  if (!stream) return false;
  try {
    const b = bytes.subarray(stream.offset, stream.offset + stream.storedBytes), c = new NativeCursor(b, "NX10 leaf profile", 16);
    if (c.u32(false) !== 10) return false;
    c.take(11);
    if (nativeText(c.take(c.count(1))) !== "x64/Windows NT") return false;
    const sourceName = nativeText(c.take(c.count(1)));
    if (!referenceToken(sourceName) || /[\\/]/.test(sourceName) || !/\.prt$/i.test(sourceName)) return false;
    if ([3, 1, 0, 15, 0, 0, 0, 0, b.length - 24].some((n) => c.u32() !== n) || c.u8() !== 6) return false;
    const classes = [["UGS::OM::Meta", 2], ["UGS::Assy::StructureDescription::SaveData", 18], ["UGS::Assy::StructureDescription::PartHints", 2], ["UGS::Assy::StructureDescription::EntityTypeAndLayerInfo", 2], ["UGS::OM_maps", 23]];
    for (const [name, version] of classes) {
      const n = c.u8();
      if (n < 2 || nativeText(c.take(n - 1)) !== name || c.u8() !== version) return false;
    }
    return true;
  } catch (e) {
    if (e.code === "NATIVE_MALFORMED") return false;
    throw e;
  }
}
function nxMetadata(bytes, r) {
  const refs = [], unsupported4 = [], structure2 = r.streams.find((s) => s.name === "/Root/FastLoad/Structure");
  const kind = r.roster ? "assembly" : nxLeafProfile(bytes, structure2) ? "part" : "unknown";
  if (kind === "unknown") unsupported4.push("NX occurrence/leaf reference profile is unknown; no empty closure was assumed");
  if (kind === "part" && r.streams.some((s) => s.name === "/Root/part/arrangements")) unsupported4.push("NX leaf profile conflicts with assembly arrangements");
  if (r.roster) for (const occurrence of r.roster.occurrences) {
    const prototype = r.roster.prototypes[occurrence.prototypeIndex - 1];
    if (!referenceToken(prototype) || /[\\/]/.test(prototype) || prototype.includes(".") && !/\.prt$/i.test(prototype)) {
      unsupported4.push(`Unsupported literal NX prototype: ${JSON.stringify(prototype)}`);
      continue;
    }
    refs.push({ token: /\.prt$/i.test(prototype) ? prototype : `${prototype}.prt` });
  }
  const streams = r.streams.filter((s) => s.name === "/Root/FastLoad/ExternalReferences" || s.name === "/Root/UG_PART/ExternalReferences");
  if (!streams.length) unsupported4.push("NX external-reference stream is absent; external requirements are unknown");
  for (const s of streams) {
    const parsed = r.externalReferenceStreams.find((p) => p.streamName === s.name);
    if (!parsed) {
      unsupported4.push(`Unsupported NX external-reference stream: ${s.name}`);
      continue;
    }
    for (const record of parsed.records) {
      if (record.kind === "empty") continue;
      const ref = r.references.find((v) => v.streamName === s.name && v.recordId === record.id);
      if (record.kind !== "handle-set" || !ref) unsupported4.push(`Unsupported NX external-reference record: ${s.name}:${record.id}`);
    }
  }
  for (const ref of r.references) {
    const dir = ref.directory;
    if (!referenceToken(ref.name) || /[\\/]/.test(ref.name) || dir && !referenceToken(`${dir}${/[\\/]$/.test(dir) ? "" : "/"}__audit__.prt`)) {
      unsupported4.push(`Unsupported literal NX reference slots: ${JSON.stringify([ref.name, dir])}`);
      continue;
    }
    refs.push({ token: ref.sourcePath });
  }
  return { kind, refs, unsupported: unsupported4 };
}
async function parseWorker() {
  let inflated = 0;
  const limits = workerData.limits;
  const NativeStream = globalThis.DecompressionStream;
  globalThis.DecompressionStream = class {
    constructor(format) {
      const stream = new NativeStream(format);
      this.writable = stream.writable;
      this.readable = stream.readable.pipeThrough(new TransformStream({ transform(chunk, controller) {
        inflated += chunk.byteLength;
        if (inflated > limits.inflatedBytes) throw refused("Global native decompression byte budget exceeded");
        controller.enqueue(chunk);
      } }));
    }
  };
  try {
    const bytes = new Uint8Array(workerData.bytes), format = workerData.format;
    if (format === "nx" && Buffer.from(bytes.subarray(0, 8)).toString("ascii") !== "SPLMSSTR") {
      parentPort.postMessage({ result: { kind: "unknown", refs: [], unsupported: ["Not an NX SPLMSSTR signature; a .prt extension does not identify NX (e.g. Creo)"] } });
      return;
    }
    let result;
    if (format === "solidworks") result = await auditSolidWorksReferences(bytes, { name: workerData.name, limits, referenceToken, requestedConfiguration: workerData.requestedConfiguration });
    else if (format === "step") result = auditStepReferences(bytes, { limits });
    else {
      const r = await readNX(bytes, { name: workerData.name });
      if (r.components.length > limits.edges) throw refused("Native component budget exceeded");
      result = nxMetadata(bytes, r);
    }
    result.usage = { documents: 1, edges: 0, embeddedBytes: 0, ...result.usage, inflatedBytes: inflated };
    parentPort.postMessage({ result });
  } catch (e) {
    parentPort.postMessage({ error: { code: inflated > limits.inflatedBytes ? "NATIVE_AUDIT_LIMIT" : e.code || "NATIVE_AUDIT_INTERNAL", message: inflated > limits.inflatedBytes ? "Global native decompression byte budget exceeded" : e.message, usage: { documents: 1, edges: 0, embeddedBytes: 0, ...e.usage, inflatedBytes: inflated } } });
  }
}
async function metadata(bytes, name, format, remainingMs, limits, requestedConfiguration = null) {
  const data = new Uint8Array(bytes.length);
  data.set(bytes);
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL(import.meta.url), { workerData: { nativeSourceAuditWorker: true, bytes: data.buffer, name, format, limits, requestedConfiguration }, transferList: [data.buffer], resourceLimits: { maxOldGenerationSizeMb: 256, maxYoungGenerationSizeMb: 32 }, execArgv: [] });
    let settled = false;
    const finish = (error2, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      worker.terminate().then(() => error2 ? reject(error2) : resolve(result), reject);
    };
    const timer = setTimeout(() => finish(refused("Native metadata parser time budget exceeded")), Math.max(1, Math.min(LIMIT.workerMs, remainingMs)));
    worker.once("message", (m) => m.error ? finish(Object.assign(issue4(m.error.code, m.error.message), { usage: m.error.usage })) : finish(null, m.result));
    worker.once("error", (e) => finish(e.code === "ERR_WORKER_OUT_OF_MEMORY" ? refused("Native metadata parser heap budget exceeded") : e));
    worker.once("exit", (code) => {
      if (!settled) finish(issue4("NATIVE_AUDIT_INTERNAL", `Native metadata worker exited without a result (${code})`));
    });
  });
}
async function auditNativeSources({ primaryPath, sourceRoot } = {}) {
  for (const [label, value] of Object.entries({ primaryPath, sourceRoot })) {
    if (typeof value !== "string" || !value || unc(value) || !path.isAbsolute(value) || /[\u0000-\u001f]/.test(value)) throw issue4("NATIVE_AUDIT_INPUT", `${label} must be an absolute local path`);
  }
  sourceRoot = path.resolve(sourceRoot);
  primaryPath = path.resolve(primaryPath);
  if (!within(sourceRoot, primaryPath)) throw issue4("NATIVE_AUDIT_INPUT", "Primary input is outside sourceRoot");
  await noLinks(sourceRoot);
  await noLinks(primaryPath);
  if (!(await lstat(sourceRoot)).isDirectory() || !(await lstat(primaryPath)).isFile()) throw issue4("NATIVE_AUDIT_INPUT", "Expected a regular primary file and directory sourceRoot");
  const sourceFormat = /\.sld(?:prt|asm)$/i.test(primaryPath) ? "solidworks" : /\.prt$/i.test(primaryPath) ? "nx" : null;
  if (!sourceFormat) throw issue4("NATIVE_AUDIT_INPUT", "Expected a SolidWorks file or content-identified NX .prt");
  const rootReal = await realpath(sourceRoot);
  if (!within(rootReal, await realpath(primaryPath))) throw issue4("NATIVE_AUDIT_INPUT", "Primary input escapes the real sourceRoot");
  const result = { schema: "p3dw.native-source-audit/1", sourceFormat, documentKind: "unknown", primaryRelativePath: slash(path.relative(sourceRoot, primaryPath)), requiredSourcePaths: [], unresolvedExternalReferences: [], ambiguousExternalReferences: [], unsupportedReferenceAudits: [], externalExistingReferences: [], complete: false };
  Object.assign(result, { coverage: { scope: "bounded-reference-input-metadata", geometry: "unverified", exactBrep: "unverified", allConfigurations: "unverified", featureRegeneration: "unverified" }, embeddedReferenceEvidence: [], externalFeatureEvidence: [], neutralReferenceEvidence: [] });
  const unsupported4 = (s) => result.unsupportedReferenceAudits.push(s), files = [], byPath = /* @__PURE__ */ new Map(), byBase = /* @__PURE__ */ new Map();
  const started = Date.now(), pending = [{ absolute: sourceRoot, relative: "", depth: 0 }];
  let entries = 0;
  try {
    while (pending.length) {
      const dir = pending.pop();
      if (dir.depth > LIMIT.depth) throw refused("Provided source directory depth budget exceeded");
      for await (const entry of await opendir(dir.absolute)) {
        if (Date.now() - started > LIMIT.totalMs) throw refused("Source reference audit total time budget exceeded");
        const name = entry.name;
        if (++entries > LIMIT.entries) throw refused("Provided source inventory entry budget exceeded");
        const relative = dir.relative ? `${dir.relative}/${name}` : name, absolute = path.join(dir.absolute, name), st = await lstat(absolute);
        if (st.isSymbolicLink()) {
          unsupported4(`Provided symlink/junction is not followed: ${relative}`);
          continue;
        }
        if (st.isDirectory()) {
          pending.push({ absolute, relative, depth: dir.depth + 1 });
          continue;
        }
        if (!st.isFile() || !cadName(name)) continue;
        if (!referenceToken(relative)) {
          unsupported4(`Provided source filename is unsafe: ${JSON.stringify(relative)}`);
          continue;
        }
        const f = { absolute, relative, st };
        files.push(f);
        for (const [map, k] of [[byPath, key2(relative)], [byBase, key2(name)]]) {
          if (!map.has(k)) map.set(k, []);
          map.get(k).push(f);
        }
      }
    }
  } catch (e) {
    if (e.code !== "NATIVE_AUDIT_LIMIT") throw e;
    unsupported4(e.message);
  }
  const main2 = files.find((f) => f.relative === result.primaryRelativePath);
  if (!main2) {
    unsupported4("Primary input was not admitted to the bounded provided-source inventory");
    result.unsupportedReferenceAudits = [...new Set(result.unsupportedReferenceAudits)].sort();
    return result;
  }
  const queue = [main2], seen = /* @__PURE__ */ new Set();
  let totalBytes = 0, edges = 0, documents = 0, inflatedBytes = 0;
  const account = (usage) => {
    documents += usage.documents ?? 1;
    edges += usage.edges ?? 0;
    inflatedBytes += usage.inflatedBytes ?? 0;
    totalBytes += usage.embeddedBytes ?? 0;
  };
  const identity = (f) => `${f.relative}\0${JSON.stringify(f.configuration ?? null)}`;
  const checkTime = () => {
    if (Date.now() - started > LIMIT.totalMs) throw refused("Source reference audit total time budget exceeded");
  };
  async function resolveReference(owner, ref) {
    checkTime();
    if (++edges > LIMIT.edges) throw refused("Source reference edge budget exceeded");
    const label = `${ref.owner || owner.relative} -> ${ref.role === "feature-source" ? "feature-source " : ""}${JSON.stringify(ref.token)}`, token = referenceToken(ref.token);
    if (!token) {
      unsupported4(`Unsafe/unsupported reference token: ${label}`);
      return;
    }
    try {
      if (await externalExists(token, sourceRoot)) result.externalExistingReferences.push(label);
    } catch (e) {
      unsupported4(`Cannot safely determine external path existence (${e.code || "I/O"}): ${label}`);
    }
    if (ref.embedded) return;
    if (!cadName(token.basename)) {
      unsupported4(`Unsupported native reference extension: ${label}`);
      return;
    }
    if (/\.(?:step|stp)$/i.test(token.basename) && ref.role !== "feature-source") {
      unsupported4(`STEP is admitted only as a declared feature-source, never substitute native geometry: ${label}`);
      return;
    }
    let candidates = [];
    if (token.absolute) {
      if ((!token.drive || process.platform === "win32") && within(sourceRoot, path.resolve(token.s))) candidates = byPath.get(key2(slash(path.relative(sourceRoot, path.resolve(token.s))))) || [];
    } else {
      const sibling = slash(path.posix.join(path.posix.dirname(owner.relative), token.s));
      candidates = byPath.get(key2(sibling)) || byPath.get(key2(token.s)) || [];
    }
    if (!candidates.length) candidates = byBase.get(key2(token.basename)) || [];
    if (candidates.length > 1) {
      result.ambiguousExternalReferences.push(`${label} [${candidates.map((f) => f.relative).sort().join(", ")}]`);
      return;
    }
    if (!candidates.length) {
      result.unresolvedExternalReferences.push(label);
      return;
    }
    const target = { ...candidates[0], configuration: ref.configuration ?? null };
    if (!seen.has(identity(target))) queue.push(target);
  }
  try {
    for (let i = 0; i < queue.length; i++) {
      checkTime();
      const f = queue[i];
      if (seen.has(identity(f))) continue;
      if (documents >= LIMIT.documents || inflatedBytes >= LIMIT.inflatedBytes || edges >= LIMIT.edges) throw refused("Global source document/edge/decompression budget exhausted");
      seen.add(identity(f));
      result.requiredSourcePaths.push(f.relative);
      const collisions = byPath.get(key2(f.relative));
      if (collisions.length > 1) {
        result.ambiguousExternalReferences.push(`Provided source case-collision: ${collisions.map((v) => v.relative).sort().join(", ")}`);
        continue;
      }
      if (f.st.size > LIMIT.fileBytes || totalBytes + f.st.size > LIMIT.totalBytes) throw refused("Native source input byte budget exceeded");
      await noLinks(f.absolute);
      const handle = await open(f.absolute, "r");
      let bytes;
      try {
        const before = await handle.stat();
        if (!before.isFile() || before.size !== f.st.size || before.mtimeMs !== f.st.mtimeMs || before.ino !== f.st.ino) throw refused(`Provided native source changed before read: ${f.relative}`);
        bytes = Buffer.alloc(before.size);
        let n = 0;
        while (n < bytes.length) {
          const { bytesRead } = await handle.read(bytes, n, bytes.length - n, n);
          if (!bytesRead) throw refused(`Provided native source was truncated: ${f.relative}`);
          n += bytesRead;
        }
        const after = await handle.stat();
        if (after.size !== before.size || after.mtimeMs !== before.mtimeMs || after.ino !== before.ino) throw refused(`Provided native source changed during read: ${f.relative}`);
      } finally {
        await handle.close();
      }
      totalBytes += bytes.length;
      const format = /\.sld(?:prt|asm)$/i.test(f.relative) ? "solidworks" : /\.(?:step|stp)$/i.test(f.relative) ? "step" : "nx";
      let info;
      try {
        info = await metadata(bytes, f.relative, format, LIMIT.totalMs - (Date.now() - started), { ...LIMIT, documents: LIMIT.documents - documents, edges: LIMIT.edges - edges, inflatedBytes: LIMIT.inflatedBytes - inflatedBytes, totalBytes: LIMIT.totalBytes - totalBytes }, f.configuration);
      } catch (e) {
        if (e.code !== "NATIVE_UNSUPPORTED" && e.code !== "NATIVE_AUDIT_LIMIT") throw e;
        account(e.usage ?? { documents: LIMIT.documents - documents, inflatedBytes: LIMIT.inflatedBytes - inflatedBytes });
        unsupported4(`${f.relative}: ${e.message}`);
        continue;
      }
      account(info.usage ?? {});
      for (const k of ["embeddedReferenceEvidence", "externalFeatureEvidence", "neutralReferenceEvidence"]) for (const row of info[k] || []) result[k].push({ sourcePath: f.relative, ...row });
      if (f === main2) result.documentKind = info.kind;
      for (const s of info.unsupported) unsupported4(`${f.relative}: ${s}`);
      for (const ref of info.refs) await resolveReference(f, ref);
    }
  } catch (e) {
    if (e.code !== "NATIVE_AUDIT_LIMIT") throw e;
    unsupported4(e.message);
  }
  for (const k of ["requiredSourcePaths", "unresolvedExternalReferences", "ambiguousExternalReferences", "unsupportedReferenceAudits", "externalExistingReferences"]) result[k] = [...new Set(result[k])].sort();
  for (const k of ["embeddedReferenceEvidence", "externalFeatureEvidence", "neutralReferenceEvidence"]) result[k] = [...new Map(result[k].map((row) => [JSON.stringify(row), row])).values()];
  result.complete = [result.unresolvedExternalReferences, result.ambiguousExternalReferences, result.unsupportedReferenceAudits, result.externalExistingReferences].every((a) => a.length === 0);
  return result;
}
async function outputParent(absolute) {
  const parsed = path.parse(absolute);
  let p = parsed.root;
  for (const part of absolute.slice(parsed.root.length).split(path.sep).filter(Boolean)) {
    p = path.join(p, part);
    let st;
    try {
      st = await lstat(p);
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
      await mkdir(p);
      st = await lstat(p);
    }
    if (st.isSymbolicLink() || !st.isDirectory()) throw issue4("NATIVE_AUDIT_INPUT", `Unsafe output parent: ${p}`);
  }
}
async function main() {
  const args = process.argv.slice(2), options = {};
  if (args.length !== 6) throw issue4("NATIVE_AUDIT_INPUT", "Usage: --input ABS --source-root ABS --output ABS");
  for (let i = 0; i < args.length; i += 2) {
    if (!["--input", "--source-root", "--output"].includes(args[i]) || Object.hasOwn(options, args[i])) throw issue4("NATIVE_AUDIT_INPUT", "Invalid or duplicate CLI option");
    options[args[i]] = args[i + 1];
  }
  const output = options["--output"];
  if (!output || !path.isAbsolute(output) || !referenceToken(output) || unc(output) || cadName(output)) throw issue4("NATIVE_AUDIT_INPUT", "Output must be an absolute local non-CAD path with valid literal segments");
  if (path.resolve(output) === path.resolve(options["--input"])) throw issue4("NATIVE_AUDIT_INPUT", "Output cannot overwrite the native input");
  const receipt = await auditNativeSources({ primaryPath: options["--input"], sourceRoot: options["--source-root"] });
  await outputParent(path.dirname(path.resolve(output)));
  try {
    const st = await lstat(output);
    if (st.isSymbolicLink() || !st.isFile() || st.nlink > 1) throw issue4("NATIVE_AUDIT_INPUT", "Output must not be a link, hardlink alias, or non-regular file");
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  const temporary = path.join(path.dirname(output), `.native-source-audit-${randomUUID()}.json`);
  try {
    await writeFile(temporary, JSON.stringify(receipt, null, 2) + "\n", { flag: "wx" });
    await rename(temporary, output);
  } finally {
    await unlink(temporary).catch((e) => {
      if (e.code !== "ENOENT") throw e;
    });
  }
}
if (!isMainThread && workerData?.nativeSourceAuditWorker) await parseWorker();
else if (isMainThread && process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  main().catch((e) => {
    console.error(`${e.code || "NATIVE_AUDIT_INTERNAL"}: ${e.message}`);
    process.exitCode = 1;
  });
}
export {
  auditNativeSources
};
