"""Local native CAD provider using an independently installed NVIDIA runtime.

This code ships no NVIDIA/HOOPS binaries, keys or proprietary implementation.
The authorized runtime decodes native input, OpenUSD is an internal carrier,
and the returned GLB is explicitly tessellated, never editable/exact BRep.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import tempfile

PROVIDER_ID = 'nvidia-hoops-native-local'
PACKAGE_VERSION = '0.3.0'
HERE = Path(__file__).resolve().parent
AUDIT_SCHEMA = 'p3dw.native-source-audit/1'
ISSUE_KEYS = ('unresolvedExternalReferences', 'ambiguousExternalReferences',
              'unsupportedReferenceAudits', 'externalExistingReferences')

class NativeSourceRefusal(ValueError):
    """Required source references cannot be safely certified as provided."""

def atomic_json(path, data):
    path = Path(path)
    # Validate before creating staging files or touching an existing report.
    encoded = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    path.parent.mkdir(parents=True, exist_ok=True)
    staged = path.with_name(path.name + '.pending')
    created = False
    try:
        with staged.open('xb') as stream:
            created = True
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        staged.replace(path)
    finally:
        if created:
            staged.unlink(missing_ok=True)

def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(4 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()

MAX_SOURCE_ENTRIES = 10000


def safe_component(value):
    # Reject rather than normalize Windows ADS, device names, trailing aliases,
    # relative navigation and control characters (including NUL).
    return (bool(value) and value not in ('.', '..') and value[-1] not in ' .'
        and not re.search(r'[<>:"|?*\\/\x00-\x1f]', value)
        and not re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³])(?:\..*)?', value, re.I))


def canonical_relative(value):
    if not isinstance(value, str) or not value or '\\' in value or not all(safe_component(part) for part in value.split('/')):
        raise NativeSourceRefusal('Native source identities must be safe canonical relative paths; malformed tokens are not repaired.')
    return value


def unaliased_path(value):
    """lstat ancestry before resolve/stat/open, including the source root itself."""
    raw = os.fspath(value)
    if not isinstance(raw, str) or not raw or raw.startswith(('\\\\', '//')):
        raise NativeSourceRefusal('Native job paths must be ordinary local paths, not UNC/device aliases.')
    # Strip only a syntactically valid absolute drive prefix for token checking.
    tail = raw[3:] if re.match(r'^[A-Za-z]:[\\/]', raw) else raw
    if not all(safe_component(part) for part in re.split(r'[\\/]', tail)):
        raise NativeSourceRefusal('Native job path contains an unsafe Windows path token.')
    path = Path(os.path.abspath(raw))
    cursor = Path(path.anchor)
    for part in path.parts[1:]:
        cursor /= part
        try:
            info = cursor.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise NativeSourceRefusal('Source/job aliases (symlinks, junctions and reparse points) are not allowed.')
    return path.resolve()


def validate_job_paths(primary, output, report, work_dir):
    work = unaliased_path(work_dir)
    sources = unaliased_path(work / '_sources')
    primary, output, report = (unaliased_path(value) for value in (primary, output, report))
    if not work.is_dir() or not sources.is_dir() or sources == work or not sources.is_relative_to(work) or not primary.is_relative_to(sources) or not primary.is_file():
        raise ValueError('The native primary must be a provided file inside the staged source package.')
    for path in (output, report):
        if (path == work or not path.is_relative_to(work) or path.is_relative_to(sources)
                or path.is_relative_to(work / '_native_nvidia')
                or (path.exists() and not path.is_file())):
            raise ValueError('Native outputs/reports must be files inside the job and outside immutable sources/private evidence.')
    if (output == report or output.is_relative_to(report) or report.is_relative_to(output)
            or output.suffix.lower() != '.glb' or report.suffix.lower() != '.json'):
        raise ValueError('A separate self-contained GLB output and JSON report are required.')
    return {'primary': primary, 'output': output, 'report': report, 'work': work, 'sourceRoot': sources}


def source_snapshot(source_root):
    """Complete raising enumeration; reject aliases before hashing any content.

    This protects the owned staged package, not a hostile concurrent writer with
    filesystem privileges. Recheck every ancestry immediately before opening.
    """
    root = unaliased_path(source_root)
    pending, entries, seen = [root], [], set()
    while pending:
        directory = unaliased_path(pending.pop())
        if not directory.is_relative_to(root):
            raise NativeSourceRefusal('A staged source directory escaped its source root.')
        with os.scandir(directory) as scan:
            children = sorted(scan, key=lambda item: item.name)
        for child in children:
            canonical_relative(child.name)
            info = child.stat(follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise NativeSourceRefusal('Source aliases (symlinks, junctions and reparse points) are not allowed in a native conversion package.')
            path = unaliased_path(child.path)
            if not path.is_relative_to(root):
                raise NativeSourceRefusal('A staged source resolved outside its source root.')
            relative = canonical_relative(path.relative_to(root).as_posix())
            key = os.path.normcase(relative)
            if key in seen:
                raise NativeSourceRefusal('Case-colliding staged source identities are not allowed.')
            seen.add(key)
            if stat.S_ISDIR(info.st_mode):
                pending.append(path)
                kind = 'directory'
            elif stat.S_ISREG(info.st_mode):
                kind = 'file'
            else:
                raise NativeSourceRefusal('Only ordinary staged files and directories are supported.')
            entries.append((relative, path, kind))
            if len(entries) > MAX_SOURCE_ENTRIES:
                raise NativeSourceRefusal('The staged source package exceeds the bounded provider inventory.')
    snapshot = {}
    for relative, path, kind in entries:
        current = unaliased_path(path)
        if not current.is_relative_to(root):
            raise NativeSourceRefusal('A source escaped the staged package before hashing.')
        snapshot[relative] = {'kind': kind, 'sha256': sha256(current) if kind == 'file' else None}
    return snapshot


def require_unchanged_sources(paths, before):
    if source_snapshot(paths['sourceRoot']) != before:
        raise NativeSourceRefusal('The staged source package changed (bytes, additions or removals); output was not admitted.')

def sdk_diagnostics(text):
    # Source filenames can themselves contain 'missing', 'warning' or 'error'.
    # Recognize actual vendor severity framing, not arbitrary message substrings.
    result = []
    for line in text.splitlines():
        match = re.match(r'^\[omni\.converter\.hoops_log\]\*(?:warn|error)\*(.*)$', line, re.I)
        if match:
            result.append(match.group(1).strip()[:2000])
    return result[:200]

def require_closed_references(audit):
    if not isinstance(audit, dict) or audit.get('schema') != AUDIT_SCHEMA:
        raise NativeSourceRefusal('The format-aware native source-reference audit is absent or invalid.')
    issues = []
    for key in ISSUE_KEYS:
        values = audit.get(key)
        if not isinstance(values, list) or any(not isinstance(x, str) for x in values):
            raise NativeSourceRefusal('Native source-reference audit has an invalid ' + key + ' field.')
        issues.extend(values)
    if audit.get('complete') is not True or issues:
        detail = '; '.join(issues[:12]) or 'The metadata reader cannot establish the required reference closure.'
        raise NativeSourceRefusal('Native conversion refused: required references are missing, ambiguous, outside the provided package, or not audited. ' + detail)
    if audit.get('sourceFormat') not in ('solidworks', 'nx'):
        raise NativeSourceRefusal('The primary is not a qualified SolidWorks or NX native document.')
    primary = canonical_relative(audit.get('primaryRelativePath'))
    required = audit.get('requiredSourcePaths')
    if not isinstance(required, list) or not required or len(required) > MAX_SOURCE_ENTRIES:
        raise NativeSourceRefusal('The bounded requiredSourcePaths list must be present and nonempty.')
    identities = [os.path.normcase(canonical_relative(value)) for value in required]
    if len(set(identities)) != len(identities) or os.path.normcase(primary) not in identities:
        raise NativeSourceRefusal('Required source identities must be unique and include the bound primary.')
    expected = 'solidworks' if Path(primary).suffix.lower() in ('.sldprt', '.sldasm') else 'nx' if Path(primary).suffix.lower() == '.prt' else None
    if expected != audit['sourceFormat']:
        raise NativeSourceRefusal('The audited source format does not match the native primary extension.')
    return audit


def bind_audit(audit, paths, snapshot):
    require_closed_references(audit)
    invoked = paths['primary'].relative_to(paths['sourceRoot']).as_posix()
    if os.path.normcase(audit['primaryRelativePath']) != os.path.normcase(invoked):
        raise NativeSourceRefusal('The audit primary identity is not the actual invoked staged primary.')
    inventory = {os.path.normcase(key): value for key, value in snapshot.items()}
    for relative in audit['requiredSourcePaths']:
        resolved = unaliased_path(paths['sourceRoot'] / relative)
        if (not resolved.is_relative_to(paths['sourceRoot']) or not resolved.is_file()
                or inventory.get(os.path.normcase(relative), {}).get('kind') != 'file'):
            raise NativeSourceRefusal('A required reference is not a provided staged file: ' + relative)
    return audit

def make_provider_report(audit, exported, output_sha, native_warnings):
    require_closed_references(audit)
    if not isinstance(exported, dict):
        raise ValueError('Measured export metadata must be an object.')
    unit = exported.get('stageMetersPerUnit')
    if isinstance(unit, bool) or not isinstance(unit, (int, float)) or not math.isfinite(unit) or unit <= 0:
        raise ValueError('The USD stage has no usable physical length scale.')
    if exported.get('format') != 'glb' or exported.get('stageUpAxis') not in ('Y', 'Z'):
        raise ValueError('Unsupported exported representation or source coordinate axis.')
    counts = {}
    for key in ('nodeCount', 'meshCount', 'meshInstanceCount', 'triangleCount'):
        value = exported.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError('Missing/invalid measured export count: ' + key)
        counts[key] = value
    if not isinstance(output_sha, str) or not re.fullmatch(r'[0-9a-f]{64}', output_sha):
        raise ValueError('Final GLB digest is invalid.')
    material_warnings = exported.get('warnings', [])
    if (not isinstance(material_warnings, list) or not isinstance(native_warnings, list)
            or any(not isinstance(value, str) for value in material_warnings + native_warnings)):
        raise ValueError('Exporter/decoder warnings must be lists of strings.')
    coverage_warning = ('Native geometry coverage is not independently certified. Component-file '
        'reference closure and measured exported meshes do not prove that every native body or '
        'occurrence was decoded; structural/provider identities are not native CAD product UUIDs.')
    warnings = [coverage_warning] + [value[:2000] for value in native_warnings + material_warnings][:199]
    # A successful reader and closed reference metadata establish usable native-
    # derived viewing, not a complete geometry inventory. Warnings can only make
    # this more conservative; never publish a false non-degradation assertion.
    complete = False if native_warnings else None
    return {
        'schema': 'p3dw.provider-result/1',
        'provider': PROVIDER_ID,
        'parser': 'NVIDIA Omniverse CAD Converter / HOOPS Exchange',
        'providerVersion': PACKAGE_VERSION,
        'sourceFormat': audit['sourceFormat'],
        'documentKind': audit.get('documentKind', 'unknown'),
        'outputSchema': 'glTF 2.0 binary',
        'fidelity': 'tessellated',
        'exactBrep': False,
        'nativeGeometryDecoded': True,
        'outputSha256': output_sha,
        'sourceUnit': 'unknown',
        'outputUnit': 'meter',
        'unitsVerified': exported.get('stageMetersPerUnitAuthored') is True,
        'sourceStageMetersPerUnit': unit,
        'sourceStageUpAxis': exported['stageUpAxis'],
        'complete': complete,
        'incompleteVisualization': True if complete is False else None,
        'geometryCoverage': 'unverified',
        # Only primary consumption is directly established by the invocation.
        # Metadata reachability is not silently relabelled observed SDK I/O.
        'consumedSourcePaths': [audit['primaryRelativePath']],
        'unresolvedExternalReferences': [],
        'warnings': warnings,
        'triangleCount': counts['triangleCount'],
        'uniqueMeshCount': counts['meshCount'],
        'resolvedOccurrenceCount': counts['meshInstanceCount'],
        'assembly': {
            'hierarchy': 'glTF default scene, native-derived USD hierarchy',
            'sourceOccurrenceIdentity': 'USD structural prim path',
            'geometryReuseIdentity': 'shared glTF mesh definition',
            'nativeProductIdentity': 'unverified',
            'referenceAuditComplete': True,
            'requiredProvidedSourcePaths': audit.get('requiredSourcePaths', []),
        },
        'pmi': {'semanticAssociativityPreserved': False},
    }

def clean_environment(temp_dir):
    temporary = str(unaliased_path(temp_dir))
    environment = {k: v for k, v in os.environ.items() if k.upper() not in ('PYTHONHOME', 'PYTHONPATH', 'TEMP', 'TMP', 'TMPDIR')}
    environment.update({key: temporary for key in ('TEMP', 'TMP', 'TMPDIR')})
    return environment


def run_process(command, **kwargs):
    # -I intentionally excludes the adapter directory from sys.path. Load only
    # the explicitly deployed sibling; never use an ambient package import.
    path = HERE / 'native_process.py'
    spec = importlib.util.spec_from_file_location('p3dw_owned_native_process', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.run_owned(command, **kwargs)


def durable_copy(source, destination):
    with Path(source).open('rb') as incoming, Path(destination).open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing, 4 * 1024 * 1024)
        outgoing.flush()
        os.fsync(outgoing.fileno())


def publish_pair(paths, private_output, private_report, report, before, owned):
    """Failure-atomic pair under the bridge's exclusive per-job ownership.

    Both candidates and both prior bytes are retained in a fresh owned namespace.
    Two filesystem names cannot be one crash-atomic rename: this rolls back on
    Python/OS operation failure, not a power-loss transaction or concurrent API.
    """
    transaction = Path(tempfile.mkdtemp(prefix='publication-', dir=owned))
    targets = (paths['output'], paths['report'])
    sources = (private_output, private_report)
    previous, candidates = {}, {}
    # Admission and all staging/backup work precede the first public replace.
    validate_job_paths(paths['primary'], *targets, paths['work'])
    for index, (target, source) in enumerate(zip(targets, sources)):
        target.parent.mkdir(parents=True, exist_ok=True)
        candidates[target] = transaction / ('candidate-' + str(index))
        durable_copy(source, candidates[target])
        if target.exists():
            backup = transaction / ('previous-' + str(index))
            durable_copy(target, backup)
            previous[target] = (backup, sha256(backup))
        else:
            previous[target] = None
    if (sha256(candidates[targets[0]]) != report['outputSha256']
            or json.loads(candidates[targets[1]].read_text(encoding='utf-8')) != report):
        raise ValueError('Private publication candidates do not match the admitted output/report.')
    require_unchanged_sources(paths, before)
    validate_job_paths(paths['primary'], *targets, paths['work'])
    attempted = []
    try:
        for target in targets:
            attempted.append(target)
            candidates[target].replace(target)
        if (sha256(targets[0]) != report['outputSha256']
                or json.loads(targets[1].read_text(encoding='utf-8')) != report):
            raise RuntimeError('Final GLB/report readback does not match the admitted pair.')
        require_unchanged_sources(paths, before)
    except BaseException as error:
        rollback_errors = []
        for index, target in enumerate(reversed(attempted)):
            try:
                old = previous[target]
                if old is None:
                    target.unlink(missing_ok=True)
                elif not target.is_file() or sha256(target) != old[1]:
                    restore = transaction / ('restore-' + str(index))
                    durable_copy(old[0], restore)
                    os.replace(restore, target)
                if old is not None and sha256(target) != old[1]:
                    raise RuntimeError('Previous final bytes could not be verified after rollback.')
            except BaseException as failure:
                rollback_errors.append(str(failure))
        if rollback_errors:
            raise RuntimeError('Publication failed and filesystem prevented rollback; retained private recovery evidence: '
                + str(transaction) + '; ' + '; '.join(rollback_errors)) from error
        raise

def load_exporter():
    path = HERE / 'usd_geometry.py'
    if not path.is_file():
        raise RuntimeError('The qualified USD-to-GLB exporter is not installed alongside the native adapter.')
    spec = importlib.util.spec_from_file_location('p3dw_usd_geometry', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    if not callable(getattr(module, 'export_usd_to_glb', None)):
        raise RuntimeError('The installed USD exporter does not implement the required public contract.')
    return module.export_usd_to_glb

def runtime_probe(node, audit_script, temp_dir=None):
    if sys.version_info[:2] != (3, 12) or sys.prefix == sys.base_prefix:
        raise RuntimeError('Use the approved isolated Python 3.12 CAD runtime, not the system Python/pip.')
    if sys.platform != 'win32' or platform.machine().lower() not in ('amd64', 'x86_64'):
        raise RuntimeError('This installed native reader qualification covers Windows x86-64 only.')
    import usd_convert_cad
    import omni.converter.hoops as hoops
    from pxr import Usd
    prefix = Path(sys.prefix).resolve()
    if usd_convert_cad.__version__ != PACKAGE_VERSION:
        raise RuntimeError('This adapter requires the qualified NVIDIA package version ' + PACKAGE_VERSION)
    if not Path(usd_convert_cad.__file__).resolve().is_relative_to(prefix):
        raise RuntimeError('NVIDIA package resolved outside the approved runtime.')
    if not Path(hoops.__file__).resolve().is_relative_to(prefix):
        raise RuntimeError('Native converter binding resolved outside the approved runtime.')
    hoops.Parameters()  # Real native binding load; no fabricated capability getter.
    if not Path(audit_script).is_file():
        raise RuntimeError('The native source-reference audit module is not installed.')
    load_exporter()
    if temp_dir is None:
        # Explicit TEMP base, never tempfile's potentially stale inherited TMPDIR.
        base = unaliased_path(os.environ.get('TEMP', str(Path.home() / 'AppData/Local/Temp')))
        probe_dir = Path(tempfile.mkdtemp(prefix='p3dw-native-probe-', dir=base))
    else:
        probe_dir = Path(temp_dir) / 'runtime-probe'
        probe_dir.mkdir(exist_ok=False)
    with (probe_dir/'node.stdout.log').open('wb') as stdout, (probe_dir/'node.stderr.log').open('wb') as stderr:
        proc = run_process([node, '--version'], env=clean_environment(probe_dir), cwd=probe_dir,
            stdout=stdout, stderr=stderr, timeout=15, observation_path=probe_dir/'node-lifecycle.json')
    match = re.fullmatch(rb'v(\d+)\.\d+\.\d+\s*', (probe_dir/'node.stdout.log').read_bytes())
    if proc.returncode or not match or int(match[1]) < 20:
        raise RuntimeError('A working qualified Node runtime is required for source-reference auditing.')
    return {'packageVersion': usd_convert_cad.__version__, 'python': sys.version.split()[0], 'nativeBinding': str(Path(hoops.__file__).resolve()), 'openUSD': list(Usd.GetVersion()), 'readerEntitlement': 'normal vendor execution remains authoritative; no bypass'}

def unaliased_path_lstat(path):
    info = os.lstat(unaliased_path(path))
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise NativeSourceRefusal('Stored mode requires a regular file without hardlink aliases.')
    return info


def stored_runtime(args):
    if args.sw2800_verifier_exe is None:
        return None
    name = 'p3dw_owned_sw2800_runtime'
    path = HERE / 'sw2800_runtime.py'
    unaliased_path_lstat(path)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.verify_payload(sys.modules[__name__])
    verifier = Path(args.sw2800_verifier_exe)
    unaliased_path_lstat(verifier)
    if sha256(verifier) != args.sw2800_verifier_sha256:
        raise NativeSourceRefusal('Stored verifier digest mismatch.')
    return module


def run_native(args):
    paths = validate_job_paths(args.input, args.output, args.report, args.work_dir)
    before = source_snapshot(paths['sourceRoot'])
    owned = paths['work'] / '_native_nvidia'
    owned.mkdir(exist_ok=False)
    temporary = owned / 'temp'
    temporary.mkdir()
    runtime_probe(args.node, args.audit_script, temp_dir=owned)
    environment = clean_environment(temporary)
    atomic_json(owned/'source-inventory-before.json', before)
    audit_path = owned / 'source-reference-audit.json'
    audit_cmd = [args.node, args.audit_script, '--input', str(paths['primary']), '--source-root', str(paths['sourceRoot']), '--output', str(audit_path)]
    with (owned / 'audit.stdout.log').open('wb') as stdout, (owned / 'audit.stderr.log').open('wb') as stderr:
        result = run_process(audit_cmd, cwd=owned, env=environment, stdout=stdout, stderr=stderr,
            timeout=120, observation_path=owned/'audit-lifecycle.json')
    if result.returncode or not audit_path.is_file():
        raise NativeSourceRefusal('Native source-reference inspection failed; conversion was not attempted. ' + (owned / 'audit.stderr.log').read_text(errors='replace')[-1200:])
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    if (args.sw2800_verifier_exe is not None and isinstance(audit, dict)
            and audit.get('schema') == AUDIT_SCHEMA and audit.get('complete') is False
            and audit.get('sourceFormat') == 'solidworks'):
        stored_runtime(args).dispatch_stored(args, paths, before, owned, environment, audit, sys.modules[__name__])
        return
    audit = bind_audit(audit, paths, before)
    require_unchanged_sources(paths, before)
    usd_path = owned / 'model.usdc'
    cmd = [sys.executable, '-I', '-B', '-m', 'usd_convert_cad', '-i', str(paths['primary']), '-o', str(usd_path), '--accurate-tessellation', '--convert-metadata', '--instancing-style', 'reference', '--composition-style', 'none', '--filter-style', 'hide', '--load-hidden', '--material-type', 'preview-surface', '--progress']
    atomic_json(owned / 'invocation.json', {'command': cmd, 'primarySHA256': sha256(paths['primary']), 'sourceFileCount': sum(row['kind'] == 'file' for row in before.values()), 'processing': 'local', 'physicalPropertiesRequested': False})
    print('Reading native CAD geometry with NVIDIA/HOOPS...', flush=True)
    with (owned / 'converter.stdout.log').open('wb') as stdout, (owned / 'converter.stderr.log').open('wb') as stderr:
        result = run_process(cmd, cwd=paths['primary'].parent, env=environment, stdout=stdout, stderr=stderr,
            timeout=600, observation_path=owned/'converter-lifecycle.json')
    text = (owned / 'converter.stdout.log').read_text(errors='replace') + (owned / 'converter.stderr.log').read_text(errors='replace')
    if result.returncode or not usd_path.is_file() or usd_path.stat().st_size == 0:
        detail = (owned / 'converter.stderr.log').read_text(errors='replace')[-1600:]
        raise RuntimeError('The installed native decoder refused this document (exit ' + str(result.returncode) + '). ' + detail)
    require_unchanged_sources(paths, before)
    print('Preserving native hierarchy, placements, units and tessellated geometry...', flush=True)
    private_output = owned / 'private-model.glb'
    private_report = owned / 'private-provider-report.json'
    exported = load_exporter()(usd_path, private_output)
    require_unchanged_sources(paths, before)
    if not private_output.is_file() or private_output.stat().st_size == 0:
        raise ValueError('The exporter did not produce a private nonempty GLB.')
    atomic_json(owned / 'usd-export.json', exported)
    report = make_provider_report(audit, exported, sha256(private_output), sdk_diagnostics(text))
    atomic_json(private_report, report)
    publish_pair(paths, private_output, private_report, report, before, owned)
    print('Native-derived tessellated GLB ready; native geometry coverage is unverified; exact BRep/topology is not retained.', flush=True)

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--probe', action='store_true')
    parser.add_argument('--node', required=True)
    parser.add_argument('--audit-script', default=str(HERE / 'native-source-audit.mjs'))
    parser.add_argument('--input')
    parser.add_argument('--output')
    parser.add_argument('--report')
    parser.add_argument('--work-dir')
    parser.add_argument('--sw2800-verifier-exe')
    parser.add_argument('--sw2800-verifier-sha256')
    args = parser.parse_args(argv)
    exe, digest = args.sw2800_verifier_exe, args.sw2800_verifier_sha256
    if ((exe is None) != (digest is None) or (exe is not None and
            (not Path(exe).is_absolute() or not re.fullmatch(r'[0-9a-f]{64}', digest)))):
        parser.error('Use a paired absolute --sw2800-verifier-exe and lowercase --sw2800-verifier-sha256.')
    try:
        if args.probe:
            detail = runtime_probe(args.node, args.audit_script)
            stored_runtime(args)
            print('P3DW_NVIDIA_NATIVE_READY ' + PACKAGE_VERSION)
            print(json.dumps(detail))
        else:
            if not all((args.input, args.output, args.report, args.work_dir)):
                parser.error('--input, --output, --report and --work-dir are required for conversion')
            run_native(args)
        return 0
    except Exception as error:
        # No credentials/environment dumps; source diagnostics are retained locally.
        print(('Native reference/source refusal: ' if isinstance(error, NativeSourceRefusal) else 'Native CAD conversion failed: ') + str(error), file=sys.stderr, flush=True)
        return 3 if isinstance(error, NativeSourceRefusal) else 1

if __name__ == '__main__':
    raise SystemExit(main())
