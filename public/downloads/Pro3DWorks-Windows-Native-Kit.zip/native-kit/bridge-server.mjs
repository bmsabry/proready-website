#!/usr/bin/env node

// bridge/server.mjs
import { spawn } from "node:child_process";
import { createHash, randomBytes } from "node:crypto";
import {
  createReadStream,
  createWriteStream,
  existsSync as existsSync2
} from "node:fs";
import {
  mkdir,
  mkdtemp,
  open,
  readdir as readdir2,
  readFile,
  rm,
  stat as stat2,
  truncate,
  writeFile
} from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import {
  basename,
  dirname as dirname2,
  extname as extname2,
  isAbsolute as isAbsolute2,
  join as join2,
  resolve as resolve2,
  sep
} from "node:path";
import { pipeline } from "node:stream/promises";
import { Transform } from "node:stream";
import { fileURLToPath as fileURLToPath2 } from "node:url";

// src/formats.js
var BREP_EXT = Object.freeze({
  step: "step",
  stp: "step",
  p21: "step",
  iges: "iges",
  igs: "iges",
  brep: "brep",
  brp: "brep"
});
var MESH_EXT = Object.freeze([
  "stl",
  "obj",
  "ply",
  "3mf",
  "glb",
  "gltf",
  "amf",
  "dae",
  "fbx",
  "3ds",
  "wrl",
  "vrml",
  "vtk",
  "vtp",
  "usd",
  "usda",
  "usdc",
  "usdz",
  "kmz"
]);
var ASSIMP_VISUAL_EXTENSIONS = Object.freeze([
  "3d",
  "ac",
  "ac3d",
  "ase",
  "b3d",
  "blend",
  "bvh",
  "cob",
  "scn",
  "csm",
  "dxf",
  "hmp",
  "lwo",
  "lws",
  "md2",
  "md5mesh",
  "md5anim",
  "md5camera",
  "mdc",
  "mdl",
  "ms3d",
  "nff",
  "off",
  "ogex",
  "q3d",
  "q3s",
  "sib",
  "smd",
  "vta",
  "x",
  "xgl",
  "zgl",
  "zae"
]);
var ASSIMP_VISUAL_EXTENSION_SET = new Set(ASSIMP_VISUAL_EXTENSIONS);
var EMBEDDED_PARASOLID_TEXT_EXTENSIONS = Object.freeze([
  "x_t",
  "xmt_txt",
  "xmt"
]);
var EMBEDDED_PARASOLID_TEXT_EXTENSION_SET = new Set(
  EMBEDDED_PARASOLID_TEXT_EXTENSIONS
);
var EMBEDDED_SOLIDWORKS_VISUAL_EXTENSIONS = Object.freeze([
  "sldprt",
  "sldasm"
]);
var EMBEDDED_SOLIDWORKS_VISUAL_EXTENSION_SET = new Set(
  EMBEDDED_SOLIDWORKS_VISUAL_EXTENSIONS
);
var CONVERSION_GROUPS = Object.freeze([
  Object.freeze({
    family: "AutoCAD / engineering drawing",
    extensions: Object.freeze([
      "dwg",
      "dxf",
      "dxb",
      "dgn",
      "dwf",
      "dwfx",
      "dws",
      "dwt",
      "cel",
      "plt",
      "hpgl"
    ]),
    preferredExtensions: Object.freeze(["step", "glb", "dae", "stl"]),
    guidance: "For 3D solids, export STEP AP242 to preserve exact bodies and assembly structure. For presentation-only or drawing-derived geometry, export GLB or DAE; use STL only when no assembly metadata is required."
  }),
  Object.freeze({
    family: "Parasolid",
    extensions: Object.freeze(["x_t", "x_b", "xmt", "xmt_txt", "xmt_bin"]),
    preferredExtensions: Object.freeze(["step", "iges", "glb"]),
    guidance: "Text .x_t/.xmt_txt has an embedded, isolated tessellated reader that supports validated nested occurrences and shared bodies. For authoritative B-rep/PMI, binary .x_b/.xmt_bin, or unsupported entities and revisions, use a qualified Parasolid provider and prefer STEP AP242 output."
  }),
  Object.freeze({
    family: "ACIS",
    extensions: Object.freeze(["sat", "sab"]),
    preferredExtensions: Object.freeze(["step", "iges", "glb"]),
    guidance: "Export STEP AP242 for exact solid topology, or GLB for viewing-scale geometry."
  }),
  Object.freeze({
    family: "JT",
    extensions: Object.freeze(["jt"]),
    preferredExtensions: Object.freeze(["step", "glb"]),
    guidance: "Use a JT-capable CAD translator to export STEP AP242 for exact solids or GLB for lightweight viewing."
  }),
  Object.freeze({
    family: "Native mechanical CAD",
    extensions: Object.freeze([
      "sldprt",
      "sldasm",
      "slddrw",
      "ipt",
      "iam",
      "idw",
      "ipn",
      "catpart",
      "catproduct",
      "catdrawing",
      "catshape",
      "cgr",
      "3dxml",
      "model",
      "session",
      "dlv",
      "exp",
      "prt",
      "asm",
      "neu",
      "xas",
      "xpr",
      "drw",
      "frm",
      "par",
      "psm",
      "pwd",
      "dft",
      "f3d",
      "f3z",
      "fcstd",
      "fcstd1",
      "mf1",
      "arc",
      "unv",
      "pkg"
    ]),
    preferredExtensions: Object.freeze(["step", "glb"]),
    guidance: "Export STEP AP242 when measurements, bodies, names, and authored colors matter. Export GLB for fast presentation-only viewing."
  }),
  Object.freeze({
    family: "BIM / plant model",
    extensions: Object.freeze(["ifc", "ifczip", "ifcxml", "rvt", "rfa", "rte", "rft", "nwd", "nwc", "nwf"]),
    // STEP preserves IFC world units for engineering inspection. If it is not
    // available or cannot produce renderable solids, provider fallback uses
    // GLB for the full presentation model.
    preferredExtensions: Object.freeze(["step", "glb"]),
    guidance: "Export GLB/GLTF for the complete visual model, or STEP for the mechanical solids that require engineering inspection."
  }),
  Object.freeze({
    family: "Rhino / NURBS CAD",
    extensions: Object.freeze(["3dm"]),
    preferredExtensions: Object.freeze(["step", "glb"]),
    guidance: "Translate exact Rhino B-rep to STEP AP242 and use GLB only when the source contains presentation meshes without exact surfaces."
  }),
  Object.freeze({
    family: "Engineering exchange / visualization",
    extensions: Object.freeze([
      "prc",
      "u3d",
      "x3d",
      "x3dv",
      "x3db",
      "vda",
      "stpz",
      "stpx",
      "stpxz",
      "plmxml",
      "qif",
      "pdf"
    ]),
    preferredExtensions: Object.freeze(["step", "glb"]),
    guidance: "Use STEP AP242 when the source carries exact topology. Use GLB for visualization-only or tessellated content."
  }),
  Object.freeze({
    family: "SketchUp",
    extensions: Object.freeze(["skp"]),
    preferredExtensions: Object.freeze(["glb", "dae"]),
    guidance: "Export GLB or DAE from SketchUp so hierarchy, transforms, and presentation colors remain available."
  })
]);
var CAD_CONVERSION_FORMATS = Object.freeze(Object.fromEntries(
  CONVERSION_GROUPS.flatMap((group) => group.extensions.map((extension) => [extension, group]))
));
var MESH_EXT_SET = new Set(MESH_EXT);
function normalizeModelExtension(extension) {
  return String(extension || "").trim().replace(/^\./, "").toLowerCase();
}
var CAD_ASSEMBLY_ROOT_EXTENSIONS = Object.freeze([
  "sldasm",
  "iam",
  "catproduct",
  "asm",
  "xas",
  "session",
  "3dxml",
  "rvt",
  "nwd",
  "nwf",
  "ifc",
  "ifczip",
  "plmxml",
  "f3z",
  "fcstd",
  "fcstd1"
]);
var CAD_ASSEMBLY_ROOT_SET = new Set(CAD_ASSEMBLY_ROOT_EXTENSIONS);
function modelFileExtension(fileName) {
  const cleanName = String(fileName || "").trim().split(/[\\/]/).pop() || "";
  const versionedCreo = cleanName.match(/\.(prt|asm)\.\d+$/i);
  if (versionedCreo) return versionedCreo[1].toLowerCase();
  const dot = cleanName.lastIndexOf(".");
  return dot >= 0 ? normalizeModelExtension(cleanName.slice(dot + 1)) : "";
}
var DIRECT_MODEL_EXTENSIONS = Object.freeze([
  ...Object.keys(BREP_EXT),
  ...MESH_EXT
]);
var KNOWN_MODEL_FILE_ACCEPT = Object.freeze([
  ...DIRECT_MODEL_EXTENSIONS,
  ...ASSIMP_VISUAL_EXTENSIONS,
  "p3dw",
  ...Object.keys(CAD_CONVERSION_FORMATS)
].map((extension) => `.${extension}`).join(","));

// src/import-provenance.js
var MAX_WARNINGS = 20;
var MAX_WARNING_CHARS = 500;
var MAX_TOLERANCE_SOURCES = 32;
var MAX_BLEND_WORK_KINDS = 32;
function boundedString(value, max = 160) {
  if (value == null) return null;
  const text = String(value).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim();
  return text ? text.slice(0, max) : null;
}
function count(value) {
  const number = Number(value);
  return Number.isSafeInteger(number) && number >= 0 ? number : null;
}
function finite(value, { min = -Infinity, max = Infinity } = {}) {
  const number = Number(value);
  return Number.isFinite(number) && number >= min && number <= max ? number : null;
}
function bool(value) {
  return typeof value === "boolean" ? value : null;
}
function finiteVector3(value) {
  if (!Array.isArray(value) || value.length !== 3) return null;
  const vector = value.map((component) => finite(component));
  return vector.every((component) => component !== null) ? vector : null;
}
function finiteBounds3(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const min = finiteVector3(value.min);
  const max = finiteVector3(value.max);
  return min && max && min.every((component, axis) => component <= max[axis]) ? { min, max } : null;
}
function addDefined(target, key, value) {
  if (value !== null && value !== void 0) target[key] = value;
}
function boundedWarnings(...sources) {
  const warnings = [];
  const seen = /* @__PURE__ */ new Set();
  for (const source of sources) {
    if (!Array.isArray(source)) continue;
    for (const raw of source) {
      const warning = boundedString(raw, MAX_WARNING_CHARS);
      if (!warning || seen.has(warning)) continue;
      seen.add(warning);
      warnings.push(warning);
      if (warnings.length >= MAX_WARNINGS) return warnings;
    }
  }
  return warnings;
}
function boundedTolerance(report) {
  const source = report?.toleranceDiagnostics && typeof report.toleranceDiagnostics === "object" ? report.toleranceDiagnostics : report?.tolerance && typeof report.tolerance === "object" ? report.tolerance : report;
  const tolerance = {};
  for (const key of [
    "requestedChordToleranceMeters",
    "achievedChordToleranceMeters",
    "maxBoundaryResidualMeters",
    "maxBlendSupportResidualMeters"
  ]) addDefined(tolerance, key, finite(source?.[key], { min: 0 }));
  addDefined(
    tolerance,
    "approximateBlendSupportSections",
    count(source?.approximateBlendSupportSections)
  );
  addDefined(tolerance, "worstFaceIndex", count(source?.worstFaceIndex));
  addDefined(tolerance, "worstBodyIndex", count(source?.worstBodyIndex));
  const residualSources = Array.isArray(source?.boundaryResidualSources) ? source.boundaryResidualSources.slice(0, MAX_TOLERANCE_SOURCES).map((value) => boundedString(value, 120)).filter(Boolean) : [];
  if (residualSources.length) {
    tolerance.boundaryResidualSources = [...new Set(residualSources)];
  }
  const blendWork = {};
  let blendKinds = 0;
  if (source?.blendWork && typeof source.blendWork === "object" && !Array.isArray(source.blendWork)) {
    for (const [rawKind, rawValue] of Object.entries(source.blendWork)) {
      if (blendKinds >= MAX_BLEND_WORK_KINDS) break;
      const kind = boundedString(rawKind, 80);
      const value = count(rawValue);
      if (!kind || value === null || Object.hasOwn(blendWork, kind)) continue;
      blendWork[kind] = value;
      blendKinds++;
    }
  }
  if (blendKinds) tolerance.blendWork = blendWork;
  return Object.keys(tolerance).length ? tolerance : null;
}
function boundedProviderReportSummary(report, fallbackWarnings = null) {
  if (!report || typeof report !== "object" || Array.isArray(report)) return null;
  const summary = {};
  for (const key of ["parser", "provider", "documentKind", "sourceUnit", "outputUnit"]) {
    addDefined(summary, key, boundedString(report[key]));
  }
  if (typeof report.geometryCoverage === "string") {
    addDefined(summary, "geometryCoverage", boundedString(report.geometryCoverage));
  }
  for (const key of [
    "bodyCount",
    "uniqueMeshCount",
    "sourceBodyCount",
    "faceCount",
    "totalFaces",
    "renderedFaces",
    "failedFaces",
    "invalidFaces",
    "omittedFaces",
    "recoveredFaces",
    "approximateRecoveredFaces",
    "triangleCount",
    "uniqueTriangleCount",
    "sourceTriangleCount",
    "vertexCount",
    "stagedVertexCount",
    "uniquePartCount",
    "resolvedOccurrenceCount",
    "missingOccurrenceCount",
    "unplacedOccurrenceCount",
    "suppressedOccurrenceCount",
    "totalComponentCount",
    "droppedDegenerateTriangles",
    "droppedGpuCollapsedTriangles",
    "repairedWindingTriangles",
    "ambiguousWindingTriangles"
  ]) addDefined(summary, key, count(report[key]));
  addDefined(summary, "exactBrep", bool(report.exactBrep));
  addDefined(summary, "unitsVerified", bool(report.unitsVerified));
  addDefined(summary, "boundsMM", finiteBounds3(report.boundsMM));
  addDefined(summary, "renderOriginMM", finiteVector3(report.renderOriginMM));
  addDefined(summary, "renderBoundsMM", finiteBounds3(report.renderBoundsMM));
  addDefined(summary, "completenessRatio", finite(report.completenessRatio, {
    min: 0,
    max: 1
  }));
  addDefined(summary, "incompleteVisualization", bool(report.incompleteVisualization));
  addDefined(summary, "complete", bool(report.complete));
  addDefined(
    summary,
    "reconstructionCorridorExceeded",
    bool(report.reconstructionCorridorExceeded)
  );
  addDefined(summary, "visualCacheHit", bool(report.visualCacheHit));
  for (const key of ["normalEncoding", "normalEncodingReason", "colorEncoding"]) {
    addDefined(summary, key, boundedString(report[key]));
  }
  for (const key of ["normalComponentType", "colorComponentType"]) {
    addDefined(summary, key, count(report[key]));
  }
  for (const key of ["normalNormalized", "colorNormalized"]) {
    addDefined(summary, key, bool(report[key]));
  }
  for (const key of [
    "normalQuantizationMaxComponentError",
    "normalQuantizationMaxAngularErrorDegrees",
    "colorQuantizationMaxComponentError",
    "maxGpuCollapsedTriangleAltitudeMeters",
    "maxGpuPositionQuantizationErrorMeters"
  ]) addDefined(summary, key, finite(report[key], { min: 0 }));
  for (const key of [
    "outputBinaryBytes",
    "outputJsonBytes",
    "outputGlbBytes",
    "expandedLoaderBytes",
    "expandedLoaderVertexCount",
    "expandedLoaderIndexCount",
    "expandedLoaderTriangleCount"
  ]) addDefined(summary, key, count(report[key]));
  const tolerance = boundedTolerance(report);
  if (tolerance) summary.tolerance = tolerance;
  const warnings = boundedWarnings(report.warnings, fallbackWarnings);
  if (warnings.length) summary.warnings = warnings;
  return Object.keys(summary).length ? summary : null;
}

// src/import-fidelity.js
var dataOf = (part) => part?.data || part || {};
var auditOf = (part) => dataOf(part).pipelineAudit || part?.pipelineAudit || {};
function degradedReport(report) {
  if (!report) return false;
  return report.complete === false || report.incompleteVisualization === true || report.reconstructionCorridorExceeded === true || Number.isFinite(report.completenessRatio) && report.completenessRatio >= 0 && report.completenessRatio < 1 || [
    "omittedFaces",
    "failedFaces",
    "invalidFaces",
    "approximateRecoveredFaces",
    "approximateBlendSupportSections"
  ].some((key) => Number(report[key]) > 0) || Number(report.tolerance?.approximateBlendSupportSections) > 0;
}
function incompleteImportEvidence(part) {
  const data = dataOf(part), audit = auditOf(part), session = audit.importSession || {};
  const conversion = session.conversion || audit.conversion;
  return [data, audit, session, conversion].some((value) => value?.incompleteImport === true) || degradedReport(conversion?.providerReport);
}

// bridge/provider-discovery.mjs
import { existsSync } from "node:fs";
import { readdir, stat } from "node:fs/promises";
import { delimiter, dirname, extname, isAbsolute, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { availableParallelism } from "node:os";
var HERE = dirname(fileURLToPath(import.meta.url));
var RECOMMENDED_PROVIDER_CATALOG = Object.freeze([
  Object.freeze({
    id: "hoops-exchange",
    label: "HOOPS Exchange",
    role: "Primary native CAD/BIM translator",
    license: "commercial",
    installHint: "Install and license the HOOPS Exchange SDK, build its ImportExport worker, then configure bridge/config.local.json."
  }),
  Object.freeze({
    id: "ifcopenshell",
    label: "IfcOpenShell IfcConvert",
    role: "IFC to GLB/STEP",
    license: "LGPL",
    installHint: "Install an official IfcOpenShell build containing IfcConvert.exe; discovery is automatic."
  }),
  Object.freeze({
    id: "freecad",
    label: "FreeCAD command-line",
    role: "FCStd and open neutral CAD fallback",
    license: "LGPL",
    installHint: "Install FreeCAD 1.x; FreeCADCmd.exe is discovered automatically."
  }),
  Object.freeze({
    id: "assimp",
    label: "Assimp command-line",
    role: "Large/uncommon tessellated scene fallback",
    license: "BSD-3-Clause",
    installHint: "Install the Assimp command-line tools or use the embedded AssimpJS fallback."
  }),
  Object.freeze({
    id: "sketchup",
    label: "SketchUp C API worker",
    role: "Authoritative SKP components/materials",
    license: "vendor SDK terms",
    installHint: "Build and configure a SketchUp C API worker for production SKP import."
  })
]);
function expandEnvironment(value, env) {
  return String(value || "").replace(/%([^%]+)%/g, (match, key) => env[key] ?? env[key.toUpperCase()] ?? env[key.toLowerCase()] ?? match);
}
async function regularFile(path) {
  if (!path || !existsSync(path)) return false;
  try {
    return (await stat(path)).isFile();
  } catch (error) {
    return false;
  }
}
function executableNames(command, platform, env) {
  if (platform !== "win32" || extname(command)) return [command];
  const pathExt = String(env.PATHEXT || ".COM;.EXE").split(";").filter((extension) => /^\.(?:com|exe)$/i.test(extension));
  return [
    command,
    ...pathExt.map((extension) => command + extension.toLowerCase()),
    ...pathExt.map((extension) => command + extension.toUpperCase())
  ];
}
async function resolveExecutableCandidates(command, {
  env = process.env,
  cwd = process.cwd(),
  platform = process.platform
} = {}) {
  const expanded = expandEnvironment(command, env).trim();
  if (!expanded) return [];
  if (platform === "win32" && extname(expanded) && !/^\.(?:com|exe)$/i.test(extname(expanded))) return [];
  if (isAbsolute(expanded)) return await regularFile(expanded) ? [resolve(expanded)] : [];
  if (/[\\/]/.test(expanded)) {
    const candidate = resolve(cwd, expanded);
    return await regularFile(candidate) ? [candidate] : [];
  }
  const matches = [];
  for (const directory of String(env.PATH || "").split(delimiter).filter(Boolean)) {
    for (const name of executableNames(expanded, platform, env)) {
      const candidate = resolve(expandEnvironment(directory.replace(/^"|"$/g, ""), env), name);
      if (await regularFile(candidate)) matches.push(candidate);
    }
  }
  return matches;
}
async function resolveExecutable(command, options = {}) {
  return (await resolveExecutableCandidates(command, options))[0] || null;
}
async function versionedInstallCandidates(root, productPattern, relativeExecutables) {
  if (!root || !existsSync(root)) return [];
  let entries;
  try {
    entries = await readdir(root, { withFileTypes: true });
  } catch (error) {
    return [];
  }
  const candidates = [];
  for (const entry of entries.sort((left, right) => right.name.localeCompare(left.name, void 0, { numeric: true }))) {
    if (!entry.isDirectory() || !productPattern.test(entry.name)) continue;
    for (const relative of relativeExecutables) candidates.push(join(root, entry.name, relative));
  }
  return candidates;
}
async function uniqueExecutables(candidates, options) {
  const platform = options?.platform || process.platform;
  const seen = /* @__PURE__ */ new Set();
  const executables = [];
  for (const candidate of candidates.filter(Boolean)) {
    for (const found of await resolveExecutableCandidates(candidate, options)) {
      const key = platform === "win32" ? found.toLowerCase() : found;
      if (seen.has(key)) continue;
      seen.add(key);
      executables.push(found);
    }
  }
  return executables;
}
function failoverIdentity(id, label, index) {
  if (index === 0) return { id, label };
  return {
    id: `${id}-fallback-${index + 1}`,
    label: `${label} (fallback ${index + 1})`
  };
}
function programRoots(env) {
  return [...new Set([
    env.ProgramFiles,
    env["ProgramFiles(x86)"],
    env.LOCALAPPDATA && join(env.LOCALAPPDATA, "Programs")
  ].filter(Boolean).map((value) => resolve(value)))];
}
async function discoverOpenProviders({
  env = process.env,
  platform = process.platform,
  bridgeDirectory = HERE
} = {}) {
  const options = { env, platform, cwd: bridgeDirectory };
  const roots = programRoots(env);
  const freeCadCandidates = [
    env.P3DW_FREECADCMD_PATH,
    join(bridgeDirectory, "tools", "freecad", "bin", "FreeCADCmd.exe")
  ];
  const ifcCandidates = [
    env.P3DW_IFCCONVERT_PATH,
    env.LOCALAPPDATA && join(
      env.LOCALAPPDATA,
      "Pro3DWorks",
      "providers",
      "ifcopenshell",
      "IfcConvert.exe"
    ),
    join(bridgeDirectory, "tools", "ifcopenshell", "IfcConvert.exe")
  ];
  for (const root of roots) {
    freeCadCandidates.push(...await versionedInstallCandidates(
      root,
      /^FreeCAD(?:\s|$|-)/i,
      [join("bin", "FreeCADCmd.exe"), "FreeCADCmd.exe"]
    ));
    ifcCandidates.push(...await versionedInstallCandidates(
      root,
      /^(?:IfcOpenShell|Bonsai)(?:\s|$|-)/i,
      ["IfcConvert.exe", join("bin", "IfcConvert.exe")]
    ));
  }
  freeCadCandidates.push(platform === "win32" ? "FreeCADCmd.exe" : "freecadcmd");
  ifcCandidates.push(platform === "win32" ? "IfcConvert.exe" : "IfcConvert");
  const [freeCadExecutables, ifcExecutables, assimpExecutables] = await Promise.all([
    uniqueExecutables(freeCadCandidates, options),
    uniqueExecutables(ifcCandidates, options),
    uniqueExecutables([
      env.P3DW_ASSIMP_PATH,
      join(bridgeDirectory, "tools", "assimp", platform === "win32" ? "assimp.exe" : "assimp"),
      platform === "win32" ? "assimp.exe" : "assimp"
    ], options)
  ]);
  const providers = [];
  for (const [index, freeCad] of freeCadExecutables.entries()) {
    const worker = join(bridgeDirectory, "workers", "freecad-convert.py");
    const probeWorker = join(bridgeDirectory, "workers", "freecad-probe.py");
    const identity = failoverIdentity(
      "freecad-open-cad",
      "FreeCAD open CAD worker",
      index
    );
    providers.push({
      ...identity,
      command: freeCad,
      args: [
        "-c",
        "import os, runpy; runpy.run_path(os.environ['P3DW_WORKER'], run_name='__main__')"
      ],
      environment: {
        P3DW_WORKER: worker,
        P3DW_PROBE_WORKER: probeWorker,
        P3DW_INPUT: "{input}",
        P3DW_OUTPUT: "{output}",
        P3DW_REPORT: "{report}"
      },
      supports: ["fcstd", "fcstd1", "step", "stp", "p21", "iges", "igs", "brep", "brp"],
      outputs: ["step"],
      exactOutputs: ["step"],
      timeoutMs: 2 * 60 * 60 * 1e3,
      licensed: true,
      discovered: true,
      probeArgs: [
        "-c",
        "import os, runpy; runpy.run_path(os.environ['P3DW_PROBE_WORKER'], run_name='__main__')"
      ],
      probeSuccessPattern: "P3DW_FREECAD_PROVIDER_READY",
      probeTimeoutMs: 15e3
    });
  }
  for (const [index, ifcConvert] of ifcExecutables.entries()) {
    const configuredThreads = Number.parseInt(env.P3DW_IFC_THREADS || "", 10);
    const defaultThreads = Math.min(4, Math.max(1, availableParallelism() - 1));
    const jobs = String(Number.isSafeInteger(configuredThreads) && configuredThreads > 0 ? Math.min(16, configuredThreads) : defaultThreads);
    const visualIdentity = failoverIdentity(
      "ifcopenshell-glb",
      "IfcOpenShell visual translator",
      index
    );
    providers.push({
      ...visualIdentity,
      command: ifcConvert,
      args: [
        "-y",
        "--no-progress",
        "--stderr-progress",
        "--log-format",
        "json",
        "-j",
        jobs,
        "{input}",
        "{output}"
      ],
      supports: ["ifc"],
      outputs: ["glb"],
      exactOutputs: [],
      timeoutMs: 2 * 60 * 60 * 1e3,
      licensed: true,
      discovered: true,
      probeArgs: ["--version"],
      probeTimeoutMs: 15e3
    });
    const stepIdentity = failoverIdentity(
      "ifcopenshell-step",
      "IfcOpenShell STEP translator",
      index
    );
    providers.push({
      ...stepIdentity,
      command: ifcConvert,
      args: ["-y", "--no-progress", "--convert-back-units", "{input}", "{output}"],
      supports: ["ifc"],
      // IfcConvert names its STEP serializer `.stp`; `.step` is rejected.
      outputs: ["stp"],
      exactOutputs: ["stp"],
      timeoutMs: 2 * 60 * 60 * 1e3,
      licensed: true,
      discovered: true,
      probeArgs: ["--version"],
      probeTimeoutMs: 15e3
    });
  }
  for (const [index, assimp] of assimpExecutables.entries()) {
    const identity = failoverIdentity(
      "assimp-native-visual",
      "Assimp native visual translator",
      index
    );
    providers.push({
      ...identity,
      command: assimp,
      args: ["export", "{input}", "{output}"],
      supports: [
        "3d",
        "3ds",
        "3mf",
        "ac",
        "ac3d",
        "amf",
        "ase",
        "b3d",
        "blend",
        "bvh",
        "cob",
        "scn",
        "csm",
        "dae",
        "zae",
        "dxf",
        "fbx",
        "gltf",
        "glb",
        "hmp",
        "lwo",
        "lws",
        "md2",
        "md5mesh",
        "md5anim",
        "md5camera",
        "mdc",
        "mdl",
        "ms3d",
        "nff",
        "obj",
        "off",
        "ogex",
        "ply",
        "q3d",
        "q3s",
        "sib",
        "smd",
        "vta",
        "stl",
        "x",
        "xgl",
        "zgl"
      ],
      outputs: ["glb"],
      exactOutputs: [],
      timeoutMs: 2 * 60 * 60 * 1e3,
      licensed: true,
      discovered: true,
      probeArgs: ["version"],
      probeTimeoutMs: 15e3
    });
  }
  return providers;
}

// bridge/server.mjs
var CAD_BRIDGE_PROTOCOL = "p3dw-import-bridge/1";
var JOB_SCHEMA = "p3dw.import-job/1";
var HERE2 = dirname2(fileURLToPath2(import.meta.url));
var DEFAULT_APP_PATH = resolve2(HERE2, "..", "dist", "Pro3DWorks.html");
var DEFAULT_CONFIG_PATH = resolve2(HERE2, "config.local.json");
var OCCT_VERIFIER_PATH = resolve2(HERE2, "workers", "occt-verify.mjs");
var DEFAULT_MAX_FILE_BYTES = 8 * 1024 ** 3;
var DEFAULT_MAX_JOB_BYTES = 16 * 1024 ** 3;
var DEFAULT_TIMEOUT_MS = 2 * 60 * 60 * 1e3;
var DEFAULT_MAX_OUTPUT_BYTES = 512 * 1024 ** 2;
var DEFAULT_MAX_CONCURRENT_JOBS = 1;
var DEFAULT_MAX_SOURCE_FILES = 4096;
var DEFAULT_MAX_CHUNK_BYTES = 16 * 1024 ** 2;
var MAX_JSON_BYTES = 1024 * 1024;
var MAX_LOG_BYTES = 128 * 1024;
var JOB_RETENTION_MS = 30 * 60 * 1e3;
var DEFAULT_INACTIVE_UPLOAD_MS = 15 * 60 * 1e3;
var ORPHAN_JOB_MINIMUM_AGE_MS = 6 * 60 * 60 * 1e3;
var LOOPBACK_HOSTS = /* @__PURE__ */ new Set(["127.0.0.1", "localhost", "[::1]", "::1"]);
var EXACT_BREP_CONTAINERS = /* @__PURE__ */ new Set([
  "step",
  "stp",
  "p21",
  "iges",
  "igs",
  "brep",
  "brp"
]);
var BRIDGE_OUTPUT_EXTENSIONS = /* @__PURE__ */ new Set([
  ...EXACT_BREP_CONTAINERS,
  "glb"
]);
var STEP_RENDERABLE_ENTITY = /#\s*\d+\s*=\s*(?:MANIFOLD_SOLID_BREP|BREP_WITH_VOIDS|FACETED_BREP|SHELL_BASED_SURFACE_MODEL|EDGE_BASED_WIREFRAME_MODEL|GEOMETRIC_CURVE_SET|GEOMETRIC_SET|TRIANGULATED_FACE_SET|TESSELLATED_(?:SHELL|SOLID|GEOMETRIC_SET)|ADVANCED_FACE|FACE_SURFACE|CLOSED_SHELL|OPEN_SHELL|EDGE_CURVE|POLYLINE|B_SPLINE_CURVE(?:_WITH_KNOTS)?|COMPOSITE_CURVE)\s*\(/i;
var BREP_SHAPE_COUNT = /\bTShapes\s+[1-9]\d*/i;
var BREP_TOPOLOGY_RECORD = /(?:^|\r?\n)(?:Ve|Ed|Wi|Fa|Sh|So|Co|Cs)\b/m;
function cleanExtension(value) {
  return String(value || "").trim().replace(/^\./, "").toLowerCase();
}
function boundedInteger(value, fallback, name, minimum, maximum) {
  const selected = value === void 0 || value === null || value === "" ? fallback : value;
  const number = Number(selected);
  if (!Number.isSafeInteger(number) || number < minimum || number > maximum) {
    throw new Error(`${name} must be a safe integer from ${minimum} to ${maximum}.`);
  }
  return number;
}
function throwIfJobCancelled(job) {
  if (job.cancelled) throw new Error("CAD conversion cancelled.");
}
function fileExtension(value) {
  return modelFileExtension(value);
}
function modelBaseName(value) {
  const leaf = basename(String(value || "converted"));
  const versionedCreo = leaf.match(/^(.*)\.(?:prt|asm)\.\d+$/i);
  return (versionedCreo?.[1] || basename(leaf, extname2(leaf)) || "converted").slice(0, 220);
}
function safeLeaf(value, fallback = "source.cad") {
  const leaf = basename(String(value || fallback).replace(/\\/g, "/"));
  return leaf.replace(/[\u0000-\u001f<>:"|?*]/g, "_").slice(0, 240) || fallback;
}
function safeRelativePath(value, fallback = "source.cad") {
  const raw = String(value || fallback).replace(/\\/g, "/");
  if (isAbsolute2(raw) || /^[a-z]:/i.test(raw)) {
    throw new Error("Absolute source paths are not allowed.");
  }
  const segments = raw.split("/").filter(Boolean);
  if (!segments.length || segments.some((segment) => segment === "." || segment === "..")) {
    throw new Error("Unsafe source relative path.");
  }
  const deviceName = /^(?:con|prn|aux|nul|clock\$|conin\$|conout\$|com(?:[1-9\u00b9\u00b2\u00b3])|lpt(?:[1-9\u00b9\u00b2\u00b3]))(?:\..*)?$/i;
  for (const segment of segments) {
    if (/[. ]$/.test(segment) || deviceName.test(segment) || safeLeaf(segment, "item") !== segment) {
      throw new Error("Unsafe or unsupported Windows source filename: " + segment);
    }
  }
  return segments.join("/");
}
function pathInside(root, relativePath) {
  const target = resolve2(root, relativePath);
  const prefix = root.endsWith(sep) ? root : `${root}${sep}`;
  if (target !== root && !target.startsWith(prefix)) {
    throw new Error("Resolved source path escaped the job directory.");
  }
  return target;
}
function cappedText(existing, chunk) {
  const next = existing + String(chunk || "");
  return next.length > MAX_LOG_BYTES ? next.slice(next.length - MAX_LOG_BYTES) : next;
}
function publicProvider(provider) {
  return {
    id: provider.id,
    label: provider.label,
    version: provider.version || null,
    supports: provider.supports,
    outputs: provider.outputs,
    exactOutputs: provider.exactOutputs,
    licensed: provider.licensed === true,
    ready: provider.ready === true,
    reason: provider.reason || null,
    discovered: provider.discovered === true,
    probe: provider.probe || null
  };
}
function normalizeProvider(provider, index) {
  if (!provider || provider.enabled === false) return null;
  const command = String(provider.command || "").trim();
  if (!command || !Array.isArray(provider.args)) return null;
  const outputs = [...new Set((provider.outputs || ["step"]).map(cleanExtension).filter((output) => BRIDGE_OUTPUT_EXTENSIONS.has(output)))];
  if (!outputs.length) return null;
  const supports = [...new Set((provider.supports || ["*"]).map(cleanExtension).filter(Boolean))];
  return {
    id: String(provider.id || "provider-" + (index + 1)),
    label: String(provider.label || provider.id || "Provider " + (index + 1)),
    version: provider.version ? String(provider.version) : null,
    command,
    args: provider.args.map((value) => String(value)),
    cwd: provider.cwd ? resolve2(String(provider.cwd)) : null,
    environment: provider.environment && typeof provider.environment === "object" ? Object.fromEntries(Object.entries(provider.environment).map(([key, value]) => [String(key), String(value)])) : {},
    supports,
    outputs,
    exactOutputs: [...new Set((provider.exactOutputs || []).map(cleanExtension).filter((output) => outputs.includes(output)))],
    timeoutMs: boundedInteger(
      provider.timeoutMs,
      DEFAULT_TIMEOUT_MS,
      `${provider.id || "provider"} timeoutMs`,
      1e3,
      24 * 60 * 60 * 1e3
    ),
    licensed: provider.licensed === true,
    discovered: provider.discovered === true,
    probeArgs: Array.isArray(provider.probeArgs) ? provider.probeArgs.map((value) => String(value)) : [],
    probeSuccessPattern: provider.probeSuccessPattern ? String(provider.probeSuccessPattern) : null,
    probeTimeoutMs: Math.max(1e3, Number(provider.probeTimeoutMs || 15e3)),
    ready: false,
    reason: "Provider has not passed preflight."
  };
}
async function runProviderProbe(provider, command) {
  if (!provider.probeArgs.length) {
    return { ok: false, detail: "No functional capability probe is configured." };
  }
  return new Promise((resolvePromise) => {
    let output = "";
    let settled = false;
    let timer = null;
    let terminalDetail = null;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      resolvePromise(result);
    };
    const child = spawn(command, provider.probeArgs, {
      cwd: provider.cwd || dirname2(command),
      env: { ...process.env, ...provider.environment },
      shell: false,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"]
    });
    const collect = (chunk) => {
      output = cappedText(output, String(chunk).replace(/\0/g, "")).slice(-8192);
    };
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);
    child.once("error", (error) => finish({ ok: false, detail: error.message }));
    child.once("close", (code, signal) => {
      if (terminalDetail) {
        finish({ ok: false, detail: terminalDetail });
        return;
      }
      const lines = output.trim().split(/\r?\n/).filter(Boolean);
      const matchingLine = provider.probeSuccessPattern ? lines.find((line) => line.includes(provider.probeSuccessPattern)) : null;
      const matched = !provider.probeSuccessPattern || !!matchingLine;
      const detail = matchingLine || lines[0] || (code === 0 ? "Capability sentinel was not emitted." : "No capability output.");
      finish({
        ok: code === 0 && matched,
        detail: (code === 0 ? detail : `Probe exited with ${signal ? "signal " + signal : "code " + code}. ${detail}`).slice(0, 500)
      });
    });
    timer = setTimeout(() => {
      terminalDetail = "Capability probe timed out.";
      terminateChildProcess(child).finally(() => finish({ ok: false, detail: terminalDetail }));
    }, provider.probeTimeoutMs);
  });
}
async function preflightProvider(provider) {
  const licensed = provider.licensed === true;
  const resolvedCommand = await resolveExecutable(provider.command, {
    cwd: provider.cwd || HERE2,
    env: { ...process.env, ...provider.environment }
  });
  const probe = licensed && resolvedCommand ? await runProviderProbe(provider, resolvedCommand) : { ok: false, detail: !licensed ? "Provider is not marked licensed/configured." : "Translator executable was not found." };
  const detectedVersion = probe.ok ? probe.detail.match(/\b\d+\.\d+(?:\.\d+)?(?:[-+][A-Za-z0-9.-]+)?\b/)?.[0] || null : null;
  return {
    ...provider,
    command: resolvedCommand || provider.command,
    version: provider.version || detectedVersion,
    licensed,
    ready: licensed && !!resolvedCommand && probe.ok,
    probe: probe.detail,
    reason: !licensed ? "Provider is not marked licensed/configured." : !resolvedCommand ? "Translator executable not found: " + provider.command : probe.ok ? "Executable passed capability preflight; every output is validated and exact fidelity requires a matching result report." : "Translator capability probe failed: " + probe.detail
  };
}
function environmentProvider(env) {
  const command = String(env.P3DW_CAD_COMMAND || "").trim();
  if (!command) return null;
  let args;
  try {
    args = JSON.parse(env.P3DW_CAD_ARGS || '["{input}","{output}"]');
  } catch (error) {
    throw new Error("P3DW_CAD_ARGS must be a JSON string array.");
  }
  if (!Array.isArray(args)) throw new Error("P3DW_CAD_ARGS must be a JSON string array.");
  let probeArgs;
  try {
    probeArgs = JSON.parse(env.P3DW_CAD_PROBE_ARGS || "[]");
  } catch (error) {
    throw new Error("P3DW_CAD_PROBE_ARGS must be a JSON string array.");
  }
  if (!Array.isArray(probeArgs)) {
    throw new Error("P3DW_CAD_PROBE_ARGS must be a JSON string array.");
  }
  return {
    id: env.P3DW_CAD_PROVIDER_ID || "environment-command",
    label: env.P3DW_CAD_PROVIDER_LABEL || "Configured CAD translator",
    version: env.P3DW_CAD_PROVIDER_VERSION || null,
    command,
    args,
    supports: String(env.P3DW_CAD_SUPPORTS || "*").split(","),
    outputs: String(env.P3DW_CAD_OUTPUTS || "step,glb").split(","),
    exactOutputs: String(env.P3DW_CAD_EXACT_OUTPUTS || "step").split(","),
    timeoutMs: Number(env.P3DW_CAD_TIMEOUT_MS || DEFAULT_TIMEOUT_MS),
    licensed: String(env.P3DW_CAD_LICENSED || "").toLowerCase() === "true",
    probeArgs,
    probeSuccessPattern: env.P3DW_CAD_PROBE_PATTERN || null,
    probeTimeoutMs: Number(env.P3DW_CAD_PROBE_TIMEOUT_MS || 15e3)
  };
}
async function loadBridgeConfig({
  configPath = process.env.P3DW_CAD_BRIDGE_CONFIG || DEFAULT_CONFIG_PATH,
  env = process.env
} = {}) {
  let disk = {};
  if (configPath && existsSync2(configPath)) {
    disk = JSON.parse(await readFile(configPath, "utf8"));
  }
  const providers = [...disk.providers || []];
  const fromEnvironment = environmentProvider(env);
  if (fromEnvironment) providers.unshift(fromEnvironment);
  if (disk.autoDiscoverOpenProviders !== false) {
    const discovered = await discoverOpenProviders({ env, bridgeDirectory: HERE2 });
    const configuredIds = new Set(providers.map((provider) => String(provider?.id || "")));
    providers.push(...discovered.filter((provider) => !configuredIds.has(provider.id)));
  }
  const configDirectory = configPath ? dirname2(resolve2(configPath)) : HERE2;
  const configuredAppPath = String(
    env.P3DW_CAD_APP_PATH || disk.appPath || DEFAULT_APP_PATH
  );
  const appPath = isAbsolute2(configuredAppPath) ? configuredAppPath : resolve2(configDirectory, configuredAppPath);
  return {
    host: "127.0.0.1",
    port: boundedInteger(
      env.P3DW_CAD_BRIDGE_PORT ?? disk.port,
      43879,
      "port",
      0,
      65535
    ),
    appPath,
    maxFileBytes: boundedInteger(
      disk.maxFileBytes,
      DEFAULT_MAX_FILE_BYTES,
      "maxFileBytes",
      1,
      Number.MAX_SAFE_INTEGER
    ),
    maxJobBytes: boundedInteger(
      disk.maxJobBytes,
      DEFAULT_MAX_JOB_BYTES,
      "maxJobBytes",
      1,
      Number.MAX_SAFE_INTEGER
    ),
    maxSourceFiles: boundedInteger(
      disk.maxSourceFiles,
      DEFAULT_MAX_SOURCE_FILES,
      "maxSourceFiles",
      1,
      65536
    ),
    maxOutputBytes: boundedInteger(
      disk.maxOutputBytes,
      DEFAULT_MAX_OUTPUT_BYTES,
      "maxOutputBytes",
      1,
      Number.MAX_SAFE_INTEGER
    ),
    maxConcurrentJobs: boundedInteger(
      disk.maxConcurrentJobs,
      DEFAULT_MAX_CONCURRENT_JOBS,
      "maxConcurrentJobs",
      1,
      64
    ),
    maxChunkBytes: boundedInteger(
      disk.maxChunkBytes,
      DEFAULT_MAX_CHUNK_BYTES,
      "maxChunkBytes",
      1,
      256 * 1024 * 1024
    ),
    inactiveUploadMs: boundedInteger(
      disk.inactiveUploadMs,
      DEFAULT_INACTIVE_UPLOAD_MS,
      "inactiveUploadMs",
      1e3,
      24 * 60 * 60 * 1e3
    ),
    providers: providers.map(normalizeProvider).filter(Boolean),
    providerCatalog: RECOMMENDED_PROVIDER_CATALOG
  };
}
function providerSupports(provider, extension) {
  return provider.supports.includes("*") || provider.supports.includes(extension);
}
function providerCoverage(providers) {
  const ready = providers.filter((provider) => provider.ready);
  return {
    wildcard: ready.some((provider) => provider.supports.includes("*")),
    supportedExtensions: [...new Set(ready.flatMap((provider) => provider.supports.filter((extension) => extension !== "*")))].sort(),
    exactOutputExtensions: [...new Set(ready.flatMap((provider) => provider.exactOutputs || []))].sort()
  };
}
function expandCommandArguments(template, values) {
  const replacements = new Map(Object.entries(values).map(([key, value]) => [`{${key}}`, String(value)]));
  return template.map((argument) => {
    let result = String(argument);
    for (const [token, value] of replacements) result = result.split(token).join(value);
    if (/\{(?:input|output|report|workDir|inputName|inputExt|outputExt)\}/.test(result)) {
      throw new Error(`Unknown or unresolved command placeholder in "${argument}".`);
    }
    return result;
  });
}
function formatFamily(extension) {
  const normalized = cleanExtension(extension);
  if (["step", "stp", "p21"].includes(normalized)) return "step";
  if (["iges", "igs"].includes(normalized)) return "iges";
  if (["brep", "brp"].includes(normalized)) return "brep";
  return normalized;
}
function reportFormatMatches(value, extension) {
  const family = formatFamily(extension);
  if (!family) return false;
  const rawTokens = String(value || "").toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean);
  if (rawTokens.some((token) => formatFamily(token) === family)) return true;
  if (!["step", "iges", "brep"].includes(family)) return false;
  return rawTokens.some((token) => token.split("_").some((component) => formatFamily(component) === family));
}
function outputFidelity(provider, sourceExtension, outputExtension, report = null, outputSha256 = null) {
  const exactContainer = EXACT_BREP_CONTAINERS.has(outputExtension) && provider.exactOutputs.includes(outputExtension);
  const solidCount = report?.topology?.solidCount;
  if (report?.schema === "p3dw.provider-result/1" && report.complete === true && !incompleteImportEvidence({ pipelineAudit: { conversion: { providerReport: report } } }) && report.fidelity === "exact-brep" && Number.isSafeInteger(solidCount) && solidCount > 0 && !!report.outputSha256 && report.outputSha256 === outputSha256 && exactContainer && reportFormatMatches(report.sourceFormat, sourceExtension) && reportFormatMatches(report.outputSchema, outputExtension)) {
    return "exact-brep";
  }
  return exactContainer ? "brep-unverified" : "tessellated";
}
function hasIgesRecord(text, section) {
  const lines = String(text || "").replace(/\r/g, "").split("\n");
  return lines.some((line) => line.length >= 73 && line[72] === section && /^\s*\d+\s*$/.test(line.slice(73, 80)));
}
async function scanAsciiFile(path, predicates, overlap = 2048) {
  const found = predicates.map(() => false);
  let carry = "";
  for await (const chunk of createReadStream(path)) {
    const text = carry + chunk.toString("ascii");
    predicates.forEach((predicate, index) => {
      if (!found[index] && predicate(text)) found[index] = true;
    });
    if (found.every(Boolean)) break;
    carry = text.slice(-overlap);
  }
  return found;
}
function nonNegativeInteger(value) {
  return Number.isSafeInteger(value) && value >= 0;
}
var GLB_UNSIGNED_COMPONENT_BYTES = Object.freeze({
  5121: 1,
  5123: 2,
  5125: 4
});
var GLB_ACCESSOR_SCAN_BYTES = 4 * 1024 * 1024;
function safeGlbRangeLength(count2, stride, itemBytes) {
  if (!Number.isSafeInteger(count2) || count2 <= 0 || !Number.isSafeInteger(stride) || stride <= 0 || !Number.isSafeInteger(itemBytes) || itemBytes <= 0 || count2 - 1 > Math.floor((Number.MAX_SAFE_INTEGER - itemBytes) / stride)) {
    return null;
  }
  return (count2 - 1) * stride + itemBytes;
}
function glbBufferViewRange(gltf, viewIndex, byteOffset, byteLength, binaryLength) {
  if (!nonNegativeInteger(viewIndex) || !nonNegativeInteger(byteOffset) || !Number.isSafeInteger(byteLength) || byteLength <= 0) return false;
  const bufferView = gltf.bufferViews?.[viewIndex];
  if (!bufferView || !nonNegativeInteger(bufferView.buffer) || bufferView.buffer !== 0 || !nonNegativeInteger(bufferView.byteLength) || !nonNegativeInteger(bufferView.byteOffset || 0)) return false;
  const buffer = gltf.buffers?.[0];
  if (!buffer || buffer.uri || !nonNegativeInteger(buffer.byteLength)) return false;
  const viewOffset = bufferView.byteOffset || 0;
  if (viewOffset > Number.MAX_SAFE_INTEGER - bufferView.byteLength || byteOffset > Number.MAX_SAFE_INTEGER - byteLength) return false;
  const viewEnd = viewOffset + bufferView.byteLength;
  return byteOffset + byteLength <= bufferView.byteLength && viewEnd <= buffer.byteLength && viewEnd <= binaryLength;
}
function glbAccessorBaseLayout(gltf, accessor, itemBytes, componentBytes, binaryLength) {
  if (accessor.bufferView === void 0) return null;
  if (!nonNegativeInteger(accessor.bufferView) || !nonNegativeInteger(accessor.byteOffset || 0) || (accessor.byteOffset || 0) % componentBytes) return false;
  const bufferView = gltf.bufferViews?.[accessor.bufferView];
  const stride = bufferView?.byteStride ?? itemBytes;
  if (!Number.isSafeInteger(stride) || stride < itemBytes || stride > 252 || stride % componentBytes) return false;
  const required = safeGlbRangeLength(accessor.count, stride, itemBytes);
  if (required === null || !glbBufferViewRange(
    gltf,
    accessor.bufferView,
    accessor.byteOffset || 0,
    required,
    binaryLength
  )) {
    return false;
  }
  return {
    count: accessor.count,
    offset: (bufferView.byteOffset || 0) + (accessor.byteOffset || 0),
    stride
  };
}
function glbAccessorSparseLayout(gltf, accessor, itemBytes, componentBytes, binaryLength) {
  if (accessor.sparse === void 0) return null;
  const sparse = accessor.sparse;
  const indexComponentType = sparse?.indices?.componentType;
  const indexBytes = GLB_UNSIGNED_COMPONENT_BYTES[indexComponentType];
  const count2 = sparse?.count;
  const indexOffset = sparse?.indices?.byteOffset || 0;
  const valueOffset = sparse?.values?.byteOffset || 0;
  const indexViewIndex = sparse?.indices?.bufferView;
  const valueViewIndex = sparse?.values?.bufferView;
  const indexView = gltf.bufferViews?.[indexViewIndex];
  const valueView = gltf.bufferViews?.[valueViewIndex];
  if (!Number.isSafeInteger(count2) || count2 <= 0 || count2 > accessor.count || !indexBytes || !nonNegativeInteger(indexOffset) || indexOffset % indexBytes || !nonNegativeInteger(valueOffset) || valueOffset % componentBytes || indexView?.byteStride !== void 0 || valueView?.byteStride !== void 0 || count2 > Math.floor(Number.MAX_SAFE_INTEGER / indexBytes) || count2 > Math.floor(Number.MAX_SAFE_INTEGER / itemBytes) || !glbBufferViewRange(
    gltf,
    indexViewIndex,
    indexOffset,
    count2 * indexBytes,
    binaryLength
  ) || !glbBufferViewRange(
    gltf,
    valueViewIndex,
    valueOffset,
    count2 * itemBytes,
    binaryLength
  )) return false;
  return {
    count: count2,
    indexComponentType,
    indexOffset: (indexView.byteOffset || 0) + indexOffset,
    valueOffset: (valueView.byteOffset || 0) + valueOffset
  };
}
function readGlbComponent(buffer, byteOffset, componentType) {
  if (componentType === 5121) return buffer.readUInt8(byteOffset);
  if (componentType === 5123) return buffer.readUInt16LE(byteOffset);
  if (componentType === 5125) return buffer.readUInt32LE(byteOffset);
  if (componentType === 5126) return buffer.readFloatLE(byteOffset);
  return null;
}
async function glbAccessorValuesPass(handle, binaryOffset, layout, componentType, componentCount, predicate) {
  const componentBytes = componentType === 5126 ? 4 : GLB_UNSIGNED_COMPONENT_BYTES[componentType];
  if (!componentBytes) return false;
  const itemBytes = componentBytes * componentCount;
  const itemsPerChunk = Math.max(
    1,
    Math.floor((GLB_ACCESSOR_SCAN_BYTES - itemBytes) / layout.stride) + 1
  );
  for (let start = 0; start < layout.count; start += itemsPerChunk) {
    const count2 = Math.min(itemsPerChunk, layout.count - start);
    const length = safeGlbRangeLength(count2, layout.stride, itemBytes);
    if (length === null) return false;
    const chunk = Buffer.allocUnsafe(length);
    const position = binaryOffset + layout.offset + start * layout.stride;
    if ((await handle.read(chunk, 0, length, position)).bytesRead !== length) return false;
    for (let item = 0; item < count2; item++) {
      const itemOffset = item * layout.stride;
      for (let component = 0; component < componentCount; component++) {
        const value = readGlbComponent(
          chunk,
          itemOffset + component * componentBytes,
          componentType
        );
        if (!predicate(value, start + item, component)) return false;
      }
    }
  }
  return true;
}
async function validGlbSparseIndices(handle, binaryOffset, sparse, accessorCount) {
  const bytes = GLB_UNSIGNED_COMPONENT_BYTES[sparse.indexComponentType];
  let previous = -1;
  return glbAccessorValuesPass(handle, binaryOffset, {
    count: sparse.count,
    offset: sparse.indexOffset,
    stride: bytes
  }, sparse.indexComponentType, 1, (value) => {
    if (!Number.isSafeInteger(value) || value <= previous || value >= accessorCount) {
      return false;
    }
    previous = value;
    return true;
  });
}
async function validGlbPositionAccessor(handle, binaryOffset, gltf, accessor, binaryLength) {
  if (!accessor || accessor.type !== "VEC3" || accessor.componentType !== 5126 || !Number.isSafeInteger(accessor.count) || accessor.count <= 0 || !nonNegativeInteger(accessor.byteOffset || 0)) return false;
  const itemBytes = 12;
  const base = glbAccessorBaseLayout(gltf, accessor, itemBytes, 4, binaryLength);
  if (base === false) return false;
  const sparse = glbAccessorSparseLayout(gltf, accessor, itemBytes, 4, binaryLength);
  if (sparse === false || !base && !sparse) return false;
  if (base && !await glbAccessorValuesPass(
    handle,
    binaryOffset,
    base,
    5126,
    3,
    Number.isFinite
  )) return false;
  if (sparse) {
    if (!await validGlbSparseIndices(handle, binaryOffset, sparse, accessor.count)) return false;
    if (!await glbAccessorValuesPass(handle, binaryOffset, {
      count: sparse.count,
      offset: sparse.valueOffset,
      stride: itemBytes
    }, 5126, 3, Number.isFinite)) return false;
  }
  return { count: accessor.count, base, sparse };
}
async function validGlbIndexAccessor(handle, binaryOffset, gltf, accessor, positionCount, binaryLength) {
  const componentBytes = GLB_UNSIGNED_COMPONENT_BYTES[accessor?.componentType];
  if (!accessor || accessor.type !== "SCALAR" || !componentBytes || accessor.normalized === true || !Number.isSafeInteger(accessor.count) || accessor.count <= 0 || !nonNegativeInteger(accessor.byteOffset || 0)) return false;
  const base = glbAccessorBaseLayout(
    gltf,
    accessor,
    componentBytes,
    componentBytes,
    binaryLength
  );
  if (base === false) return false;
  const sparse = glbAccessorSparseLayout(
    gltf,
    accessor,
    componentBytes,
    componentBytes,
    binaryLength
  );
  if (sparse === false || !base && !sparse) return false;
  const indexValueIsValid = (value) => Number.isSafeInteger(value) && value < positionCount;
  if (base && !await glbAccessorValuesPass(
    handle,
    binaryOffset,
    base,
    accessor.componentType,
    1,
    indexValueIsValid
  )) return false;
  if (sparse) {
    if (!await validGlbSparseIndices(handle, binaryOffset, sparse, accessor.count)) return false;
    if (!await glbAccessorValuesPass(handle, binaryOffset, {
      count: sparse.count,
      offset: sparse.valueOffset,
      stride: componentBytes
    }, accessor.componentType, 1, indexValueIsValid)) return false;
  }
  return {
    count: accessor.count,
    base,
    sparse,
    componentType: accessor.componentType
  };
}
function validGlbTriangleElementCount(count2, mode) {
  if (!Number.isSafeInteger(count2) || count2 < 3) return false;
  return mode === 4 ? count2 % 3 === 0 : mode === 5 || mode === 6;
}
function createGlbBinaryReader(handle, binaryOffset, binaryLength) {
  const pageBytes = GLB_ACCESSOR_SCAN_BYTES;
  const overlapBytes = 256;
  const maxCachedPages = 8;
  const pages = /* @__PURE__ */ new Map();
  const page = async (relativeOffset) => {
    const pageStart = Math.floor(relativeOffset / pageBytes) * pageBytes;
    let data = pages.get(pageStart);
    if (data) {
      pages.delete(pageStart);
      pages.set(pageStart, data);
      return { data, pageStart };
    }
    const length = Math.min(
      pageBytes + overlapBytes,
      binaryLength - pageStart
    );
    if (!Number.isSafeInteger(length) || length <= 0) return null;
    data = Buffer.allocUnsafe(length);
    let bytesRead = 0;
    while (bytesRead < length) {
      const result = await handle.read(
        data,
        bytesRead,
        length - bytesRead,
        binaryOffset + pageStart + bytesRead
      );
      if (!result.bytesRead) return null;
      bytesRead += result.bytesRead;
    }
    pages.set(pageStart, data);
    while (pages.size > maxCachedPages) pages.delete(pages.keys().next().value);
    return { data, pageStart };
  };
  return {
    async components(relativeOffset, componentType, componentCount) {
      const componentBytes = componentType === 5126 ? 4 : GLB_UNSIGNED_COMPONENT_BYTES[componentType];
      const byteLength = componentBytes * componentCount;
      if (!componentBytes || !nonNegativeInteger(relativeOffset) || !Number.isSafeInteger(byteLength) || byteLength <= 0 || relativeOffset > binaryLength - byteLength) return null;
      const loaded = await page(relativeOffset);
      if (!loaded) return null;
      const offset = relativeOffset - loaded.pageStart;
      if (offset < 0 || offset + byteLength > loaded.data.length) return null;
      const values = new Array(componentCount);
      for (let component = 0; component < componentCount; component++) {
        values[component] = readGlbComponent(
          loaded.data,
          offset + component * componentBytes,
          componentType
        );
      }
      return values;
    }
  };
}
async function glbSparseOrdinal(reader, sparse, accessorIndex) {
  if (!sparse) return -1;
  const componentBytes = GLB_UNSIGNED_COMPONENT_BYTES[sparse.indexComponentType];
  let low = 0;
  let high = sparse.count - 1;
  while (low <= high) {
    const middle = low + (high - low >> 1);
    const values = await reader.components(
      sparse.indexOffset + middle * componentBytes,
      sparse.indexComponentType,
      1
    );
    if (!values) return null;
    const value = values[0];
    if (value === accessorIndex) return middle;
    if (value < accessorIndex) low = middle + 1;
    else high = middle - 1;
  }
  return -1;
}
async function readGlbPosition(reader, position, vertexIndex) {
  const sparseOrdinal = await glbSparseOrdinal(
    reader,
    position.sparse,
    vertexIndex
  );
  if (sparseOrdinal === null) return null;
  if (sparseOrdinal >= 0) {
    return reader.components(
      position.sparse.valueOffset + sparseOrdinal * 12,
      5126,
      3
    );
  }
  if (position.base) {
    return reader.components(
      position.base.offset + vertexIndex * position.base.stride,
      5126,
      3
    );
  }
  return [0, 0, 0];
}
async function readGlbIndex(reader, indices, elementIndex) {
  const componentBytes = GLB_UNSIGNED_COMPONENT_BYTES[indices.componentType];
  const sparseOrdinal = await glbSparseOrdinal(
    reader,
    indices.sparse,
    elementIndex
  );
  if (sparseOrdinal === null) return null;
  const relativeOffset = sparseOrdinal >= 0 ? indices.sparse.valueOffset + sparseOrdinal * componentBytes : indices.base ? indices.base.offset + elementIndex * indices.base.stride : -1;
  if (relativeOffset < 0) return 0;
  const values = await reader.components(
    relativeOffset,
    indices.componentType,
    1
  );
  return values ? values[0] : null;
}
function glbTriangleHasFiniteNonzeroArea(a, b, c) {
  if (!a || !b || !c) return false;
  const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  if (!ab.every(Number.isFinite) || !ac.every(Number.isFinite)) return false;
  const scale = Math.max(...ab.map(Math.abs), ...ac.map(Math.abs));
  if (!Number.isFinite(scale) || scale === 0) return false;
  const ux = ab[0] / scale;
  const uy = ab[1] / scale;
  const uz = ab[2] / scale;
  const vx = ac[0] / scale;
  const vy = ac[1] / scale;
  const vz = ac[2] / scale;
  const cross = [
    uy * vz - uz * vy,
    uz * vx - ux * vz,
    ux * vy - uy * vx
  ];
  return cross.every(Number.isFinite) && cross.some((value) => value !== 0);
}
async function glbPrimitiveHasFiniteNonzeroTriangle(reader, mode, position, indices = null) {
  const elementCount = indices?.count ?? position.count;
  const positionCache = /* @__PURE__ */ new Map();
  const readVertex = async (elementIndex) => {
    const vertexIndex = indices ? await readGlbIndex(reader, indices, elementIndex) : elementIndex;
    if (!Number.isSafeInteger(vertexIndex)) return null;
    if (positionCache.has(vertexIndex)) return positionCache.get(vertexIndex);
    const value = await readGlbPosition(reader, position, vertexIndex);
    if (positionCache.size >= 16384) {
      positionCache.delete(positionCache.keys().next().value);
    }
    positionCache.set(vertexIndex, value);
    return value;
  };
  const triangleHasArea = async (aElement, bElement, cElement) => glbTriangleHasFiniteNonzeroArea(
    await readVertex(aElement),
    await readVertex(bElement),
    await readVertex(cElement)
  );
  if (mode === 4) {
    for (let element = 0; element < elementCount; element += 3) {
      if (await triangleHasArea(element, element + 1, element + 2)) return true;
    }
  } else if (mode === 5) {
    for (let element = 2; element < elementCount; element++) {
      if (await triangleHasArea(element - 2, element - 1, element)) return true;
    }
  } else {
    for (let element = 2; element < elementCount; element++) {
      if (await triangleHasArea(0, element - 1, element)) return true;
    }
  }
  return false;
}
async function validateGlbTrianglePrimitive(handle, binaryOffset, gltf, primitive, binaryLength, reader) {
  const mode = primitive?.mode === void 0 ? 4 : primitive.mode;
  if (![4, 5, 6].includes(mode)) return null;
  const accessorIndex = primitive?.attributes?.POSITION;
  const positionAccessor = nonNegativeInteger(accessorIndex) ? gltf.accessors?.[accessorIndex] : null;
  const position = await validGlbPositionAccessor(
    handle,
    binaryOffset,
    gltf,
    positionAccessor,
    binaryLength
  );
  if (!position) return false;
  if (primitive.indices === void 0) {
    return validGlbTriangleElementCount(position.count, mode) && await glbPrimitiveHasFiniteNonzeroTriangle(reader, mode, position);
  }
  const indexAccessor = nonNegativeInteger(primitive.indices) ? gltf.accessors?.[primitive.indices] : null;
  const indices = await validGlbIndexAccessor(
    handle,
    binaryOffset,
    gltf,
    indexAccessor,
    position.count,
    binaryLength
  );
  return !!indices && validGlbTriangleElementCount(indices.count, mode) && await glbPrimitiveHasFiniteNonzeroTriangle(
    reader,
    mode,
    position,
    indices
  );
}
function glbDefaultSceneGeometryStatus(gltf, geometryMeshes, invalidMeshes) {
  if (!Array.isArray(gltf.scenes) || !gltf.scenes.length || !Array.isArray(gltf.nodes)) return { valid: false, invalid: false };
  const sceneIndex = gltf.scene === void 0 ? 0 : gltf.scene;
  if (!nonNegativeInteger(sceneIndex) || sceneIndex >= gltf.scenes.length) {
    return { valid: false, invalid: true };
  }
  const roots = gltf.scenes[sceneIndex]?.nodes;
  if (!Array.isArray(roots)) return { valid: false, invalid: true };
  const state = new Uint8Array(gltf.nodes.length);
  const parents = new Int32Array(gltf.nodes.length);
  parents.fill(-2);
  let valid = false;
  let invalid = false;
  const pending = [];
  for (let rootIndex = roots.length - 1; rootIndex >= 0; rootIndex--) {
    const nodeIndex = roots[rootIndex];
    if (!nonNegativeInteger(nodeIndex) || nodeIndex >= gltf.nodes.length || parents[nodeIndex] !== -2) return { valid: false, invalid: true };
    parents[nodeIndex] = -1;
    pending.push({ nodeIndex, exiting: false });
    while (pending.length) {
      const frame = pending.pop();
      if (frame.exiting) {
        state[frame.nodeIndex] = 2;
        continue;
      }
      if (state[frame.nodeIndex] !== 0) {
        return { valid: false, invalid: true };
      }
      state[frame.nodeIndex] = 1;
      const node = gltf.nodes[frame.nodeIndex];
      if (!node || typeof node !== "object" || Array.isArray(node)) {
        return { valid: false, invalid: true };
      }
      if (node.mesh !== void 0) {
        if (!nonNegativeInteger(node.mesh) || node.mesh >= (gltf.meshes?.length || 0)) {
          return { valid: false, invalid: true };
        }
        if (geometryMeshes.has(node.mesh)) valid = true;
        if (invalidMeshes.has(node.mesh)) invalid = true;
      }
      const children = node.children === void 0 ? [] : node.children;
      if (!Array.isArray(children)) return { valid: false, invalid: true };
      pending.push({ nodeIndex: frame.nodeIndex, exiting: true });
      for (let childIndex = children.length - 1; childIndex >= 0; childIndex--) {
        const child = children[childIndex];
        if (!nonNegativeInteger(child) || child >= gltf.nodes.length || parents[child] !== -2 || state[child] !== 0) {
          return { valid: false, invalid: true };
        }
        parents[child] = frame.nodeIndex;
        pending.push({ nodeIndex: child, exiting: false });
      }
    }
  }
  return { valid, invalid };
}
async function validateGlbOutput(path, size) {
  const handle = await open(path, "r");
  try {
    const header = Buffer.alloc(12);
    if ((await handle.read(header, 0, 12, 0)).bytesRead !== 12 || header.toString("ascii", 0, 4) !== "glTF" || header.readUInt32LE(4) !== 2 || header.readUInt32LE(8) !== size) {
      throw new Error("Translator produced an invalid or truncated GLB header.");
    }
    let offset = 12;
    let chunkIndex = 0;
    let gltf = null;
    let binaryLength = 0;
    let binaryOffset = -1;
    while (offset < size) {
      const chunkHeader = Buffer.alloc(8);
      if ((await handle.read(chunkHeader, 0, 8, offset)).bytesRead !== 8) {
        throw new Error("Translator produced a truncated GLB chunk header.");
      }
      const chunkLength = chunkHeader.readUInt32LE(0);
      const chunkType = chunkHeader.readUInt32LE(4);
      if (chunkLength % 4 !== 0 || offset + 8 + chunkLength > size) {
        throw new Error("Translator produced an invalid GLB chunk length.");
      }
      if (chunkIndex === 0) {
        if (chunkType !== 1313821514 || !chunkLength || chunkLength > 64 * 1024 * 1024) {
          throw new Error("Translator GLB is missing a bounded first JSON chunk.");
        }
        const json = Buffer.alloc(chunkLength);
        if ((await handle.read(json, 0, chunkLength, offset + 8)).bytesRead !== chunkLength) {
          throw new Error("Translator produced a truncated GLB JSON chunk.");
        }
        try {
          gltf = JSON.parse(json.toString("utf8").replace(/[\u0000\u0020]+$/g, ""));
        } catch (error) {
          throw new Error("Translator GLB contains invalid JSON metadata.");
        }
      } else if (chunkType === 5130562 && !binaryLength) {
        binaryLength = chunkLength;
        binaryOffset = offset + 8;
      }
      offset += 8 + chunkLength;
      chunkIndex++;
    }
    if (offset !== size || !gltf || String(gltf.asset?.version || "").split(".")[0] !== "2") {
      throw new Error("Translator GLB is not a complete glTF 2 container.");
    }
    const geometryMeshes = /* @__PURE__ */ new Set();
    const invalidMeshes = /* @__PURE__ */ new Set();
    const binaryReader = binaryOffset >= 0 ? createGlbBinaryReader(handle, binaryOffset, binaryLength) : null;
    for (let meshIndex = 0; meshIndex < (gltf.meshes || []).length; meshIndex++) {
      const mesh = gltf.meshes[meshIndex];
      if (!Array.isArray(mesh?.primitives)) continue;
      for (const primitive of mesh.primitives) {
        const verdict = binaryOffset >= 0 && await validateGlbTrianglePrimitive(
          handle,
          binaryOffset,
          gltf,
          primitive,
          binaryLength,
          binaryReader
        );
        if (verdict === true) geometryMeshes.add(meshIndex);
        else if (verdict === false) invalidMeshes.add(meshIndex);
      }
    }
    const geometryStatus = glbDefaultSceneGeometryStatus(
      gltf,
      geometryMeshes,
      invalidMeshes
    );
    if (geometryStatus.invalid) {
      throw new Error(
        "Translator GLB default scene contains malformed or non-finite triangle geometry, collapsed triangles, or an invalid scene graph."
      );
    }
    if (!geometryStatus.valid) {
      throw new Error(
        "Translator GLB default scene contains no reachable, buffer-backed POSITION geometry forming valid triangles."
      );
    }
  } finally {
    await handle.close();
  }
}
async function validateOutput(path, extension, maxOutputBytes) {
  const info = await stat2(path);
  if (!info.isFile() || !info.size) throw new Error("Translator output is empty.");
  if (info.size > maxOutputBytes) {
    throw new Error("Translator output exceeds the " + maxOutputBytes + " byte safety limit.");
  }
  const stream = createReadStream(path, { start: 0, end: Math.min(info.size - 1, 65535) });
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  const head = Buffer.concat(chunks);
  if (["step", "stp", "p21"].includes(extension)) {
    const headText = head.toString("ascii").replace(/^\uFEFF/, "").trimStart();
    if (!headText.startsWith("ISO-10303-21;") || !/\bHEADER\s*;/i.test(headText) || !/\bDATA\s*;/i.test(headText)) {
      throw new Error("Translator claimed STEP output without an ISO-10303-21 header.");
    }
    const tailStream = createReadStream(path, {
      start: Math.max(0, info.size - 4096),
      end: info.size - 1
    });
    const tailChunks = [];
    for await (const chunk of tailStream) tailChunks.push(chunk);
    if (!Buffer.concat(tailChunks).toString("ascii").trimEnd().endsWith("END-ISO-10303-21;")) {
      throw new Error("Translator produced a truncated STEP container without its terminal marker.");
    }
    const [hasGeometry] = await scanAsciiFile(path, [
      (text) => STEP_RENDERABLE_ENTITY.test(text)
    ]);
    if (!hasGeometry) {
      throw new Error(
        "Translator STEP container contains no recognized renderable geometry entities."
      );
    }
  }
  if (["iges", "igs"].includes(extension)) {
    const tailStream = createReadStream(path, {
      start: Math.max(0, info.size - 65536),
      end: info.size - 1
    });
    const tailChunks = [];
    for await (const chunk of tailStream) tailChunks.push(chunk);
    const tail = Buffer.concat(tailChunks).toString("ascii");
    if (!hasIgesRecord(head.toString("ascii"), "S") || !hasIgesRecord(tail, "T")) {
      throw new Error("Translator produced an invalid IGES container without S/T records.");
    }
    const [hasDirectoryEntry, hasParameterData] = await scanAsciiFile(path, [
      (text) => hasIgesRecord(text, "D"),
      (text) => hasIgesRecord(text, "P")
    ]);
    if (!hasDirectoryEntry || !hasParameterData) {
      throw new Error(
        "Translator IGES container contains no directory-entry and parameter geometry records."
      );
    }
  }
  if (["brep", "brp"].includes(extension)) {
    if (!/CASCADE Topology V\d+/i.test(head.toString("ascii"))) {
      throw new Error("Translator produced an invalid OpenCascade BREP container.");
    }
    const [hasShapes, hasTopology] = await scanAsciiFile(path, [
      (text) => BREP_SHAPE_COUNT.test(text),
      (text) => BREP_TOPOLOGY_RECORD.test(text)
    ]);
    if (!hasShapes || !hasTopology) {
      throw new Error("Translator OpenCascade BREP contains no topology records.");
    }
  }
  if (extension === "glb") await validateGlbOutput(path, info.size);
  return info.size;
}
async function sha256File(path, job = null) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(path)) {
    if (job) throwIfJobCancelled(job);
    hash.update(chunk);
  }
  return hash.digest("hex");
}
var childTerminations = /* @__PURE__ */ new WeakMap();
async function waitWithin(promise, milliseconds) {
  let timer;
  try {
    await Promise.race([promise, new Promise((resolvePromise) => {
      timer = setTimeout(resolvePromise, milliseconds);
    })]);
  } finally {
    clearTimeout(timer);
  }
}
function terminateChildProcess(child) {
  if (!child) return Promise.resolve();
  if (childTerminations.has(child)) return childTerminations.get(child);
  const termination = (async () => {
    let onExit;
    try {
      if (child.exitCode !== null || child.signalCode) return;
      const exited = new Promise((resolvePromise) => {
        onExit = resolvePromise;
        child.once("exit", onExit);
      });
      if (process.platform === "win32" && Number.isInteger(child.pid)) {
        try {
          const killer = spawn("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], {
            shell: false,
            windowsHide: true,
            stdio: "ignore"
          });
          const killerFinished = new Promise((resolvePromise) => {
            killer.once("close", resolvePromise);
            killer.once("error", resolvePromise);
          });
          await waitWithin(killerFinished, 3e3);
        } catch (error) {
          child.kill();
        }
      } else {
        child.kill("SIGTERM");
      }
      await waitWithin(exited, 3e3);
      if (child.exitCode === null && !child.signalCode) child.kill("SIGKILL");
      await waitWithin(exited, 1e3);
    } finally {
      if (onExit) child.off("exit", onExit);
      child.stdout?.destroy();
      child.stderr?.destroy();
    }
  })();
  childTerminations.set(child, termination);
  return termination;
}
function verifyOcctOutput(job, outputPath, outputExtension, timeoutMs) {
  const format = formatFamily(outputExtension);
  return new Promise((resolvePromise, rejectPromise) => {
    let stdout = "";
    let stderr = "";
    let settled = false;
    let timer = null;
    let terminalError = null;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      if (job.child === child) job.child = null;
      callback(value);
    };
    const child = spawn(process.execPath, [OCCT_VERIFIER_PATH, outputPath, format], {
      cwd: dirname2(OCCT_VERIFIER_PATH),
      env: process.env,
      shell: false,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"]
    });
    job.child = child;
    child.stdout.on("data", (chunk) => {
      stdout = cappedText(stdout, chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr = cappedText(stderr, chunk);
    });
    timer = setTimeout(() => {
      terminalError = new Error(
        `OpenCascade semantic validation exceeded ${Math.round(timeoutMs / 6e4)} minutes.`
      );
      terminateChildProcess(child).finally(() => finish(rejectPromise, terminalError));
    }, timeoutMs);
    child.once("error", (error) => finish(
      rejectPromise,
      new Error("OpenCascade semantic verifier could not start: " + error.message)
    ));
    child.once("close", (code) => {
      if (terminalError) return finish(rejectPromise, terminalError);
      if (job.cancelled) {
        return finish(rejectPromise, new Error("CAD conversion cancelled."));
      }
      if (code !== 0) {
        return finish(rejectPromise, new Error(
          "OpenCascade semantic verification rejected the output: " + (stderr.trim().slice(-800) || `verifier exited with code ${code}`)
        ));
      }
      try {
        const result = JSON.parse(stdout.trim());
        if (result.schema !== "p3dw.occt-semantic-validation/1" || result.validator !== "occt-import-js" || result.format !== format || !Number.isSafeInteger(result.meshCount) || result.meshCount <= 0 || !Number.isSafeInteger(result.triangleCount) || result.triangleCount <= 0 || !/^[a-f0-9]{64}$/.test(result.outputSha256)) {
          throw new Error("verifier returned an invalid result contract");
        }
        finish(resolvePromise, result);
      } catch (error) {
        finish(rejectPromise, new Error(
          "OpenCascade semantic verifier returned invalid evidence: " + error.message
        ));
      }
    });
  });
}
function runChild(job, provider, outputPath, outputExtension, reportPath) {
  return new Promise((resolvePromise, rejectPromise) => {
    let settled = false;
    let timer = null;
    let terminalError = null;
    const primary = job.files.get(job.manifest.primaryFileId);
    const values = {
      input: primary.path,
      output: outputPath,
      report: reportPath,
      workDir: job.directory,
      inputName: primary.name,
      inputExt: fileExtension(primary.name),
      outputExt: outputExtension
    };
    const args = expandCommandArguments(provider.args, values);
    const childEnvironment = Object.fromEntries(Object.entries(provider.environment).map(([key, value]) => [key, expandCommandArguments([value], values)[0]]));
    const child = spawn(provider.command, args, {
      cwd: provider.cwd || job.directory,
      env: { ...process.env, ...childEnvironment },
      shell: false,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"]
    });
    job.child = child;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      if (job.child === child) job.child = null;
      callback(value);
    };
    child.stdout.on("data", (chunk) => {
      job.stdout = cappedText(job.stdout, chunk);
      job.message = String(chunk).trim().slice(-240) || job.message;
    });
    child.stderr.on("data", (chunk) => {
      job.stderr = cappedText(job.stderr, chunk);
      const message = String(chunk).trim();
      if (message) job.message = message.slice(-240);
    });
    timer = setTimeout(() => {
      terminalError = new Error(
        `${provider.label} exceeded its ${Math.round(provider.timeoutMs / 6e4)} minute time limit.`
      );
      terminateChildProcess(child).finally(() => finish(rejectPromise, terminalError));
    }, provider.timeoutMs);
    child.once("error", (error) => {
      finish(rejectPromise, new Error(`${provider.label} could not start: ${error.message}`));
    });
    child.once("close", (code, signal) => {
      if (terminalError) {
        finish(rejectPromise, terminalError);
      } else if (job.cancelled) {
        finish(rejectPromise, new Error("CAD conversion cancelled."));
      } else if (code === 0) {
        finish(resolvePromise);
      } else {
        finish(rejectPromise, new Error(
          `${provider.label} exited with ${signal ? `signal ${signal}` : `code ${code}`}. ` + `${job.stderr.trim().slice(-800)}`.trim()
        ));
      }
    });
  });
}
async function executeJob(job, config) {
  throwIfJobCancelled(job);
  const primary = job.files.get(job.manifest.primaryFileId);
  const extension = fileExtension(primary.name);
  const preferred = (job.manifest.target?.preferred || ["step", "glb"]).map(cleanExtension).filter(Boolean);
  const providers = config.providers.filter((provider) => provider.ready && providerSupports(provider, extension));
  if (!providers.length) throw new Error(extension ? "No ready translator supports ." + extension + "." : "No ready wildcard translator supports this extensionless source.");
  const allCandidates = providers.flatMap((provider, providerIndex) => provider.outputs.map((outputExtension, outputIndex) => ({
    provider,
    outputExtension,
    providerIndex,
    outputIndex
  })));
  const selections = [];
  const selected = /* @__PURE__ */ new Set();
  const add = (candidate) => {
    const key = candidate.provider.id + "\0" + candidate.outputExtension;
    if (!selected.has(key)) {
      selected.add(key);
      selections.push(candidate);
    }
  };
  for (const wanted of preferred) {
    allCandidates.filter((candidate) => formatFamily(candidate.outputExtension) === formatFamily(wanted)).sort((left, right) => Number(right.provider.exactOutputs.includes(right.outputExtension)) - Number(left.provider.exactOutputs.includes(left.outputExtension)) || left.providerIndex - right.providerIndex || left.outputIndex - right.outputIndex).forEach(add);
  }
  allCandidates.forEach(add);
  job.phase = "translating";
  job.progress = 0.72;
  job.lastActivity = Date.now();
  const failures = [];
  for (const { provider, outputExtension } of selections) {
    job.translator = {
      provider: provider.id,
      label: provider.label,
      version: provider.version
    };
    throwIfJobCancelled(job);
    const outputName = modelBaseName(primary.name) + "." + outputExtension;
    const outputPath = pathInside(job.directory, join2("_outputs", outputName));
    const reportPath = pathInside(job.directory, join2(
      "_outputs",
      provider.id + "-" + outputExtension + "-report.json"
    ));
    await mkdir(dirname2(outputPath), { recursive: true });
    throwIfJobCancelled(job);
    await rm(reportPath, { force: true });
    throwIfJobCancelled(job);
    try {
      job.phase = "translating";
      job.message = "Translating to " + outputExtension.toUpperCase() + " with " + provider.label;
      await runChild(job, provider, outputPath, outputExtension, reportPath);
      throwIfJobCancelled(job);
      job.phase = "validating";
      job.progress = 0.94;
      job.message = "Validating " + outputName;
      const bytes = await validateOutput(
        outputPath,
        outputExtension,
        config.maxOutputBytes
      );
      throwIfJobCancelled(job);
      const semanticValidation = EXACT_BREP_CONTAINERS.has(outputExtension) ? await verifyOcctOutput(job, outputPath, outputExtension, provider.timeoutMs) : null;
      throwIfJobCancelled(job);
      const sha256 = await sha256File(outputPath, job);
      throwIfJobCancelled(job);
      if (semanticValidation && semanticValidation.outputSha256 !== sha256) {
        throw new Error(
          "OpenCascade evidence hash does not match the validated output bytes."
        );
      }
      let providerReport = null;
      if (existsSync2(reportPath)) {
        const reportInfo = await stat2(reportPath);
        throwIfJobCancelled(job);
        if (reportInfo.size > MAX_JSON_BYTES) throw new Error("Provider result report is too large.");
        providerReport = JSON.parse(await readFile(reportPath, "utf8"));
        throwIfJobCancelled(job);
        if (providerReport.schema !== "p3dw.provider-result/1") {
          throw new Error("Provider result report has an unsupported schema.");
        }
        if (providerReport.outputSha256 && providerReport.outputSha256 !== sha256) {
          throw new Error("Provider result report output hash does not match the file.");
        }
        const uploadedPaths = new Map([...job.files.values()].map((file) => [file.relativePath.toLowerCase(), file.relativePath]));
        const consumedSourcePaths = [];
        if (providerReport.consumedSourcePaths !== void 0 && !Array.isArray(providerReport.consumedSourcePaths)) {
          throw new Error("Provider result consumedSourcePaths must be an array.");
        }
        for (const rawPath of providerReport.consumedSourcePaths || []) {
          const safePath = safeRelativePath(rawPath);
          const canonical = uploadedPaths.get(safePath.toLowerCase());
          if (!canonical) {
            throw new Error(
              "Provider result reports a consumed source path that was not uploaded: " + safePath
            );
          }
          if (!consumedSourcePaths.includes(canonical)) consumedSourcePaths.push(canonical);
        }
        job.unresolvedExternalReferences = Array.isArray(providerReport.unresolvedExternalReferences) ? providerReport.unresolvedExternalReferences.map((value) => String(value).slice(0, 500)) : null;
        if (Array.isArray(providerReport.warnings)) {
          job.warnings.push(...providerReport.warnings.map((value) => String(value).slice(0, 1e3)));
        }
        job.providerReport = {
          ...boundedProviderReportSummary(providerReport),
          schema: providerReport.schema,
          complete: typeof providerReport.complete === "boolean" ? providerReport.complete : null,
          fidelity: providerReport.fidelity || null,
          sourceFormat: providerReport.sourceFormat || null,
          outputSchema: providerReport.outputSchema || null,
          topology: providerReport.topology || null,
          assembly: providerReport.assembly || null,
          pmi: providerReport.pmi || null,
          // Keep an explicit length declaration for the browser import
          // boundary, including invalid values that it must reject.
          ...providerReport.outputUnit !== void 0 ? { outputUnit: providerReport.outputUnit } : {},
          consumedSourcePaths
        };
      }
      const fidelity = outputFidelity(
        provider,
        extension,
        outputExtension,
        providerReport,
        sha256
      );
      throwIfJobCancelled(job);
      const id = "o" + job.outputs.length;
      job.outputs.push({
        id,
        name: outputName,
        path: outputPath,
        extension: outputExtension,
        kind: fidelity === "exact-brep" ? "exact" : fidelity === "tessellated" ? "visual" : "candidate-brep",
        bytes,
        sha256,
        semanticValidation,
        mediaType: outputExtension === "glb" ? "model/gltf-binary" : "application/octet-stream"
      });
      job.decision = { requested: preferred, actual: outputExtension, fidelity };
      break;
    } catch (error) {
      if (job.cancelled) throw error;
      failures.push(provider.label + "/" + outputExtension.toUpperCase() + ": " + error.message);
      try {
        await rm(outputPath, { force: true });
      } catch (ignored) {
      }
    }
    if (job.outputs.length) break;
  }
  if (!job.outputs.length) {
    throw new Error("All translation providers/targets failed. " + failures.join(" | "));
  }
  job.warnings.push(...failures.map((message) => "Fallback after " + message));
  throwIfJobCancelled(job);
  job.phase = "ready";
  job.progress = 1;
  job.message = "Ready: " + job.outputs[0].name;
  job.completedAt = Date.now();
  job.lastActivity = job.completedAt;
}
async function readJson(request) {
  const chunks = [];
  let bytes = 0;
  for await (const chunk of request) {
    bytes += chunk.length;
    if (bytes > MAX_JSON_BYTES) throw new Error("JSON request is too large.");
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
}
function sendJson(response, status, data) {
  const body = Buffer.from(JSON.stringify(data));
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": body.length,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(body);
}
function localRequest(request) {
  const address = String(request.socket.remoteAddress || "");
  if (!(address === "127.0.0.1" || address === "::1" || address === "::ffff:127.0.0.1")) return false;
  const hostHeader = String(request.headers.host || "").toLowerCase();
  const host = hostHeader.split(":")[0];
  if (!LOOPBACK_HOSTS.has(host)) return false;
  const origin = String(request.headers.origin || "");
  return !origin || origin === `http://${hostHeader}` || origin === `https://${hostHeader}`;
}
function publicJob(job) {
  const primary = job.files.get(job.manifest.primaryFileId);
  return {
    schema: "p3dw.import-result/1",
    jobId: job.id,
    phase: job.phase,
    progress: job.progress,
    message: job.message,
    error: job.error,
    source: primary ? {
      name: primary.name,
      bytes: primary.size,
      sha256: primary.sha256 || null
    } : null,
    sources: [...job.files.values()].map((file) => ({
      name: file.name,
      relativePath: file.relativePath,
      bytes: file.size,
      sha256: file.sha256 || null
    })),
    sourceSetSha256: job.sourceSetSha256 || null,
    translator: job.translator,
    decision: job.decision,
    providerReport: job.providerReport || null,
    outputs: job.outputs.map(({ path, ...output }) => output),
    unresolvedExternalReferences: job.unresolvedExternalReferences,
    warnings: job.warnings
  };
}
async function createJob(config, manifest) {
  if (manifest.schema !== JOB_SCHEMA || !Array.isArray(manifest.files) || !manifest.files.length || !manifest.primaryFileId) {
    throw new Error("Invalid " + JOB_SCHEMA + " manifest.");
  }
  if (manifest.files.length > config.maxSourceFiles) {
    throw new Error(
      `CAD source set exceeds the ${config.maxSourceFiles} file safety limit.`
    );
  }
  const ids = /* @__PURE__ */ new Set();
  const relativePaths = /* @__PURE__ */ new Set();
  const descriptors = [];
  let totalBytes = 0;
  for (const file of manifest.files) {
    if (typeof file.id !== "string" || !/^[A-Za-z0-9._-]{1,80}$/.test(file.id) || ids.has(file.id)) {
      throw new Error("Source file IDs must be unique URL-safe strings.");
    }
    ids.add(file.id);
    const size = Number(file.size);
    if (!Number.isSafeInteger(size) || size <= 0 || size > config.maxFileBytes) {
      throw new Error("Invalid or oversized source file: " + (file.name || file.id) + ".");
    }
    const relativePath = safeRelativePath(file.relativePath || file.name, file.name);
    const pathKey = relativePath.toLowerCase();
    if (relativePaths.has(pathKey)) {
      throw new Error("Source paths collide after safe normalization: " + relativePath + ".");
    }
    relativePaths.add(pathKey);
    descriptors.push({ descriptor: file, relativePath, size });
    totalBytes += size;
  }
  if (!ids.has(manifest.primaryFileId)) {
    throw new Error("The primary CAD file is missing from the source set.");
  }
  const primaryDescriptor = manifest.files.find((file) => file.id === manifest.primaryFileId);
  const primaryExtension = fileExtension(primaryDescriptor?.name || primaryDescriptor?.relativePath);
  if (!config.providers.some((provider) => provider.ready && providerSupports(provider, primaryExtension))) {
    const coverage = providerCoverage(config.providers);
    throw new Error(
      (primaryExtension ? `No ready translator supports .${primaryExtension}. ` : "No ready wildcard translator supports this extensionless source. ") + (coverage.supportedExtensions.length ? `Ready coverage: ${coverage.supportedExtensions.map((value) => "." + value).join(", ")}.` : "Run npm run bridge:doctor and install/configure a translator provider.")
    );
  }
  if (totalBytes > config.maxJobBytes) throw new Error("CAD source set exceeds the job limit.");
  const id = randomBytes(16).toString("hex");
  const directory = await mkdtemp(join2(tmpdir(), "p3dw-cad-" + id.slice(0, 8) + "-"));
  await writeFile(join2(directory, ".owner.json"), JSON.stringify({
    schema: "p3dw.job-owner/1",
    pid: process.pid,
    createdAt: Date.now()
  }));
  const files = /* @__PURE__ */ new Map();
  for (const { descriptor, relativePath, size } of descriptors) {
    const path = pathInside(directory, join2("_sources", relativePath));
    await mkdir(dirname2(path), { recursive: true });
    files.set(descriptor.id, {
      id: descriptor.id,
      name: safeLeaf(descriptor.name),
      relativePath,
      path,
      size,
      received: 0,
      sha256: null,
      complete: false,
      uploading: false,
      uploadRequest: null,
      uploadStream: null,
      uploadPromise: null
    });
  }
  return {
    id,
    directory,
    manifest,
    files,
    phase: "uploading",
    progress: 0,
    message: "Waiting for CAD source files",
    error: null,
    translator: null,
    decision: null,
    providerReport: null,
    outputs: [],
    warnings: [],
    unresolvedExternalReferences: null,
    sourceSetSha256: null,
    stdout: "",
    stderr: "",
    child: null,
    cancelled: false,
    execution: null,
    downloads: /* @__PURE__ */ new Set(),
    cleanup: null,
    createdAt: Date.now(),
    lastActivity: Date.now(),
    completedAt: null
  };
}
async function uploadChunk(request, response, job, file, offset, config) {
  if (job.cancelled || job.phase !== "uploading") {
    throw new Error("This job is no longer accepting files.");
  }
  if (file.uploading) throw new Error("Another chunk is already uploading for this source file.");
  if (!Number.isSafeInteger(offset) || offset !== file.received) {
    throw new Error("Expected upload offset " + file.received + ", received " + offset + ".");
  }
  const remaining = file.size - file.received;
  if (remaining <= 0 || file.complete) throw new Error("This source file is already complete.");
  let received = 0;
  file.uploading = true;
  file.uploadRequest = request;
  let resolveUpload;
  const uploadPromise = new Promise((resolvePromise) => {
    resolveUpload = resolvePromise;
  });
  file.uploadPromise = uploadPromise;
  const counter = new Transform({
    transform(chunk, encoding, callback) {
      received += chunk.length;
      job.lastActivity = Date.now();
      if (received > remaining || received > config.maxChunkBytes) {
        callback(new Error("Source chunk exceeds its declared range or bridge chunk limit."));
        return;
      }
      callback(null, chunk);
    }
  });
  const output = createWriteStream(file.path, { flags: offset === 0 ? "w" : "a" });
  file.uploadStream = output;
  try {
    await pipeline(request, counter, output);
    if (!received) throw new Error("Empty source chunk.");
    const nextReceived = file.received + received;
    const sha256 = nextReceived === file.size ? await sha256File(file.path, job) : null;
    throwIfJobCancelled(job);
    file.received = nextReceived;
    if (sha256) {
      file.sha256 = sha256;
      file.complete = true;
    }
    const total = [...job.files.values()].reduce((sum, item) => sum + item.size, 0);
    const uploaded = [...job.files.values()].reduce((sum, item) => sum + item.received, 0);
    job.progress = total ? 0.65 * uploaded / total : 0;
    job.lastActivity = Date.now();
    job.message = "Uploaded " + file.name + ": " + file.received + "/" + file.size + " bytes";
    sendJson(response, 200, { received: file.received, complete: file.complete });
  } catch (error) {
    try {
      await truncate(file.path, offset);
    } catch (ignored) {
    }
    throw error;
  } finally {
    file.uploading = false;
    file.uploadRequest = null;
    file.uploadStream = null;
    resolveUpload();
    if (file.uploadPromise === uploadPromise) file.uploadPromise = null;
  }
}
function contentType(path) {
  if (/\.html?$/i.test(path)) return "text/html; charset=utf-8";
  return "application/octet-stream";
}
async function serveApp(response, appPath) {
  const info = await stat2(appPath);
  response.writeHead(200, {
    "Content-Type": contentType(appPath),
    "Content-Length": info.size,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Resource-Policy": "same-origin"
  });
  await pipeline(createReadStream(appPath), response);
}
async function cleanupJob(jobs, job) {
  if (job.cleanup) return job.cleanup;
  job.cleanup = (async () => {
    const cancellation = new Error("CAD job was cancelled or expired.");
    for (const file of job.files.values()) {
      file.uploadRequest?.destroy?.(cancellation);
      file.uploadStream?.destroy?.(cancellation);
    }
    for (const download of job.downloads || []) download.stream?.destroy?.(cancellation);
    if (job.child) await terminateChildProcess(job.child);
    const uploads = [...job.files.values()].map((file) => file.uploadPromise).filter(Boolean);
    if (uploads.length) await Promise.allSettled(uploads);
    const downloads = [...job.downloads || []].map((download) => download.promise).filter(Boolean);
    if (downloads.length) await Promise.allSettled(downloads);
    const execution = job.execution;
    if (execution) await execution.catch(() => {
    });
    try {
      await rm(job.directory, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
    } catch (error) {
      job.warnings.push("Temporary job cleanup will be retried at bridge startup: " + error.message);
    } finally {
      jobs.delete(job.id);
    }
  })();
  return job.cleanup;
}
async function reapOrphanedJobDirectories({
  directory = tmpdir(),
  now = Date.now(),
  minimumAgeMs = ORPHAN_JOB_MINIMUM_AGE_MS
} = {}) {
  const root = resolve2(directory);
  let entries;
  try {
    entries = await readdir2(root, { withFileTypes: true });
  } catch (error) {
    return 0;
  }
  let removed = 0;
  for (const entry of entries) {
    if (!entry.isDirectory() || !/^p3dw-cad-[a-f0-9]{8}-/i.test(entry.name)) continue;
    const target = resolve2(root, entry.name);
    const prefix = root.endsWith(sep) ? root : root + sep;
    if (!target.startsWith(prefix)) continue;
    let info;
    try {
      info = await stat2(target);
    } catch (error) {
      continue;
    }
    if (now - info.mtimeMs < minimumAgeMs) continue;
    try {
      let owner = null;
      try {
        owner = JSON.parse(await readFile(join2(target, ".owner.json"), "utf8"));
      } catch (error) {
      }
      if (Number.isSafeInteger(owner?.pid) && owner.pid > 0) {
        try {
          process.kill(owner.pid, 0);
          continue;
        } catch (error) {
          if (error.code === "EPERM") continue;
        }
      }
      await rm(target, { recursive: true, force: true });
      removed++;
    } catch (error) {
    }
  }
  return removed;
}
function reapJobs(jobs, config) {
  const now = Date.now();
  for (const job of jobs.values()) {
    const age = now - (job.lastActivity || job.completedAt || job.createdAt);
    const activeUpload = [...job.files.values()].some((file) => file.uploading);
    const activeDownload = !!job.downloads?.size;
    if (["uploading", "queued"].includes(job.phase) && !activeUpload && age > config.inactiveUploadMs) {
      job.cancelled = true;
      job.phase = "cancelled";
      job.message = "Inactive CAD upload expired";
      job.completedAt = now;
      cleanupJob(jobs, job).catch(() => {
      });
    } else if (!activeDownload && ["ready", "failed", "cancelled"].includes(job.phase) && age > JOB_RETENTION_MS) {
      cleanupJob(jobs, job).catch(() => {
      });
    }
  }
}
async function createCadBridgeServer(options = {}) {
  const config = options.config || await loadBridgeConfig(options);
  config.maxOutputBytes ??= DEFAULT_MAX_OUTPUT_BYTES;
  config.maxConcurrentJobs ??= DEFAULT_MAX_CONCURRENT_JOBS;
  config.maxSourceFiles ??= DEFAULT_MAX_SOURCE_FILES;
  config.maxChunkBytes ??= DEFAULT_MAX_CHUNK_BYTES;
  config.inactiveUploadMs ??= DEFAULT_INACTIVE_UPLOAD_MS;
  config.maxFileBytes = boundedInteger(
    config.maxFileBytes,
    DEFAULT_MAX_FILE_BYTES,
    "maxFileBytes",
    1,
    Number.MAX_SAFE_INTEGER
  );
  config.maxJobBytes = boundedInteger(
    config.maxJobBytes,
    DEFAULT_MAX_JOB_BYTES,
    "maxJobBytes",
    1,
    Number.MAX_SAFE_INTEGER
  );
  config.maxOutputBytes = boundedInteger(
    config.maxOutputBytes,
    DEFAULT_MAX_OUTPUT_BYTES,
    "maxOutputBytes",
    1,
    Number.MAX_SAFE_INTEGER
  );
  config.maxConcurrentJobs = boundedInteger(
    config.maxConcurrentJobs,
    DEFAULT_MAX_CONCURRENT_JOBS,
    "maxConcurrentJobs",
    1,
    64
  );
  config.maxSourceFiles = boundedInteger(
    config.maxSourceFiles,
    DEFAULT_MAX_SOURCE_FILES,
    "maxSourceFiles",
    1,
    65536
  );
  config.maxChunkBytes = boundedInteger(
    config.maxChunkBytes,
    DEFAULT_MAX_CHUNK_BYTES,
    "maxChunkBytes",
    1,
    256 * 1024 * 1024
  );
  config.inactiveUploadMs = boundedInteger(
    config.inactiveUploadMs,
    DEFAULT_INACTIVE_UPLOAD_MS,
    "inactiveUploadMs",
    1e3,
    24 * 60 * 60 * 1e3
  );
  config.providerCatalog ||= RECOMMENDED_PROVIDER_CATALOG;
  const normalizedProviders = (config.providers || []).map((provider, index) => normalizeProvider(provider, index)).filter(Boolean);
  const providerIds = /* @__PURE__ */ new Set();
  for (const provider of normalizedProviders) {
    if (providerIds.has(provider.id)) {
      throw new Error(`CAD provider IDs must be unique; duplicate ID: ${provider.id}.`);
    }
    providerIds.add(provider.id);
  }
  config.providers = await Promise.all(normalizedProviders.map(preflightProvider));
  const jobs = /* @__PURE__ */ new Map();
  let admissionReservations = 0;
  let reaper = null;
  let closing = false;
  let closePromise = null;
  const sockets = /* @__PURE__ */ new Set();
  const server = createServer(async (request, response) => {
    try {
      request.setTimeout(6e4, () => request.destroy(
        new Error("CAD bridge request timed out while inactive.")
      ));
      if (!localRequest(request)) {
        sendJson(response, 403, { error: "The CAD bridge accepts loopback requests only." });
        return;
      }
      if (closing) {
        sendJson(response, 503, { error: "The CAD bridge is shutting down." });
        return;
      }
      const url = new URL(request.url || "/", `http://${request.headers.host}`);
      const parts = url.pathname.split("/").filter(Boolean);
      if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html" || url.pathname === "/Pro3DWorks.html")) {
        await serveApp(response, config.appPath);
        return;
      }
      if (request.method === "GET" && url.pathname === "/api/cad/v1/health") {
        const readyProviders = config.providers.filter((provider) => provider.ready);
        const coverage = providerCoverage(config.providers);
        sendJson(response, 200, {
          protocol: CAD_BRIDGE_PROTOCOL,
          build: "node-provider-broker/2",
          ready: readyProviders.length > 0,
          reason: readyProviders.length ? null : "No translator provider passed preflight. Run npm run bridge:doctor for exact installation/configuration guidance.",
          providers: config.providers.map(publicProvider),
          coverage,
          providerCatalog: config.providerCatalog,
          limits: {
            maxFileBytes: config.maxFileBytes,
            maxJobBytes: config.maxJobBytes,
            maxOutputBytes: config.maxOutputBytes,
            maxConcurrentJobs: config.maxConcurrentJobs,
            maxSourceFiles: config.maxSourceFiles,
            maxChunkBytes: config.maxChunkBytes
          }
        });
        return;
      }
      if (request.method === "POST" && url.pathname === "/api/cad/v1/jobs") {
        const activeJobs = [...jobs.values()].filter((job2) => !["ready", "failed", "cancelled"].includes(job2.phase)).length;
        if (activeJobs + admissionReservations >= config.maxConcurrentJobs) {
          sendJson(response, 429, { error: "The CAD bridge is at its concurrent-job limit." });
          return;
        }
        admissionReservations++;
        try {
          const job2 = await createJob(config, await readJson(request));
          if (closing) {
            job2.cancelled = true;
            job2.phase = "cancelled";
            await cleanupJob(jobs, job2);
            sendJson(response, 503, { error: "The CAD bridge is shutting down." });
            return;
          }
          jobs.set(job2.id, job2);
          sendJson(response, 201, { jobId: job2.id, protocol: CAD_BRIDGE_PROTOCOL });
        } finally {
          admissionReservations--;
        }
        return;
      }
      if (parts.slice(0, 4).join("/") !== "api/cad/v1/jobs" || !parts[4]) {
        sendJson(response, 404, { error: "Not found." });
        return;
      }
      const job = jobs.get(parts[4]);
      if (!job) {
        sendJson(response, 404, { error: "CAD conversion job not found or expired." });
        return;
      }
      if (request.method === "PUT" && parts[5] === "files" && parts[6]) {
        const file = job.files.get(parts[6]);
        if (!file) throw new Error("Unknown source file ID.");
        await uploadChunk(
          request,
          response,
          job,
          file,
          Number(url.searchParams.get("offset")),
          config
        );
        return;
      }
      if (request.method === "GET" && parts[5] === "files" && parts[6]) {
        const file = job.files.get(parts[6]);
        if (!file) throw new Error("Unknown source file ID.");
        sendJson(response, 200, {
          id: file.id,
          size: file.size,
          received: file.received,
          complete: file.complete
        });
        return;
      }
      if (request.method === "POST" && parts[5] === "convert") {
        if ([...job.files.values()].some((file) => !file.complete || file.received !== file.size || !file.sha256)) {
          throw new Error("All declared source files must finish uploading before conversion.");
        }
        if (job.phase !== "uploading") throw new Error("CAD conversion already started.");
        job.phase = "queued";
        job.lastActivity = Date.now();
        const sourceSetHash = createHash("sha256");
        for (const file of [...job.files.values()].sort((a, b) => a.relativePath.localeCompare(b.relativePath))) {
          sourceSetHash.update(file.relativePath);
          sourceSetHash.update("\0");
          sourceSetHash.update(file.sha256 || "");
          sourceSetHash.update("\0");
        }
        job.sourceSetSha256 = sourceSetHash.digest("hex");
        job.progress = 0.68;
        job.message = "CAD translation queued";
        job.execution = executeJob(job, config).catch((error) => {
          if (job.cancelled) return;
          job.phase = "failed";
          job.progress = 1;
          job.error = error.message || String(error);
          job.message = job.error;
          job.completedAt = Date.now();
          job.lastActivity = job.completedAt;
        }).finally(() => {
          job.execution = null;
        });
        sendJson(response, 202, publicJob(job));
        return;
      }
      if (request.method === "GET" && parts[5] === "outputs" && parts[6]) {
        if (job.cancelled || job.phase !== "ready") {
          throw new Error("CAD output is not ready.");
        }
        const output = job.outputs.find((item) => item.id === parts[6]);
        if (!output) throw new Error("Unknown CAD output ID.");
        response.writeHead(200, {
          "Content-Type": output.mediaType,
          "Content-Length": output.bytes,
          "Content-Disposition": `attachment; filename="${safeLeaf(output.name)}"`,
          "X-Pro3DWorks-File-Name": encodeURIComponent(output.name),
          "X-Pro3DWorks-SHA256": output.sha256,
          "X-Content-Type-Options": "nosniff",
          "Cache-Control": "no-store"
        });
        const stream = createReadStream(output.path);
        const download = { stream, promise: null };
        stream.on("data", () => {
          job.lastActivity = Date.now();
        });
        download.promise = pipeline(stream, response);
        job.downloads.add(download);
        try {
          await download.promise;
        } finally {
          job.downloads.delete(download);
        }
        return;
      }
      if (request.method === "GET" && parts.length === 5) {
        sendJson(response, 200, publicJob(job));
        return;
      }
      if (request.method === "DELETE" && parts.length === 5) {
        job.cancelled = true;
        job.phase = "cancelled";
        job.message = "CAD conversion cancelled";
        job.completedAt = Date.now();
        await cleanupJob(jobs, job);
        sendJson(response, 202, { jobId: job.id, phase: job.phase });
        return;
      }
      sendJson(response, 404, { error: "Not found." });
    } catch (error) {
      if (!response.headersSent) {
        sendJson(response, 400, { error: error.message || String(error) });
      } else {
        response.destroy(error);
      }
    }
  });
  server.on("connection", (socket) => {
    sockets.add(socket);
    socket.once("close", () => sockets.delete(socket));
  });
  async function start() {
    if (!existsSync2(config.appPath)) {
      throw new Error(`Standalone application not found: ${config.appPath}`);
    }
    await reapOrphanedJobDirectories();
    await new Promise((resolvePromise, rejectPromise) => {
      server.once("error", rejectPromise);
      server.listen(config.port, config.host, () => {
        server.off("error", rejectPromise);
        resolvePromise();
      });
    });
    reaper = setInterval(() => reapJobs(jobs, config), 6e4);
    reaper.unref?.();
    return server.address();
  }
  async function close() {
    if (closePromise) return closePromise;
    closePromise = (async () => {
      closing = true;
      if (reaper) clearInterval(reaper);
      const serverClosed = server.listening ? new Promise((resolvePromise, rejectPromise) => server.close((error) => error ? rejectPromise(error) : resolvePromise())) : Promise.resolve();
      for (const socket of sockets) socket.destroy();
      const active = [...jobs.values()];
      for (const job of active) {
        job.cancelled = true;
        job.phase = "cancelled";
        job.message = "CAD bridge shutting down";
        job.completedAt = Date.now();
      }
      await Promise.allSettled(active.map((job) => cleanupJob(jobs, job)));
      await serverClosed;
    })();
    return closePromise;
  }
  return { config, jobs, server, start, close };
}
async function openBrowser(url) {
  const command = process.platform === "win32" ? "rundll32.exe" : process.platform === "darwin" ? "open" : "xdg-open";
  const args = process.platform === "win32" ? ["url.dll,FileProtocolHandler", url] : [url];
  const child = spawn(command, args, {
    detached: true,
    stdio: "ignore",
    windowsHide: false
  });
  child.unref();
}
async function main() {
  const bridge = await createCadBridgeServer();
  if (process.argv.includes("--doctor")) {
    const readyProviders = bridge.config.providers.filter((provider) => provider.ready);
    const report = {
      protocol: CAD_BRIDGE_PROTOCOL,
      ready: readyProviders.length > 0,
      coverage: providerCoverage(bridge.config.providers),
      providers: bridge.config.providers.map(publicProvider),
      providerCatalog: bridge.config.providerCatalog
    };
    if (process.argv.includes("--json")) console.log(JSON.stringify(report, null, 2));
    else {
      console.log("Pro3DWorks CAD provider doctor");
      console.log("Ready:", report.ready ? "yes" : "no");
      for (const provider of report.providers) {
        console.log(`${provider.ready ? "[READY]" : "[NOT READY]"} ${provider.label}: ${provider.reason}`);
        if (provider.probe) console.log("  Probe:", provider.probe);
        console.log("  Inputs:", provider.supports.map((value) => "." + value).join(", "));
        console.log("  Outputs:", provider.outputs.map((value) => "." + value).join(", "));
      }
      if (!report.providers.length) {
        console.log("No native provider executable was discovered or configured.");
      }
      console.log("\nProvider options:");
      for (const item of report.providerCatalog) {
        console.log(`- ${item.label} (${item.license}): ${item.installHint}`);
      }
    }
    if (!report.ready) process.exitCode = 1;
    return;
  }
  const address = await bridge.start();
  const url = `http://127.0.0.1:${address.port}/`;
  console.log(`Pro3DWorks CAD Translation Bridge: ${url}`);
  console.log(bridge.config.providers.length ? `Providers: ${bridge.config.providers.map((provider) => `${provider.label}=${provider.ready ? "ready" : "not-ready"}`).join(", ")}` : "No native provider found. Direct formats and the embedded Assimp visual fallback remain available; run npm run bridge:doctor for native CAD setup.");
  if (process.argv.includes("--open")) await openBrowser(url);
  const shutdown = async () => {
    await bridge.close();
    process.exit(0);
  };
  process.once("SIGINT", shutdown);
  process.once("SIGTERM", shutdown);
}
if (process.argv[1] && resolve2(process.argv[1]) === fileURLToPath2(import.meta.url)) {
  main().catch((error) => {
    console.error(error.stack || error);
    process.exitCode = 1;
  });
}
export {
  CAD_BRIDGE_PROTOCOL,
  createCadBridgeServer,
  expandCommandArguments,
  loadBridgeConfig,
  reapOrphanedJobDirectories,
  reportFormatMatches,
  safeRelativePath
};
