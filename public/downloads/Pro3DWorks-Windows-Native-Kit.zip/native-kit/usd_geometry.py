"""Static, tessellated public-OpenUSD scene -> self-contained glTF 2 GLB.

No native reader, licence operation, provenance/completeness inference or BRep
conversion lives here. USD paths identify composed occurrences (including
instance proxies). Hidden geometry is retained; its initial visibility is
recorded in extras for the caller. Geometry stays body-local and float32;
hierarchy placements and the single units/up-axis root stay JSON doubles.

Deliberately refused: animation/time samples, subdivision, non-triangles,
holes, non-mesh Gprims/point instancers, invalid numeric/index data. Material
support is constant UsdPreviewSurface values, input-interface forwarding,
materialBind face subsets and fallback displayColor/displayOpacity. Unsupported
shader/texture/optional channels are reported, never advertised as preserved.
"""
from __future__ import annotations

from array import array
from collections import OrderedDict
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import sys
import tempfile

import usd_convert_cad  # Public package initialization configures bundled pxr.
from pxr import Gf, Usd, UsdGeom, UsdShade

# Fail before unbounded expansion or a uint32 GLB/accessor length overflow.
MAX_NODES = 100_000
MAX_POINTS = 15_000_000
MAX_TRIANGLES = 10_000_000
MAX_BUFFER_BYTES = 1_500_000_000
_TIME = Usd.TimeCode.Default()
_IDENTITY = [float(i == j) for i in range(4) for j in range(4)]


class UsdGeometryError(ValueError):
    """Unsupported or invalid static USD geometry; no destination published."""


def _require(condition, message):
    if not condition:
        raise UsdGeometryError(message)


def _finite(value, context):
    number = float(value)
    _require(math.isfinite(number), f'{context}: non-finite value')
    return number


def _vector(value, width, context):
    _require(len(value) == width, f'{context}: expected {width} components')
    return tuple(_finite(x, context) for x in value)


def _unit_normal(value, context):
    v = _vector(value, 3, context)
    length = math.hypot(*v)
    _require(math.isfinite(length) and length > 0, f'{context}: zero/invalid normal')
    return tuple(x / length for x in v)


def _matrix(matrix, context):
    """Gf is row-vector. glTF matrix = Gf transpose; its column-major list
    is therefore exactly the row-major enumeration of Gf (NOT another transpose).
    This also puts Gf's row-3 translation at glTF array offsets 12..14.
    """
    result = [_finite(matrix[i][j], context) for i in range(4) for j in range(4)]
    _require(all(abs(matrix[i][3]) <= 1e-12 for i in range(3)) and abs(matrix[3][3] - 1) <= 1e-12,
             f'{context}: projective transforms are unsupported')
    return result


def _trs_decomposable(matrix):
    axes = [tuple(float(matrix[i][j]) for j in range(3)) for i in range(3)]
    lengths = [math.hypot(*axis) for axis in axes]
    return all(abs(sum(a * b for a, b in zip(axes[i], axes[j]))) <= 1e-10 * lengths[i] * lengths[j] + 1e-24
               for i, j in ((0, 1), (0, 2), (1, 2)))


def _affine_parts(matrix, context):
    """A reset under rotated/nonuniform ancestors can produce local shear.
    glTF forbids a shear in a single node matrix. Public Gf.Transform factors
    row-vector M = O^-1 * S * O * R * T. Thus insert one TRS compensation
    parent B = S*O*R*T and retain the USD node as pure rotation A = O^-1.
    Row A*B = M, so the native ancestor chain and world geometry both survive.
    The helper is explicitly marked and is not a fictitious USD-path identity.
    """
    if _trs_decomposable(matrix):
        return None, matrix
    transform = Gf.Transform(matrix)
    orientation = Gf.Matrix4d(1).SetRotate(transform.GetPivotOrientation())
    a = orientation.GetInverse()
    b = (Gf.Matrix4d(1).SetScale(transform.GetScale()) * orientation
         * Gf.Matrix4d(1).SetRotate(transform.GetRotation())
         * Gf.Matrix4d(1).SetTranslate(transform.GetTranslation()))
    reconstructed = a * b
    _require(all(abs(reconstructed[i][j] - matrix[i][j]) <= 1e-9 * max(1.0, abs(matrix[i][j]))
                 for i in range(4) for j in range(4)), f'{context}: affine factorization failed')
    _require(_trs_decomposable(a) and _trs_decomposable(b), f'{context}: non-TRS affine factorization')
    return b, a


def _bytes(values, kind):
    try:
        result = array(kind, values)
    except (ValueError, OverflowError) as exc:
        raise UsdGeometryError(f'Cannot represent geometry as {kind}: {exc}') from exc
    if kind == 'f':
        _require(all(math.isfinite(x) for x in result), 'float32 geometry overflow')
    if sys.byteorder != 'little':
        result.byteswap()
    return result.tobytes()


def _channel(prim, name, npoints, nfaces, width, normal=False, builtin=None):
    """Resolve and validate indexed primvar interpolation *before* corner lookup.
    In particular vertex primvars:normals indices address normal values, whereas
    faceVertexIndices address points; the two index domains are never joined.
    """
    pv = UsdGeom.PrimvarsAPI(prim).FindPrimvarWithInheritance(name)
    context = f'{prim.GetPath()} {name}'
    if pv and pv.HasValue():
        _require(pv.GetElementSize() == 1, f'{context}: elementSize != 1 unsupported')
        values = pv.Get(_TIME)
        interpolation = str(pv.GetInterpolation())
        indices = pv.GetIndices(_TIME) if pv.IsIndexed() else None
        _require(pv.GetUnauthoredValuesIndex() < 0, f'{context}: unauthored value indices unsupported')
    elif builtin is not None and builtin[0].HasValue():
        values = builtin[0].Get(_TIME)
        interpolation = str(builtin[1])
        indices = None
    else:
        return None
    _require(values is not None and len(values) > 0, f'{context}: empty authored channel')
    cardinality = {'constant': 1, 'uniform': nfaces, 'vertex': npoints,
                   'varying': npoints, 'faceVarying': nfaces * 3}
    _require(interpolation in cardinality, f'{context}: unsupported interpolation {interpolation}')
    converted = []
    for value in values:
        if normal:
            converted.append(_unit_normal(value, context))
        elif width == 1:
            converted.append(_finite(value, context))
        else:
            converted.append(_vector(value, width, context))
    if indices is not None:
        _require(len(indices) == cardinality[interpolation], f'{context}: wrong primvar index count')
        _require(all(0 <= i < len(converted) for i in indices), f'{context}: invalid primvar index')
        converted = [converted[i] for i in indices]
    else:
        _require(len(converted) == cardinality[interpolation], f'{context}: wrong value count for {interpolation}')
    return interpolation, converted


def _sample(channel, face, corner, vertex):
    interpolation, values = channel
    if interpolation == 'constant':
        index = 0
    elif interpolation == 'uniform':
        index = face
    elif interpolation == 'faceVarying':
        index = corner
    else:
        index = vertex
    return values[index]


class _Materials:
    def __init__(self, document, warn):
        self.document = document
        self.warn = warn
        self.cache = {}
        self.identities = {}

    def _input(self, attr, default, context, seen=None):
        """Follow input-to-input material interfaces, but never evaluate shaders."""
        if not attr:
            return default
        seen = set() if seen is None else seen
        path = str(attr.GetPath())
        if path in seen:
            self.warn(f'{context}: cyclic material input; using fallback')
            return default
        seen.add(path)
        connections = attr.GetConnections()
        if connections:
            if len(connections) == 1 and connections[0].name.startswith('inputs:'):
                target = attr.GetPrim().GetStage().GetAttributeAtPath(connections[0])
                return self._input(target, default, context, seen)
            self.warn(f'{context}: unsupported texture/shader output; using constant fallback')
        value = attr.Get(_TIME)
        return default if value is None else value

    def _clamp(self, number, context):
        number = _finite(number, context)
        if number < 0 or number > 1:
            self.warn(f'{context}: value outside glTF [0,1], clamped')
        return max(0.0, min(1.0, number))

    def get(self, material, double_sided, vertex_alpha=False):
        source_path = str(material.GetPath()) if material else ''
        key = (source_path, bool(double_sided), bool(vertex_alpha))
        if key in self.cache:
            return self.cache[key]
        color, opacity, metallic, roughness, cutoff = (1, 1, 1), 1, 0, 0.5, 0
        name = 'USD displayColor fallback'
        if material:
            name = material.GetPrim().GetDisplayName() or material.GetPrim().GetName()
            shader, _, _ = material.ComputeSurfaceSource()
            if shader and shader.GetIdAttr().Get(_TIME) == 'UsdPreviewSurface':
                defaults = {'diffuseColor': (0.18, 0.18, 0.18), 'opacity': 1.0, 'metallic': 0.0, 'roughness': 0.5, 'opacityThreshold': 0.0}
                resolved = {field: self._input(shader.GetInput(field).GetAttr() if shader.GetInput(field) else None,
                                               default, f'{source_path} {field}') for field, default in defaults.items()}
                color, opacity = resolved['diffuseColor'], resolved['opacity']
                metallic, roughness, cutoff = resolved['metallic'], resolved['roughness'], resolved['opacityThreshold']
                for inp in shader.GetInputs():
                    if inp.GetBaseName() not in defaults and (inp.GetAttr().HasAuthoredValueOpinion() or inp.HasConnectedSource()):
                        self.warn(f'{source_path}: unsupported UsdPreviewSurface input {inp.GetBaseName()}')
            else:
                self.warn(f'{source_path}: unsupported or missing surface shader; constant material-interface fallback only')
                color = self._input(material.GetInput('diffuseColor').GetAttr() if material.GetInput('diffuseColor') else None, color, source_path)
                opacity = self._input(material.GetInput('opacity').GetAttr() if material.GetInput('opacity') else None, opacity, source_path)
            if material.GetDisplacementOutput() and material.GetDisplacementOutput().HasConnectedSource():
                self.warn(f'{source_path}: displacement shader unsupported')
        color = _vector(color, 3, f'{source_path} diffuseColor')
        rgba = [self._clamp(v, source_path + ' baseColor') for v in color] + [self._clamp(opacity, source_path + ' opacity')]
        metallic = self._clamp(metallic, source_path + ' metallic')
        roughness = self._clamp(roughness, source_path + ' roughness')
        cutoff = self._clamp(cutoff, source_path + ' opacityThreshold')
        result = {'name': name, 'pbrMetallicRoughness': {'baseColorFactor': rgba, 'metallicFactor': metallic, 'roughnessFactor': roughness}, 'doubleSided': bool(double_sided)}
        if cutoff > 0:
            result.update(alphaMode='MASK', alphaCutoff=cutoff)
        elif rgba[3] < 1 or vertex_alpha:
            result['alphaMode'] = 'BLEND'
        else:
            result['alphaMode'] = 'OPAQUE'
        # Material identity excludes display names, not material *values*.
        identity = json.dumps({k: v for k, v in result.items() if k != 'name'}, sort_keys=True, allow_nan=False)
        if identity not in self.identities:
            self.identities[identity] = len(self.document['materials'])
            self.document['materials'].append(result)
        index = self.identities[identity]
        self.cache[key] = index
        return index


def _source_visible(prim):
    # Untyped grouping prims are retained too; absence of the Imageable schema
    # does not undo an invisible imageable ancestor for the group's descendants.
    while prim and not prim.IsPseudoRoot():
        if prim.IsA(UsdGeom.Imageable):
            return UsdGeom.Imageable(prim).ComputeVisibility(_TIME) != UsdGeom.Tokens.invisible
        prim = prim.GetParent()
    return True


def _bound(prim):
    material, _ = UsdShade.MaterialBindingAPI(prim).ComputeBoundMaterial()
    return material


def _geometry(prim, materials, warn):
    mesh = UsdGeom.Mesh(prim)
    path = str(prim.GetPath())
    points = mesh.GetPointsAttr().Get(_TIME)
    counts = mesh.GetFaceVertexCountsAttr().Get(_TIME)
    indices = mesh.GetFaceVertexIndicesAttr().Get(_TIME)
    _require(points is not None and counts is not None and indices is not None, f'{path}: missing geometry arrays')
    _require(0 < len(points) <= MAX_POINTS and 0 < len(counts) <= MAX_TRIANGLES, f'{path}: empty geometry or resource limit exceeded')
    _require(all(n == 3 for n in counts), f'{path}: only triangle topology is supported')
    _require(len(indices) == 3 * len(counts), f'{path}: face/index count mismatch')
    _require(all(0 <= i < len(points) for i in indices), f'{path}: invalid point index')
    _require(mesh.GetSubdivisionSchemeAttr().Get(_TIME) == UsdGeom.Tokens.none, f'{path}: subdivision/tessellation unsupported')
    _require(not mesh.GetHoleIndicesAttr().Get(_TIME), f'{path}: hole topology unsupported')
    points = [_vector(p, 3, path + ' point') for p in points]
    orientation = str(mesh.GetOrientationAttr().Get(_TIME))
    _require(orientation in ('rightHanded', 'leftHanded'), f'{path}: unsupported orientation')
    corner_order = (0, 2, 1) if orientation == 'leftHanded' else (0, 1, 2)
    normals = _channel(prim, 'normals', len(points), len(counts), 3, normal=True,
                       builtin=(mesh.GetNormalsAttr(), mesh.GetNormalsInterpolation()))
    if normals is None:
        warn(f'{path}: generated geometric face normals (source normals absent)')
    color = _channel(prim, 'displayColor', len(points), len(counts), 3)
    opacity = _channel(prim, 'displayOpacity', len(points), len(counts), 1)
    for pv in UsdGeom.PrimvarsAPI(prim).GetPrimvars():
        if pv.GetPrimvarName() not in ('normals', 'displayColor', 'displayOpacity') and pv.HasValue():
            warn(f'{path}: optional primvar {pv.GetPrimvarName()} not exported')
    material = _bound(prim)
    face_materials = [material] * len(counts)
    assigned = set()
    for subset in UsdGeom.Subset.GetAllGeomSubsets(mesh):
        if subset.GetFamilyNameAttr().Get(_TIME) != 'materialBind':
            warn(f'{subset.GetPath()}: non-material geometry subset not exported')
            continue
        _require(subset.GetElementTypeAttr().Get(_TIME) == 'face', f'{subset.GetPath()}: only face material subsets supported')
        members = subset.GetIndicesAttr().Get(_TIME)
        _require(members is not None, f'{subset.GetPath()}: absent material subset indices')
        bound = _bound(subset.GetPrim())
        for face in members:
            _require(0 <= face < len(counts) and face not in assigned, f'{subset.GetPath()}: invalid/overlapping material subset')
            assigned.add(face)
            face_materials[face] = bound
    family = UsdGeom.Subset.GetFamilyType(mesh, 'materialBind')
    if family == 'partition':
        _require(len(assigned) == len(counts), f'{path}: incomplete material partition')
    use_color = any(not m for m in face_materials) and (color is not None or opacity is not None)
    if not material and not color:
        warn(f'{path}: no bound material/displayColor; unbound faces use white fallback')
    double_sided = bool(mesh.GetDoubleSidedAttr().Get(_TIME))
    vertex_alpha = opacity is not None and any(v < 1 for v in opacity[1])
    # Convert per-occurrence bindings before mesh sharing: conflicting material
    # assignments cannot accidentally reuse an otherwise identical mesh.
    face_material_ids = [materials.get(m, double_sided, vertex_alpha and not m) for m in face_materials]
    positions, out_normals, colors, vertices = [], [], [], {}
    groups = OrderedDict()
    for face in range(len(counts)):
        group = groups.setdefault(face_material_ids[face], [])
        base = face * 3
        if normals is None:
            a, b, c = [points[indices[base + k]] for k in corner_order]
            ab, ac = [b[k] - a[k] for k in range(3)], [c[k] - a[k] for k in range(3)]
            normal = _unit_normal((ab[1] * ac[2] - ab[2] * ac[1], ab[2] * ac[0] - ab[0] * ac[2], ab[0] * ac[1] - ab[1] * ac[0]), path + ' generated normal')
        for k in corner_order:
            corner = base + k
            vi = indices[corner]
            n = _sample(normals, face, corner, vi) if normals is not None else normal
            rgba = None
            if use_color:
                rgb = _sample(color, face, corner, vi) if color and not face_materials[face] else (1, 1, 1)
                alpha = _sample(opacity, face, corner, vi) if opacity and not face_materials[face] else 1
                rgba = tuple(materials._clamp(x, path + ' displayColor/opacity') for x in (*rgb, alpha))
            key = (vi, n, rgba)
            out_index = vertices.get(key)
            if out_index is None:
                out_index = len(positions) // 3
                vertices[key] = out_index
                positions.extend(points[vi])
                out_normals.extend(n)
                if rgba is not None:
                    colors.extend(rgba)
            group.append(out_index)
    payloads = {'POSITION': _bytes(positions, 'f'), 'NORMAL': _bytes(out_normals, 'f')}
    if use_color:
        payloads['COLOR_0'] = _bytes(colors, 'f')
    partitions = [(mid, _bytes(ids, 'I')) for mid, ids in groups.items()]
    return payloads, partitions, len(counts)


class _Buffers:
    def __init__(self, document):
        self.document = document
        self.data = bytearray()

    def add(self, raw, width, component, target, extrema=False):
        _require(len(self.data) + len(raw) + 3 <= MAX_BUFFER_BYTES, 'GLB buffer resource limit exceeded')
        self.data.extend(b'\0' * (-len(self.data) % 4))
        view = len(self.document['bufferViews'])
        self.document['bufferViews'].append({'buffer': 0, 'byteOffset': len(self.data), 'byteLength': len(raw), 'target': target})
        self.data.extend(raw)
        accessor = {'bufferView': view, 'byteOffset': 0, 'componentType': component, 'count': len(raw) // (4 * width), 'type': {1: 'SCALAR', 3: 'VEC3', 4: 'VEC4'}[width]}
        if extrema:
            rows = struct.iter_unpack('<' + 'f' * width, raw)
            lo, hi = [math.inf] * width, [-math.inf] * width
            for row in rows:
                for k, value in enumerate(row):
                    lo[k] = min(lo[k], value)
                    hi[k] = max(hi[k], value)
            accessor.update(min=lo, max=hi)
        result = len(self.document['accessors'])
        self.document['accessors'].append(accessor)
        return result


def _validate_staged(path):
    """Read closed staged bytes, validate structure/accessors/indices before replace.
    This is a publication guard; qualification uses a separate test GLB parser.
    """
    data = path.read_bytes()
    _require(len(data) >= 28, 'Staged GLB too short')
    magic, version, length = struct.unpack_from('<4sII', data)
    _require((magic, version, length) == (b'glTF', 2, len(data)), 'Invalid staged GLB header')
    jsize, jtype = struct.unpack_from('<II', data, 12)
    _require(jtype == 0x4E4F534A and jsize % 4 == 0 and 20 + jsize + 8 <= length, 'Invalid GLB JSON chunk')
    doc = json.loads(data[20:20 + jsize])
    bsize, btype = struct.unpack_from('<II', data, 20 + jsize)
    start = 28 + jsize
    _require(btype == 0x004E4942 and bsize % 4 == 0 and start + bsize == length, 'Invalid GLB BIN chunk')
    _require(len(doc['buffers']) == 1 and 'uri' not in doc['buffers'][0] and 0 <= bsize - doc['buffers'][0]['byteLength'] <= 3, 'Invalid embedded buffer')
    capacities = {}
    index_ranges = {}
    for i, accessor in enumerate(doc['accessors']):
        width = {'SCALAR': 1, 'VEC3': 3, 'VEC4': 4}[accessor['type']]
        view = doc['bufferViews'][accessor['bufferView']]
        offset = view['byteOffset'] + accessor.get('byteOffset', 0)
        count = accessor['count']
        _require(count > 0 and view['buffer'] == 0 and offset % 4 == 0, 'Invalid accessor alignment/count')
        _require(count * width * 4 == view['byteLength'] and offset + view['byteLength'] <= doc['buffers'][0]['byteLength'], 'Accessor out of buffer bounds')
        kind = {5125: 'I', 5126: 'f'}[accessor['componentType']]
        lo, hi = [math.inf] * width, [-math.inf] * width
        for row in struct.iter_unpack('<' + kind * width, memoryview(data)[start + offset:start + offset + count * width * 4]):
            _require(all(math.isfinite(v) for v in row), 'Non-finite staged accessor')
            for k, value in enumerate(row):
                lo[k], hi[k] = min(lo[k], value), max(hi[k], value)
        if 'min' in accessor or 'max' in accessor:
            _require(accessor['min'] == lo and accessor['max'] == hi, 'Incorrect accessor min/max')
        capacities[i] = count
        if kind == 'I':
            index_ranges[i] = (lo[0], hi[0])
    for mesh in doc['meshes']:
        for prim in mesh['primitives']:
            attrs = prim['attributes']
            count = capacities[attrs['POSITION']]
            _require(all(capacities[a] == count for a in attrs.values()), 'Mismatched geometry attribute counts')
            lo, hi = index_ranges[prim['indices']]
            _require(0 <= lo <= hi < count and capacities[prim['indices']] % 3 == 0, 'Invalid triangle indices')
    seen = set()
    pending = list(doc['scenes'][doc['scene']]['nodes'])
    while pending:
        index = pending.pop()
        _require(0 <= index < len(doc['nodes']) and index not in seen, 'Invalid/cyclic node hierarchy')
        seen.add(index)
        node = doc['nodes'][index]
        _require(len(node['matrix']) == 16 and all(math.isfinite(v) for v in node['matrix']), 'Invalid node matrix')
        matrix = Gf.Matrix4d(*node['matrix'])
        _require(_trs_decomposable(matrix), 'Non-TRS staged node matrix')
        if 'mesh' in node:
            _require(0 <= node['mesh'] < len(doc['meshes']), 'Invalid node mesh')
        pending.extend(node.get('children', []))
    _require(len(seen) == len(doc['nodes']), 'Unreachable staged node')


def _publish(document, buffers, output):
    document['buffers'] = [{'byteLength': len(buffers)}]
    text = json.dumps(document, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('utf-8')
    text += b' ' * (-len(text) % 4)
    padding = b'\0' * (-len(buffers) % 4)
    length = 12 + 8 + len(text) + 8 + len(buffers) + len(padding)
    _require(length < 2 ** 32, 'GLB length exceeds uint32')
    output.parent.mkdir(parents=True, exist_ok=True)
    # A failed staged file is deliberately retained for diagnosis. Existing
    # destination bytes are untouched until validation succeeds and replace runs.
    with tempfile.NamedTemporaryFile(dir=output.parent, prefix=output.name + '.', suffix='.staged.glb', delete=False) as stream:
        staged = Path(stream.name)
        stream.write(struct.pack('<4sII', b'glTF', 2, length))
        stream.write(struct.pack('<II', len(text), 0x4E4F534A))
        stream.write(text)
        stream.write(struct.pack('<II', len(buffers) + len(padding), 0x004E4942))
        stream.write(buffers)
        stream.write(padding)
        stream.flush()
        os.fsync(stream.fileno())
    _validate_staged(staged)
    os.replace(staged, output)


def export_usd_to_glb(input_path, output_path) -> dict:
    """Export a static monolithic USD with explicit, geometry-only report.

    Accepts str/Path. Raises UsdGeometryError (or underlying I/O errors) rather
    than dropping unsupported geometry. Publication is atomic with respect to
    an existing destination; no native source/completeness assertions are made.
    """
    source, output = Path(input_path).resolve(), Path(output_path).resolve()
    _require(source != output, 'Input and output paths must differ')
    _require(source.is_file(), f'USD source not found: {source}')
    stage = Usd.Stage.Open(str(source))
    _require(bool(stage), f'Could not open USD stage: {source}')
    units = _finite(UsdGeom.GetStageMetersPerUnit(stage), 'metersPerUnit')
    _require(units > 0, 'metersPerUnit must be positive')
    axis = str(UsdGeom.GetStageUpAxis(stage))
    _require(axis in ('Y', 'Z'), f'Unsupported stage up axis: {axis}')
    prims = list(Usd.PrimRange.Stage(stage, Usd.TraverseInstanceProxies()))
    _require(len(prims) <= MAX_NODES, 'USD scene node resource limit exceeded')
    meshes = []
    for prim in prims:
        for attr in prim.GetAttributes():
            _require(attr.GetNumTimeSamples() == 0, f'{attr.GetPath()}: time-sampled/animated data unsupported')
            _require(not (attr.GetName().startswith('skel:') and attr.HasAuthoredValueOpinion()), f'{prim.GetPath()}: skeletal deformation unsupported')
        _require(not prim.IsA(UsdGeom.PointInstancer), f'{prim.GetPath()}: point instancing unsupported')
        if prim.IsA(UsdGeom.Mesh):
            meshes.append(prim)
        elif prim.IsA(UsdGeom.Gprim):
            raise UsdGeometryError(f'{prim.GetPath()}: non-mesh geometry {prim.GetTypeName()} unsupported')
    _require(bool(meshes), 'USD stage contains no supported mesh occurrences')
    warnings, warning_set = [], set()
    def warn(message):
        if message not in warning_set:
            warning_set.add(message)
            warnings.append(message)
    if not stage.HasAuthoredMetadata('metersPerUnit'):
        warn('Stage metersPerUnit is unauthored; using USD fallback, not verified source units')
    normalization = [units, 0, 0, 0, 0, units, 0, 0, 0, 0, units, 0, 0, 0, 0, 1]
    if axis == 'Z':
        normalization = [units, 0, 0, 0, 0, 0, -units, 0, 0, units, 0, 0, 0, 0, 0, 1]
    document = {'asset': {'version': '2.0', 'generator': 'Pro3DWorks public USD geometry exporter', 'extras': {'p3dwStageMetersPerUnit': units, 'p3dwStageUpAxis': axis}}, 'scene': 0, 'scenes': [{'nodes': [0]}], 'nodes': [{'name': 'USD meters / Y-up normalization', 'matrix': normalization, 'children': []}], 'meshes': [], 'materials': [], 'accessors': [], 'bufferViews': []}
    materials = _Materials(document, warn)
    buffers = _Buffers(document)
    retained = set()
    for prim in meshes:
        while prim and not prim.IsPseudoRoot():
            retained.add(str(prim.GetPath()))
            prim = prim.GetParent()
    node_indices, scene_nodes, bindings = {}, [], []
    xforms = UsdGeom.XformCache(_TIME)
    worlds = {}
    for prim in prims:
        path = str(prim.GetPath())
        if path not in retained:
            continue
        parent_path = str(prim.GetParent().GetPath())
        parent_index = node_indices.get(parent_path, 0)
        world = xforms.GetLocalToWorldTransform(prim)
        _matrix(world, path + ' world transform')
        if parent_path in worlds:
            parent_world = worlds[parent_path]
            det = _finite(parent_world.GetDeterminant(), path + ' parent determinant')
            _require(det != 0, f'{path}: singular parent transform unsupported')
            # Row-vector relation: Wchild = Lchild * Wparent. Deriving L from
            # world transforms also handles resetXformStack without reparenting.
            local = world * parent_world.GetInverse()
        else:
            local = world
        compensation, local = _affine_parts(local, path)
        if compensation is not None:
            helper_index = len(document['nodes'])
            document['nodes'].append({'name': 'USD affine compensation', 'matrix': _matrix(compensation, path + ' affine compensation'), 'extras': {'p3dwTransformHelper': True}})
            document['nodes'][parent_index].setdefault('children', []).append(helper_index)
            parent_index = helper_index
        matrix = _matrix(local, path + ' local transform')
        index = len(document['nodes'])
        _require(index < MAX_NODES, 'glTF scene node resource limit exceeded')
        visible = _source_visible(prim)
        name = prim.GetDisplayName() or prim.GetName()
        document['nodes'].append({'name': name, 'matrix': matrix, 'extras': {'p3dwUsdPath': path, 'p3dwSourceVisible': bool(visible)}})
        document['nodes'][parent_index].setdefault('children', []).append(index)
        scene_nodes.append({'usdPath': path, 'gltfNodeIndex': index, 'parentGltfNodeIndex': parent_index, 'name': name, 'localMatrix': matrix})
        node_indices[path], worlds[path] = index, world
    mesh_identities = {}
    triangles = 0
    for prim in meshes:
        payloads, partitions, count = _geometry(prim, materials, warn)
        triangles += count
        _require(triangles <= MAX_TRIANGLES, 'Composed triangle resource limit exceeded')
        digest = hashlib.sha256()
        for semantic, raw in payloads.items():
            digest.update(semantic.encode('ascii'))
            digest.update(struct.pack('<Q', len(raw)))
            digest.update(raw)
        for material, raw in partitions:
            digest.update(struct.pack('<IQ', material, len(raw)))
            digest.update(raw)
        identity = digest.digest()
        if identity not in mesh_identities:
            attrs = {name: buffers.add(raw, 4 if name == 'COLOR_0' else 3, 5126, 34962, name == 'POSITION') for name, raw in payloads.items()}
            primitives = [{'attributes': dict(attrs), 'indices': buffers.add(raw, 1, 5125, 34963), 'material': material, 'mode': 4} for material, raw in partitions]
            mesh_identities[identity] = len(document['meshes'])
            document['meshes'].append({'name': prim.GetDisplayName() or prim.GetName(), 'primitives': primitives})
        mesh_index = mesh_identities[identity]
        node_index = node_indices[str(prim.GetPath())]
        document['nodes'][node_index]['mesh'] = mesh_index
        bindings.append({'usdPath': str(prim.GetPath()), 'gltfNodeIndex': node_index, 'gltfMeshIndex': mesh_index, 'sourceVisible': document['nodes'][node_index]['extras']['p3dwSourceVisible']})
    report = {'format': 'glb', 'stageMetersPerUnit': units, 'stageMetersPerUnitAuthored': bool(stage.HasAuthoredMetadata('metersPerUnit')), 'stageUpAxis': axis, 'nodeCount': len(document['nodes']), 'meshCount': len(document['meshes']), 'meshInstanceCount': len(bindings), 'triangleCount': triangles, 'meshBindings': bindings, 'sceneNodes': scene_nodes, 'warnings': warnings}
    _publish(document, buffers.data, output)
    return report
