// Zero-npm configurator for the packaged Windows Native Kit. Uses Node
// built-ins only to validate the kit manifest and bind an independently
// installed, operator-authorized NVIDIA runtime without downloading SDKs or keys.
import { spawn } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { constants } from 'node:fs';
import {
  copyFile,
  lstat,
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rename,
  rmdir,
  writeFile,
} from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const EXPECTED_PACKAGE = '0.3.0';
const REQUIRED_KIT_FILES = [
  'bridge-server.mjs',
  'native-source-audit.mjs',
  'native_nvidia.py',
  'usd_geometry.py',
  'native_process.py',
  'notices/README.txt',
  'notices/dependency-roster.json',
];

const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
const slash = (p) => p.replaceAll('\\', '/');

export function nativeProviderConfig({ python, node, adapter, appPath, port = 0 }) {
  for (const [key, value] of Object.entries({ python, node, adapter, appPath })) {
    if (typeof value !== 'string' || !isAbsolute(value) || /[\u0000-\u001f"]/u.test(value)) {
      throw new Error(`${key} must be an explicit absolute local path without control characters or quotes.`);
    }
  }
  if (!Number.isInteger(port) || port < 0 || port > 65535) {
    throw new Error('Invalid loopback port.');
  }
  return {
    autoDiscoverOpenProviders: false,
    port,
    appPath,
    maxFileBytes: 256 * 1024 * 1024,
    maxJobBytes: 1024 * 1024 * 1024,
    maxOutputBytes: 1024 * 1024 * 1024,
    maxSourceFiles: 4096,
    maxConcurrentJobs: 1,
    maxChunkBytes: 8 * 1024 * 1024,
    providers: [{
      id: 'nvidia-hoops-native-local',
      label: 'NVIDIA / HOOPS native CAD — local tessellated viewing',
      version: EXPECTED_PACKAGE,
      command: python,
      args: [
        '-I', '-B', adapter,
        '--node', node,
        '--input', '{input}',
        '--output', '{output}',
        '--report', '{report}',
        '--work-dir', '{workDir}',
      ],
      supports: ['sldprt', 'sldasm', 'prt'],
      outputs: ['glb'],
      exactOutputs: [],
      licensed: true,
      timeoutMs: 15 * 60 * 1000,
      probeArgs: ['-I', '-B', adapter, '--probe', '--node', node],
      probeSuccessPattern: `P3DW_NVIDIA_NATIVE_READY ${EXPECTED_PACKAGE}`,
      probeTimeoutMs: 45000,
      environment: { PYTHONHOME: '', PYTHONPATH: '' },
    }],
  };
}

async function exists(path) {
  try {
    await lstat(path);
    return true;
  } catch (error) {
    if (error.code === 'ENOENT') return false;
    throw error;
  }
}

async function regularBytes(path) {
  const st = await lstat(path);
  if (!st.isFile() || st.isSymbolicLink()) {
    throw new Error(`Expected an ordinary local source file: ${path}`);
  }
  return readFile(path);
}

function environment(configPath, jobs) {
  const env = Object.fromEntries(
    Object.entries(process.env).filter(([key]) => !/^P3DW_CAD_|^PYTHON(?:HOME|PATH)$/i.test(key)),
  );
  if (configPath) env.P3DW_CAD_BRIDGE_CONFIG = configPath;
  if (jobs) {
    env.TEMP = jobs;
    env.TMP = jobs;
    env.TMPDIR = jobs;
  }
  return env;
}

function capture(command, args, { timeoutMs = 60000, env, cwd } = {}) {
  return new Promise((accept, reject) => {
    const child = spawn(command, args, {
      shell: false,
      windowsHide: true,
      env,
      cwd,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    let overflow = false;
    const collect = (old, chunk) => {
      const text = old + chunk;
      if (text.length > 1024 * 1024) overflow = true;
      return text.slice(-1024 * 1024);
    };
    const timer = setTimeout(() => {
      timedOut = true;
      if (process.platform === 'win32' && child.pid) {
        const killer = spawn(
          join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'taskkill.exe'),
          ['/PID', String(child.pid), '/T', '/F'],
          { shell: false, windowsHide: true, stdio: 'ignore' },
        );
        killer.once('error', () => child.kill());
      } else {
        child.kill();
      }
    }, timeoutMs);
    child.stdout.on('data', (data) => { stdout = collect(stdout, data); });
    child.stderr.on('data', (data) => { stderr = collect(stderr, data); });
    child.once('error', (error) => {
      clearTimeout(timer);
      Object.assign(error, { stdout, stderr });
      reject(error);
    });
    child.once('close', (code) => {
      clearTimeout(timer);
      if (code !== 0 || timedOut || overflow) {
        const error = new Error(
          timedOut
            ? 'Native helper preflight timed out.'
            : overflow
              ? 'Native helper preflight exceeded its diagnostic-output limit.'
              : `Native helper preflight failed (exit ${code}): ${stderr.trim().slice(-2000)}`,
        );
        Object.assign(error, { stdout, stderr });
        reject(error);
      } else {
        accept({ stdout, stderr });
      }
    });
  });
}

async function inventory(root) {
  const files = [];
  const directories = [];
  async function visit(directory) {
    const entries = (await readdir(directory, { withFileTypes: true }))
      .sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      const fullPath = join(directory, entry.name);
      const key = slash(relative(root, fullPath));
      const st = await lstat(fullPath);
      if (st.isSymbolicLink()) throw new Error(`Installation payload contains an alias: ${key}`);
      if (st.isDirectory()) {
        directories.push(key);
        await visit(fullPath);
      } else {
        const bytes = await regularBytes(fullPath);
        files.push({ path: key, bytes: bytes.length, sha256: digest(bytes) });
      }
    }
  }
  await visit(root);
  return { files, directories };
}

function validateDoctor(stdout) {
  let report;
  try {
    report = JSON.parse(stdout);
  } catch {
    throw new Error('Helper doctor did not return a JSON report.');
  }
  const provider = report.providers?.[0];
  const same = (a, b) => Array.isArray(a) && JSON.stringify([...a].sort()) === JSON.stringify([...b].sort());
  if (
    report.protocol !== 'p3dw-import-bridge/1'
    || report.ready !== true
    || report.providers?.length !== 1
    || provider.id !== 'nvidia-hoops-native-local'
    || provider.ready !== true
    || provider.version !== EXPECTED_PACKAGE
    || provider.licensed !== true
    || !same(provider.supports, ['sldprt', 'sldasm', 'prt'])
    || !same(provider.outputs, ['glb'])
    || !same(provider.exactOutputs, [])
    || !same(report.coverage?.supportedExtensions, ['sldprt', 'sldasm', 'prt'])
    || report.coverage?.wildcard !== false
    || !same(report.coverage?.exactOutputExtensions, [])
  ) {
    throw new Error('Helper doctor did not qualify exactly the configured tessellation-only native provider.');
  }
  return report;
}

function safeKitRelative(rel) {
  if (typeof rel !== 'string' || !rel || rel.includes('\\') || isAbsolute(rel)) {
    throw new Error(`Invalid kit manifest relative path: ${rel}`);
  }
  const parts = rel.split('/');
  if (parts.some((p) => !p || p === '.' || p === '..')) {
    throw new Error(`Unsafe kit manifest relative path: ${rel}`);
  }
  return rel;
}

export async function configureNativeKit({
  kitDir,
  outputDirectory,
  appPath,
  python,
  node = process.execPath,
  licensedRuntime = false,
  port = 0,
} = {}) {
  if (licensedRuntime !== true) {
    throw new Error('Explicit --licensed-runtime confirmation is required after the user accepts the NVIDIA terms and installs an entitled runtime.');
  }
  if (process.platform !== 'win32') {
    throw new Error('This local helper is qualified for Windows x86-64 only.');
  }

  const local = process.env.LOCALAPPDATA || join(homedir(), 'AppData', 'Local');
  const resolvedKitDir = resolve(kitDir || HERE);
  const defaultDistApp = resolve(resolvedKitDir, '..', 'dist', 'Pro3DWorks.html');
  const fallbackKitApp = resolve(resolvedKitDir, 'Pro3DWorks.html');
  const selectedApp = resolve(appPath || (await exists(defaultDistApp) ? defaultDistApp : fallbackKitApp));
  const manifestPath = join(resolvedKitDir, 'kit-manifest.json');
  const manifestBytes = await regularBytes(manifestPath);
  const manifestSha256 = digest(manifestBytes);
  let manifest;
  try {
    manifest = JSON.parse(manifestBytes.toString('utf8'));
  } catch {
    throw new Error(`Invalid kit manifest JSON: ${manifestPath}`);
  }
  if (manifest.schema !== 'p3dw.native-kit-manifest/1') {
    throw new Error(`Unsupported kit manifest schema: ${manifest.schema}`);
  }
  if (manifest.vendorBinariesBundled !== false) {
    throw new Error('Refusing kit manifest with unexpected vendorBinariesBundled value.');
  }
  if (!Array.isArray(manifest.files)) {
    throw new Error('Kit manifest is missing files array.');
  }

  const manifestMap = new Map();
  for (const entry of manifest.files) {
    const rel = safeKitRelative(entry?.path);
    if (!/^[0-9a-f]{64}$/.test(String(entry?.sha256 || '')) || !Number.isInteger(entry?.bytes) || entry.bytes <= 0) {
      throw new Error(`Invalid kit manifest entry for ${rel}.`);
    }
    manifestMap.set(rel, { path: rel, bytes: entry.bytes, sha256: entry.sha256 });
  }
  for (const requiredFile of REQUIRED_KIT_FILES) {
    if (!manifestMap.has(requiredFile)) {
      throw new Error(`Kit manifest is missing required file: ${requiredFile}`);
    }
  }

  const pins = new Map();
  const pin = async (filePath) => {
    const abs = resolve(filePath);
    const bytes = await regularBytes(abs);
    const previous = pins.get(abs);
    if (previous && !bytes.equals(previous)) {
      throw new Error(`Installation source changed during the transaction: ${abs}`);
    }
    pins.set(abs, bytes);
    return bytes;
  };

  for (const entry of manifestMap.values()) {
    const srcPath = resolve(resolvedKitDir, ...entry.path.split('/'));
    const bytes = await pin(srcPath);
    if (bytes.length !== entry.bytes || digest(bytes) !== entry.sha256) {
      throw new Error(`Kit file hash/size mismatch for ${entry.path}; the downloaded package may be corrupted or modified.`);
    }
  }

  const versionTag = String(manifest.version || '2.70.1').trim() || '2.70.1';
  const destination = resolve(outputDirectory || join(local, 'Pro3DWorks', `native-cad-helper-v${versionTag}`));
  const executable = resolve(python || join(local, 'Pro3DWorks', 'native-cad-runtime', 'venv', 'Scripts', 'python.exe'));
  const nodeExecutable = resolve(node);
  const parent = dirname(destination);

  const config = nativeProviderConfig({
    python: executable,
    node: nodeExecutable,
    adapter: join(destination, 'native_nvidia.py'),
    appPath: join(destination, 'Pro3DWorks.html'),
    port,
  });

  if (parent === destination || await exists(destination)) {
    throw new Error('Installation requires a fresh, unoccupied final directory; existing installations are never overwritten.');
  }
  await mkdir(parent, { recursive: true });
  const lock = join(parent, `.p3dw-native-install-${digest(destination.toLowerCase()).slice(0, 24)}.lock`);
  await mkdir(lock);

  let transaction;
  let payload;
  let published = false;
  let identity;
  let phase = 'inputs';
  const transactionId = randomUUID();

  try {
    transaction = await mkdtemp(join(parent, `.${basenameSafe(destination)}.transaction-`));
    payload = join(transaction, 'payload');
    await mkdir(payload);
    await mkdir(join(payload, 'jobs'));
    await mkdir(join(payload, 'notices'));

    for (const p of [executable, nodeExecutable]) await regularBytes(p);
    const sourceAppBytes = await pin(selectedApp);
    if (manifest.appSha256 && selectedApp === defaultDistApp && digest(sourceAppBytes) !== manifest.appSha256) {
      throw new Error('dist/Pro3DWorks.html SHA-256 mismatch against kit-manifest.json.');
    }

    phase = 'copy';
    await copyFile(selectedApp, join(payload, 'Pro3DWorks.html'), constants.COPYFILE_EXCL);
    if (!(await regularBytes(join(payload, 'Pro3DWorks.html'))).equals(sourceAppBytes)) {
      throw new Error('App copy readback mismatch.');
    }

    for (const rel of REQUIRED_KIT_FILES) {
      const srcPath = resolve(resolvedKitDir, ...rel.split('/'));
      const destPath = join(payload, ...rel.split('/'));
      const expectedBytes = pins.get(srcPath);
      await copyFile(srcPath, destPath, constants.COPYFILE_EXCL);
      if (!(await regularBytes(destPath)).equals(expectedBytes)) {
        throw new Error(`Kit payload copy readback mismatch: ${rel}`);
      }
    }

    phase = 'configuration';
    const configPath = join(destination, 'bridge.config.json');
    await writeFile(join(payload, 'bridge.config.json'), JSON.stringify(config, null, 2), { flag: 'wx' });

    const launcher = [
      '@echo off',
      'setlocal DisableDelayedExpansion',
      'set "P3DW_CAD_COMMAND="',
      'set "P3DW_CAD_APP_PATH="',
      'set "P3DW_CAD_BRIDGE_PORT="',
      'set "P3DW_CAD_BRIDGE_CONFIG=%~dp0bridge.config.json"',
      'set "TEMP=%~dp0jobs"',
      'set "TMP=%~dp0jobs"',
      'set "TMPDIR=%~dp0jobs"',
      'echo Pro3DWorks local native CAD helper. Close this window to stop it.',
      `"${nodeExecutable.replaceAll('%', '%%')}" "%~dp0bridge-server.mjs" --open`,
      'if errorlevel 1 pause',
      'endlocal',
      '',
    ].join('\r\n');
    await writeFile(join(payload, 'Start-Pro3DWorks-Native.cmd'), launcher, { flag: 'wx' });

    const stagedExpected = await inventory(payload);
    const probeTemp = join(transaction, 'preflight-temp');
    await mkdir(probeTemp);
    const stagedConfig = nativeProviderConfig({
      python: executable,
      node: nodeExecutable,
      adapter: join(payload, 'native_nvidia.py'),
      appPath: join(payload, 'Pro3DWorks.html'),
      port,
    });
    const stagedConfigPath = join(transaction, 'staging.config.json');
    await writeFile(stagedConfigPath, JSON.stringify(stagedConfig, null, 2), { flag: 'wx' });

    const execute = async (label, command, args, options) => {
      let result;
      try {
        result = await capture(command, args, options);
      } catch (error) {
        await writeFile(join(transaction, `${label}.stdout.log`), error.stdout || '');
        await writeFile(join(transaction, `${label}.stderr.log`), error.stderr || '');
        throw error;
      }
      await writeFile(join(transaction, `${label}.stdout.log`), result.stdout);
      await writeFile(join(transaction, `${label}.stderr.log`), result.stderr);
      return result.stdout;
    };

    const verifySources = async () => {
      for (const [p, bytes] of pins) {
        if (!(await regularBytes(p)).equals(bytes)) {
          throw new Error(`Installation source changed during the transaction: ${p}`);
        }
      }
    };

    phase = 'probe';
    const probe = await execute(
      'runtime-probe',
      executable,
      stagedConfig.providers[0].probeArgs,
      { timeoutMs: 50000, env: environment(null, probeTemp), cwd: payload },
    );
    if (!probe.split(/\r?\n/).includes(config.providers[0].probeSuccessPattern)) {
      throw new Error('Native adapter did not return the real runtime readiness sentinel.');
    }

    phase = 'staging-doctor';
    const stagedDoctor = validateDoctor(
      await execute(
        'staging-doctor',
        nodeExecutable,
        [join(payload, 'bridge-server.mjs'), '--doctor', '--json'],
        { env: environment(stagedConfigPath, probeTemp), cwd: payload },
      ),
    );

    phase = 'source-readback';
    await verifySources();
    if (JSON.stringify(await inventory(payload)) !== JSON.stringify(stagedExpected)) {
      throw new Error('Staging payload byte/hash readback mismatch after preflight.');
    }

    const record = {
      schema: 'p3dw.local-native-install/2',
      transactionId,
      installedUTC: new Date().toISOString(),
      helperDirectory: destination,
      sourceApp: selectedApp,
      appSha256: digest(sourceAppBytes),
      appBytes: sourceAppBytes.length,
      node: nodeExecutable,
      python: executable,
      pythonFiles: ['native_nvidia.py', 'native_process.py', 'usd_geometry.py'],
      runtimeProbe: probe.trim(),
      configuration: configPath,
      launcher: join(destination, 'Start-Pro3DWorks-Native.cmd'),
      transactionEvidence: transaction,
      vendorBinariesBundled: false,
      packagedFromKit: true,
      kitManifestSha256: manifestSha256,
      loopbackOriginGate: true,
      sameUserProcessAuthentication: false,
      autoStartInstalled: false,
      htmlAutoProcessingInstalled: false,
      sourcePins: [...pins].map(([p, bytes]) => ({ path: p, bytes: bytes.length, sha256: digest(bytes) })),
      stagingDoctor: { ready: stagedDoctor.ready, sameExternalRuntime: true },
      finalDoctorReceipt: join(transaction, 'completion.json'),
      payload: stagedExpected,
    };
    await writeFile(join(payload, 'installation.json'), JSON.stringify(record, null, 2), { flag: 'wx' });

    const expected = await inventory(payload);
    const verifyPayload = async (directory) => {
      if (JSON.stringify(await inventory(directory)) !== JSON.stringify(expected)) {
        throw new Error('Installation payload byte/hash readback mismatch.');
      }
    };

    phase = 'staging-readback';
    await verifyPayload(payload);
    identity = await lstat(payload, { bigint: true });

    phase = 'publication';
    if (await exists(destination)) {
      throw new Error('Final installation directory became occupied; refusing publication.');
    }
    await rename(payload, destination);
    published = true;

    phase = 'final-doctor';
    const finalDoctor = validateDoctor(
      await execute(
        'final-doctor',
        nodeExecutable,
        [join(destination, 'bridge-server.mjs'), '--doctor', '--json'],
        { env: environment(configPath, probeTemp), cwd: destination },
      ),
    );

    phase = 'final-readback';
    await verifyPayload(destination);
    await verifySources();

    const completion = {
      schema: 'p3dw.local-native-install-completion/1',
      state: 'completed',
      transactionId,
      helperDirectory: destination,
      finalDoctor,
      payload: expected,
      installationSha256: digest(await regularBytes(join(destination, 'installation.json'))),
      verifiedUTC: new Date().toISOString(),
      scope: 'Packaged Windows Native Kit configuration/runtime probes only; NVIDIA/HOOPS binaries stay external.',
    };
    await writeFile(join(transaction, 'completion.json'), JSON.stringify(completion, null, 2), { flag: 'wx' });
    if (JSON.parse(await readFile(join(transaction, 'completion.json'), 'utf8')).state !== 'completed') {
      throw new Error('Completion receipt readback failed.');
    }

    return {
      ...record,
      finalDoctor: { ready: finalDoctor.ready },
      installationSha256: completion.installationSha256,
    };
  } catch (error) {
    let rollbackError;
    if (published) {
      try {
        const current = await lstat(destination, { bigint: true });
        if (
          current.dev !== identity.dev
          || current.ino !== identity.ino
          || JSON.parse(await readFile(join(destination, 'installation.json'), 'utf8')).transactionId !== transactionId
        ) {
          throw new Error('Published directory ownership changed; refusing to move an unowned path.');
        }
        await rename(destination, payload);
        published = false;
      } catch (caught) {
        rollbackError = caught;
      }
    }
    if (transaction) {
      const failure = {
        schema: 'p3dw.local-native-install-failure/1',
        state: 'failed',
        transactionId,
        phase,
        helperDirectory: destination,
        message: error.message,
        finalDirectoryAbsent: !(await exists(destination)),
        rollbackError: rollbackError?.message || null,
        scope: 'Retained owned installation transaction; no user installation was overwritten.',
      };
      try {
        await writeFile(join(transaction, 'failure.json'), JSON.stringify(failure, null, 2), { flag: 'wx' });
      } catch (e) {
        error.message += ` Failure-evidence write failed: ${e.message}`;
      }
      error.failureDirectory = transaction;
      error.message += ` Failure evidence: ${transaction}`;
    }
    if (rollbackError) error.message += ` ROLLBACK BLOCKED: ${rollbackError.message}`;
    throw error;
  } finally {
    await rmdir(lock);
  }
}

function basenameSafe(p) {
  const parts = p.split(/[\\/]/).filter(Boolean);
  return parts[parts.length - 1] || 'native-cad-helper';
}

async function main() {
  const args = process.argv.slice(2);
  const value = (flag) => {
    const at = args.indexOf(flag);
    return at < 0 ? undefined : args[at + 1];
  };
  const result = await configureNativeKit({
    kitDir: value('--kit-dir'),
    outputDirectory: value('--output-dir'),
    appPath: value('--app'),
    python: value('--python'),
    node: value('--node'),
    licensedRuntime: args.includes('--licensed-runtime'),
    port: value('--port') === undefined ? 0 : Number(value('--port')),
  });
  console.log(JSON.stringify({
    helperDirectory: result.helperDirectory,
    launcher: result.launcher,
    appSha256: result.appSha256,
    installationSha256: result.installationSha256,
    finalDoctor: result.finalDoctor,
    transactionEvidence: result.transactionEvidence,
    vendorBinariesBundled: result.vendorBinariesBundled,
    packagedFromKit: result.packagedFromKit,
  }, null, 2));
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
