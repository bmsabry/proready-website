"""Windows-only, race-free ownership of one native invocation and descendants.

Create the root suspended IN a private KILL_ON_JOB_CLOSE Job, verify membership,
then resume its retained primary thread. Job handles are never inherited. Every exit
path terminates remaining members, measures native Job-zero and reaps the root.
No name-based/global process discovery or third-party package is used.
"""
from pathlib import Path
import ctypes
from ctypes import wintypes as W
import json
import math
import os
import subprocess
import time

if os.name == 'nt':
    import msvcrt
    K = ctypes.WinDLL('kernel32', use_last_error=True)
    SIZE = ctypes.c_size_t
    # Public WinBase.h: ProcThreadAttributeValue(JobList=13, FALSE, TRUE, FALSE).
    PROC_THREAD_ATTRIBUTE_JOB_LIST = 13 | 0x00020000

    class STARTUPINFO(ctypes.Structure):
        _fields_ = [('cb', W.DWORD), ('lpReserved', W.LPWSTR), ('lpDesktop', W.LPWSTR),
            ('lpTitle', W.LPWSTR), ('dwX', W.DWORD), ('dwY', W.DWORD),
            ('dwXSize', W.DWORD), ('dwYSize', W.DWORD), ('dwXCountChars', W.DWORD),
            ('dwYCountChars', W.DWORD), ('dwFillAttribute', W.DWORD),
            ('dwFlags', W.DWORD), ('wShowWindow', W.WORD), ('cbReserved2', W.WORD),
            ('lpReserved2', ctypes.POINTER(W.BYTE)), ('hStdInput', W.HANDLE),
            ('hStdOutput', W.HANDLE), ('hStdError', W.HANDLE)]

    class STARTUPINFOEX(ctypes.Structure):
        _fields_ = [('StartupInfo', STARTUPINFO), ('lpAttributeList', W.LPVOID)]

    class PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [('hProcess', W.HANDLE), ('hThread', W.HANDLE),
                    ('dwProcessId', W.DWORD), ('dwThreadId', W.DWORD)]

    class BASIC_LIMIT(ctypes.Structure):
        _fields_ = [('PerProcessUserTimeLimit', ctypes.c_longlong),
            ('PerJobUserTimeLimit', ctypes.c_longlong), ('LimitFlags', W.DWORD),
            ('MinimumWorkingSetSize', SIZE), ('MaximumWorkingSetSize', SIZE),
            ('ActiveProcessLimit', W.DWORD), ('Affinity', SIZE),
            ('PriorityClass', W.DWORD), ('SchedulingClass', W.DWORD)]

    class IO_COUNTERS(ctypes.Structure):
        _fields_ = [(key, ctypes.c_ulonglong) for key in ('ReadOperationCount',
            'WriteOperationCount', 'OtherOperationCount', 'ReadTransferCount',
            'WriteTransferCount', 'OtherTransferCount')]

    class EXTENDED_LIMIT(ctypes.Structure):
        _fields_ = [('BasicLimitInformation', BASIC_LIMIT), ('IoInfo', IO_COUNTERS),
            ('ProcessMemoryLimit', SIZE), ('JobMemoryLimit', SIZE),
            ('PeakProcessMemoryUsed', SIZE), ('PeakJobMemoryUsed', SIZE)]

    class ACCOUNTING(ctypes.Structure):
        _fields_ = [(key, ctypes.c_longlong) for key in ('TotalUserTime',
            'TotalKernelTime', 'ThisPeriodTotalUserTime', 'ThisPeriodTotalKernelTime')] + [
            (key, W.DWORD) for key in ('TotalPageFaultCount', 'TotalProcesses',
                'ActiveProcesses', 'TotalTerminatedProcesses')]

    def _api(name, restype, *argtypes):
        function = getattr(K, name)
        function.restype, function.argtypes = restype, list(argtypes)
        return function

    _api('CreateJobObjectW', W.HANDLE, W.LPVOID, W.LPCWSTR)
    _api('SetInformationJobObject', W.BOOL, W.HANDLE, ctypes.c_int, W.LPVOID, W.DWORD)
    _api('QueryInformationJobObject', W.BOOL, W.HANDLE, ctypes.c_int, W.LPVOID, W.DWORD, W.LPVOID)
    _api('IsProcessInJob', W.BOOL, W.HANDLE, W.HANDLE, ctypes.POINTER(W.BOOL))
    _api('TerminateJobObject', W.BOOL, W.HANDLE, W.UINT)
    _api('TerminateProcess', W.BOOL, W.HANDLE, W.UINT)
    _api('WaitForSingleObject', W.DWORD, W.HANDLE, W.DWORD)
    _api('GetExitCodeProcess', W.BOOL, W.HANDLE, ctypes.POINTER(W.DWORD))
    _api('ResumeThread', W.DWORD, W.HANDLE)
    _api('CloseHandle', W.BOOL, W.HANDLE)
    _api('GetCurrentProcess', W.HANDLE)
    _api('DuplicateHandle', W.BOOL, W.HANDLE, W.HANDLE, W.HANDLE,
        ctypes.POINTER(W.HANDLE), W.DWORD, W.BOOL, W.DWORD)
    _api('InitializeProcThreadAttributeList', W.BOOL, W.LPVOID, W.DWORD, W.DWORD, ctypes.POINTER(SIZE))
    _api('UpdateProcThreadAttribute', W.BOOL, W.LPVOID, W.DWORD, SIZE, W.LPVOID, SIZE, W.LPVOID, W.LPVOID)
    _api('DeleteProcThreadAttributeList', None, W.LPVOID)
    _api('CreateProcessW', W.BOOL, W.LPCWSTR, W.LPWSTR, W.LPVOID, W.LPVOID,
        W.BOOL, W.DWORD, W.LPVOID, W.LPCWSTR, ctypes.POINTER(STARTUPINFOEX), ctypes.POINTER(PROCESS_INFORMATION))


def _checked(value):
    if not value:
        raise ctypes.WinError(ctypes.get_last_error())
    return value


def _account(job):
    info = ACCOUNTING()
    _checked(K.QueryInformationJobObject(job, 1, ctypes.byref(info), ctypes.sizeof(info), None))
    return info


def _verify_job_membership(job, root):
    member = W.BOOL()
    _checked(K.IsProcessInJob(root, job, ctypes.byref(member)))
    if not member.value:
        raise RuntimeError('Native root was not created in the private Job.')


def _duplicate(stream):
    duplicate = W.HANDLE()
    current = K.GetCurrentProcess()
    _checked(K.DuplicateHandle(current, msvcrt.get_osfhandle(stream.fileno()), current,
        ctypes.byref(duplicate), 0, True, 2))  # DUPLICATE_SAME_ACCESS
    return duplicate


def _wait_root(root, milliseconds):
    value = K.WaitForSingleObject(root, milliseconds)
    if value not in (0, 258):
        raise ctypes.WinError(ctypes.get_last_error())
    return value == 0


def run_owned(argv, *, cwd, env, stdout, stderr, timeout, cancel_event=None,
              observation_path=None):
    """Return CompletedProcess after *all* owned members stop, or re-raise.

    stdout/stderr are binary files (not PIPE). Cancellation supports a threading
    Event and BaseException/KeyboardInterrupt unwinding. Abrupt parent death is
    covered from creation by KILL_ON_JOB_CLOSE. Windows 10+ JOB_LIST support is
    required; unsupported attributes/creation fail closed, with no late assign.
    """
    if os.name != 'nt':
        raise RuntimeError('The qualified native process owner requires Windows.')
    if isinstance(timeout, bool) or not isinstance(timeout, (float, int)) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError('A finite positive invocation timeout is required.')
    command = [os.fspath(value) for value in argv]
    if not command or not all(isinstance(value, str) and value and '\0' not in value for value in command):
        raise ValueError('An explicit nonempty argv is required.')
    # No shell/PATH interpretation: callers supply the pinned absolute runtime.
    executable = Path(command[0])
    if not executable.is_absolute() or not executable.is_file():
        raise ValueError('An existing absolute executable is required.')
    environment = dict(env)
    if any(not isinstance(k, str) or not isinstance(v, str) or '\0' in k + v or '=' in k
           for k, v in environment.items()):
        raise ValueError('Invalid child environment.')
    block = ctypes.create_unicode_buffer('\0'.join(k+'='+v for k,v in sorted(environment.items(), key=lambda row: row[0].upper())) + '\0\0')
    started = time.monotonic()
    deadline = started + timeout
    observation = {'schema':'p3dw.native-process/1', 'command':command,
        'assignedBeforeResume':False, 'rootReaped':False,
        'assignedAtCreation':None, 'jobAssignmentMode':'creation-time-job-list',
        'activeProcessesAfterCleanup':None, 'outcome':'setup'}
    job, duplicates, attributes = None, [], None
    attributes_initialized = False
    pi = PROCESS_INFORMATION()
    resumed = False
    error = None
    cleanup_error = None
    returncode = None
    try:
        job = _checked(K.CreateJobObjectW(None, None))
        limits = EXTENDED_LIMIT()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE; no breakaway
        _checked(K.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)))
        with open(os.devnull, 'rb') as stdin:
            for stream in (stdin, stdout, stderr):
                duplicates.append(_duplicate(stream))
        handles = (W.HANDLE * 3)(*(value.value for value in duplicates))
        size = SIZE()
        K.InitializeProcThreadAttributeList(None, 2, 0, ctypes.byref(size))
        storage = ctypes.create_string_buffer(size.value)
        attributes = ctypes.cast(storage, W.LPVOID)
        _checked(K.InitializeProcThreadAttributeList(attributes, 2, 0, ctypes.byref(size)))
        attributes_initialized = True
        _checked(K.UpdateProcThreadAttribute(attributes, 0, 0x20002,
            ctypes.cast(handles, W.LPVOID), ctypes.sizeof(handles), None, None))
        # Keep both arrays alive through CreateProcessW. JOB_LIST associates
        # the root inside native creation, not in a later Python-owned window.
        jobs = (W.HANDLE * 1)(job)
        _checked(K.UpdateProcThreadAttribute(attributes, 0, PROC_THREAD_ATTRIBUTE_JOB_LIST,
            ctypes.cast(jobs, W.LPVOID), ctypes.sizeof(jobs), None, None))
        startup = STARTUPINFOEX()
        startup.StartupInfo.cb = ctypes.sizeof(startup)
        startup.StartupInfo.dwFlags = 0x100  # STARTF_USESTDHANDLES
        startup.StartupInfo.hStdInput, startup.StartupInfo.hStdOutput, startup.StartupInfo.hStdError = handles
        startup.lpAttributeList = attributes
        line = ctypes.create_unicode_buffer(subprocess.list2cmdline(command))
        _checked(K.CreateProcessW(str(executable), line, None, None, True,
            0x4 | 0x400 | 0x80000 | 0x8000000, block, os.fspath(cwd),
            ctypes.byref(startup), ctypes.byref(pi)))
        observation['rootPID'] = int(pi.dwProcessId)
        observation['assignedAtCreation'] = True
        _verify_job_membership(job, pi.hProcess)  # Still suspended; fail closed before resume.
        observation['assignedBeforeResume'] = True
        if K.ResumeThread(pi.hThread) == 0xffffffff:
            raise ctypes.WinError(ctypes.get_last_error())
        resumed = True
        observation['outcome'] = 'running'
        while not _wait_root(pi.hProcess, 0):
            if cancel_event is not None and cancel_event.is_set():
                observation['outcome'] = 'cancelled'
                raise InterruptedError('Native invocation cancelled.')
            left = deadline - time.monotonic()
            if left <= 0:
                observation['outcome'] = 'timeout'
                raise subprocess.TimeoutExpired(command, timeout)
            _wait_root(pi.hProcess, max(1, min(25, int(left * 1000))))
        code = W.DWORD()
        _checked(K.GetExitCodeProcess(pi.hProcess, ctypes.byref(code)))
        returncode = int(code.value)
        observation['outcome'] = 'root-exit'
    except BaseException as exc:
        error = exc
        if observation['outcome'] in ('setup', 'running'):
            observation['outcome'] = 'exception'
    finally:
        # Cleanup is independent of success, cancellation, setup/membership
        # failure and the immediate root's exit status. Query native accounting;
        # never synthesize a zero or infer it just from root termination.
        failures = []
        try:
            if job is not None:
                try:
                    before = _account(job)
                    observation['activeProcessesBeforeCleanup'] = int(before.ActiveProcesses)
                except BaseException as exc:
                    failures.append(exc)
                # An accounting/logging failure must NEVER skip termination.
                # It remains an explicit nonacceptance, even if cleanup works.
                try:
                    _checked(K.TerminateJobObject(job, 1))
                except BaseException as exc:
                    failures.append(exc)
                    # KILL_ON_JOB_CLOSE is the independent owned-tree fallback.
                    if K.CloseHandle(job):
                        job = None
                        observation['jobClosedForCleanupFallback'] = True
                if job is not None:
                    try:
                        cleanup_deadline = time.monotonic() + 5
                        while True:
                            info = _account(job)
                            if not info.ActiveProcesses:
                                break
                            if time.monotonic() >= cleanup_deadline:
                                raise RuntimeError('Native Job did not reach active-process zero.')
                            time.sleep(.01)
                        observation['activeProcessesAfterCleanup'] = int(info.ActiveProcesses)
                        observation['totalProcesses'] = int(info.TotalProcesses)
                    except BaseException as exc:
                        failures.append(exc)
            if pi.hProcess:
                # Never depend on post-creation Python bookkeeping: native
                # creation may succeed before an observer/verification throws.
                root_termination_error = None
                try:
                    if not _wait_root(pi.hProcess, 0):
                        _checked(K.TerminateProcess(pi.hProcess, 1))
                except BaseException as exc:
                    root_termination_error = exc
                # Mandatory root reap is independent of every prior observer,
                # Job-termination and accounting exception.
                try:
                    observation['rootReaped'] = _wait_root(pi.hProcess, 5000)
                    if not observation['rootReaped']:
                        raise RuntimeError('Native root did not reach the signaled/reaped state.')
                except BaseException as exc:
                    failures.append(exc)
                # Job exit accounting can finish before the root is signaled.
                # TerminateProcess then reports ACCESS_DENIED for an already
                # terminating root. Accept ONLY that race after native reap.
                if root_termination_error is not None and not (
                    observation['rootReaped'] and isinstance(root_termination_error, OSError)
                    and getattr(root_termination_error, 'winerror', None) == 5):
                    failures.append(root_termination_error)
            if failures:
                cleanup_error = failures[0]
                observation['cleanupError'] = '; '.join(type(exc).__name__ + ': ' + str(exc) for exc in failures)
        finally:
            if attributes_initialized:
                K.DeleteProcThreadAttributeList(attributes)
            for handle in [pi.hThread, pi.hProcess] + duplicates + [job]:
                if handle:
                    K.CloseHandle(handle)
            observation['resumed'] = resumed
            observation['seconds'] = time.monotonic() - started
            if observation_path is not None:
                try:
                    with Path(observation_path).open('x', encoding='utf-8') as stream:
                        json.dump(observation, stream, indent=2, allow_nan=False)
                except BaseException as exc:
                    cleanup_error = cleanup_error or exc
    if cleanup_error is not None:
        raise RuntimeError('Native process cleanup/observation failed: ' + str(cleanup_error)) from (error or cleanup_error)
    if error is not None:
        raise error
    result = subprocess.CompletedProcess(command, returncode)
    result.lifecycle = observation
    return result
