This roster covers ONLY the pre-bundled kit JavaScript files (bridge-server.mjs, native-source-audit.mjs).
Their esbuild input closure contains only project source and Node builtins; zero third-party npm packages are bundled.
Pro3DWorks.html has its own existing in-app licences (Help -> Licence & third-party notices).
NVIDIA/HOOPS/PXR and their licences/notices remain external in the operator-installed runtime.
