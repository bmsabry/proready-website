# Pro3DWorks License

Copyright © 2026 ProReadyEngineer LLC. All rights reserved.

## Grant

Pro3DWorks (the "Software") is made available **free of charge**. Permission is granted to any person
to download, run, and share unmodified copies of the built application (`Pro3DWorks.html`) for personal
and commercial use.

Modification, redistribution of modified versions, rebranding, or incorporation of this source code into
other products requires prior written permission from ProReadyEngineer LLC
([contact](https://www.proreadyengineer.com/contact)).

## Third-party components

The Software embeds open-source components, each under its own license:

| Component | License | Source |
|---|---|---|
| occt-import-js / OpenCascade | LGPL-2.1 | https://github.com/kovacsv/occt-import-js |
| three.js | MIT | https://github.com/mrdoob/three |
| Mapbox Earcut 3.0.2 (Three.js source module) | ISC | https://github.com/mapbox/earcut/tree/v3.0.2 |
| three-mesh-bvh | MIT | https://github.com/gkjohnson/three-mesh-bvh |
| three-gpu-pathtracer | MIT | https://github.com/gkjohnson/three-gpu-pathtracer |
| AssimpJS / Assimp | BSD-3-Clause | https://github.com/kovacsv/assimpjs |
| Inter typeface (latin variable subset, `vendor/fonts`) | SIL OFL 1.1 | https://github.com/rsms/inter |
| SCOREC Parasolid qualification fixture | BSD-3-Clause | https://github.com/SCOREC/core/blob/03d6a614684bda402afb95c54610334e5cfcb44f/python_wrappers/input/sphere.x_t |

The LGPL-2.1 component is used unmodified; its source is available at the link above.

The Parasolid XT text-reader source under `vendor/parasolid-xt` was identified by the Pro3DWorks
project owner as Fable-generated and was supplied with an explicit instruction to include and
redistribute it in this project. The supplied archive contained no separate copyright notice or
license file; inclusion under the Pro3DWorks project grant therefore relies on the project owner's
representation that they hold the rights necessary to provide that authorization. Its provenance,
received archive hash, modifications, and deliberately limited text-only/tessellated scope are
recorded in that directory. This grant does not cover Siemens software, SDK code, trademarks, or
other third-party intellectual property.

The BSD-3-Clause SCOREC Parasolid qualification fixture retains its upstream copyright and license
text in `test/fixtures/SCOREC_LICENSE.txt`.
The embedded XT worker uses the Mapbox Earcut 3.0.2 implementation distributed in the pinned
Three.js package for holes-aware trim triangulation; its ISC notice is retained in
`vendor/parasolid-xt/EARCUT_LICENSE.txt`.

## Disclaimer of warranty and liability

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, ACCURACY AND
NONINFRINGEMENT. MEASUREMENTS, MASS PROPERTIES, BILLS OF MATERIALS, COST ESTIMATES, AI-GENERATED CONTENT
AND RENDERED IMAGES ARE APPROXIMATIONS AND MAY CONTAIN ERRORS OR INACCURACIES. IN NO EVENT SHALL
PROREADYENGINEER LLC, ITS MEMBERS, EMPLOYEES OR CONTRIBUTORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OF OR RELIANCE ON ITS OUTPUTS. INDEPENDENTLY VERIFY ALL RESULTS BEFORE ANY
ENGINEERING, MANUFACTURING, SAFETY, REGULATORY OR COMMERCIAL DECISION.
