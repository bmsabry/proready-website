Pro3DWorks v2.70.1 - Windows Native CAD Kit (SolidWorks & Siemens NX)
=======================================================================

This folder contains the self-contained Pro3DWorks viewer (dist\Pro3DWorks.html)
plus the local native CAD bridge needed to decode SolidWorks (.SLDPRT / .SLDASM)
and Siemens NX (.prt) geometry directly on Windows x64.

Two-step setup (no npm or source checkout needed):
  1. Double-click Setup-Pro3DWorks-Native.cmd once.
     - Checks for Node.js 20+ and Python 3.12 (offers optional winget install if missing).
     - Shows NVIDIA usd-convert-cad 0.3.0 license terms (uses Tech Soft 3D HOOPS Exchange SDK)
       and asks you to type I ACCEPT before creating a local Python venv and installing it.
     - Verifies the pre-bundled helper files by SHA-256 and runs diagnostics.
  2. Double-click Start-Pro3DWorks-Native.cmd anytime to launch Pro3DWorks with native support.

Notes:
  - No proprietary NVIDIA/HOOPS binaries or licence keys are bundled in this ZIP.
  - Native SolidWorks / NX results are tessellated viewing geometry (not editable B-rep).
  - For assemblies (.SLDASM or NX .prt), choose Open assembly folder... or select the root
    together with all referenced part/subassembly files.
  - Full guide: docs\LOCAL_NATIVE_GUIDE.md
