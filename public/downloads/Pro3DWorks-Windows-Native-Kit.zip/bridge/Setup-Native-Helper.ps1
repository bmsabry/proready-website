[CmdletBinding()]
param(
  [string]$HelperDir = '',
  [string]$RuntimeDir = '',
  [switch]$CheckOnly,
  [switch]$NoLaunch
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
$KitManifestPath = Join-Path $Root 'native-kit\kit-manifest.json'
$PkgJsonPath = Join-Path $Root 'package.json'
$IsKitMode = Test-Path -LiteralPath (Join-Path $Root 'native-kit\configure-kit.mjs') -PathType Leaf

$AppVersion = '2.70.1'
if (Test-Path -LiteralPath $KitManifestPath -PathType Leaf) {
  $km = Get-Content -Raw -LiteralPath $KitManifestPath | ConvertFrom-Json
  if ($km.PSObject.Properties['version'] -and $km.version) { $AppVersion = [string]$km.version }
} elseif (Test-Path -LiteralPath $PkgJsonPath -PathType Leaf) {
  $pj = Get-Content -Raw -LiteralPath $PkgJsonPath | ConvertFrom-Json
  if ($pj.PSObject.Properties['version'] -and $pj.version) { $AppVersion = [string]$pj.version }
}

if ([string]::IsNullOrWhiteSpace($HelperDir)) {
  $HelperDir = Join-Path $env:LOCALAPPDATA "Pro3DWorks\native-cad-helper-v$AppVersion"
}
if ([string]::IsNullOrWhiteSpace($RuntimeDir)) {
  $RuntimeDir = Join-Path $env:LOCALAPPDATA 'Pro3DWorks\native-cad-runtime'
}

if (-not [Environment]::Is64BitOperatingSystem) {
  Write-Error 'Pro3DWorks local native CAD support requires 64-bit Windows (x86-64).'
  exit 1
}

function Refresh-ProcessPath {
  $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
  $user = [Environment]::GetEnvironmentVariable('Path', 'User')
  $combined = @($machine, $user) | Where-Object { $_ }
  if ($combined.Count -gt 0) {
    $env:Path = $combined -join ';'
  }
}

function Test-Node20([string]$Candidate) {
  if ([string]::IsNullOrWhiteSpace($Candidate) -or -not (Test-Path -LiteralPath $Candidate -PathType Leaf)) {
    return $null
  }
  try {
    $out = (& $Candidate -p "Number(process.versions.node.split('.')[0])" 2>$null | Out-String).Trim()
    if ($LASTEXITCODE -eq 0 -and ($out -match '^\d+$') -and ([int]$out -ge 20)) {
      return [IO.Path]::GetFullPath($Candidate)
    }
  } catch {
  }
  return $null
}

function Find-Node20 {
  $candidates = New-Object System.Collections.Generic.List[string]
  if ($env:P3DW_NATIVE_NODE) { $candidates.Add($env:P3DW_NATIVE_NODE) }
  $hermesRoot = Join-Path $env:LOCALAPPDATA 'hermes\tools'
  if (Test-Path -LiteralPath $hermesRoot -PathType Container) {
    Get-ChildItem -Path $hermesRoot -Directory -Filter 'node-*' -ErrorAction SilentlyContinue |
      ForEach-Object { $candidates.Add((Join-Path $_.FullName 'node.exe')) }
  }
  $cmdNode = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($cmdNode) { $candidates.Add($cmdNode.Source) }
  if ($env:ProgramFiles) { $candidates.Add((Join-Path $env:ProgramFiles 'nodejs\node.exe')) }
  $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe'))

  foreach ($cand in $candidates) {
    $ok = Test-Node20 $cand
    if ($ok) { return $ok }
  }
  return $null
}

function Test-Python312([string]$Candidate) {
  if ([string]::IsNullOrWhiteSpace($Candidate) -or -not (Test-Path -LiteralPath $Candidate -PathType Leaf)) {
    return $null
  }
  try {
    $out = (& $Candidate -I -c "import sys; print(f'{sys.version_info[0]}.{sys.version_info[1]}')" 2>$null | Out-String).Trim()
    if ($LASTEXITCODE -eq 0 -and $out -eq '3.12') {
      return [IO.Path]::GetFullPath($Candidate)
    }
  } catch {
  }
  return $null
}

function Find-Python312 {
  $pyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
  if ($pyLauncher) {
    try {
      $resolved = (& $pyLauncher.Source -3.12 -c "import sys; print(sys.executable)" 2>$null | Out-String).Trim()
      if ($LASTEXITCODE -eq 0) {
        $ok = Test-Python312 $resolved
        if ($ok) { return $ok }
      }
    } catch {
    }
  }
  $candidates = New-Object System.Collections.Generic.List[string]
  $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'))
  $candidates.Add('C:\Python312\python.exe')
  if ($env:ProgramFiles) { $candidates.Add((Join-Path $env:ProgramFiles 'Python312\python.exe')) }
  $cmdPy = Get-Command python.exe -ErrorAction SilentlyContinue
  if ($cmdPy) { $candidates.Add($cmdPy.Source) }

  foreach ($cand in $candidates) {
    $ok = Test-Python312 $cand
    if ($ok) { return $ok }
  }
  return $null
}

function Test-UsdConvertCad([string]$PyExe) {
  if ([string]::IsNullOrWhiteSpace($PyExe) -or -not (Test-Path -LiteralPath $PyExe -PathType Leaf)) {
    return $false
  }
  try {
    $ver = (& $PyExe -I -c "import importlib.metadata; print(importlib.metadata.version('usd-convert-cad'))" 2>$null | Out-String).Trim()
    return ($LASTEXITCODE -eq 0 -and $ver -eq '0.3.0')
  } catch {
    return $false
  }
}

function Invoke-HelperDoctor([string]$NodeExe, [string]$TargetHelperDir) {
  $serverJs = Join-Path $TargetHelperDir 'bridge-server.mjs'
  $cfgJson = Join-Path $TargetHelperDir 'bridge.config.json'
  if (-not (Test-Path -LiteralPath $serverJs -PathType Leaf) -or -not (Test-Path -LiteralPath $cfgJson -PathType Leaf)) {
    return $null
  }
  $prevCfg = [Environment]::GetEnvironmentVariable('P3DW_CAD_BRIDGE_CONFIG', 'Process')
  try {
    $env:P3DW_CAD_BRIDGE_CONFIG = $cfgJson
    $raw = (& $NodeExe $serverJs --doctor --json 2>$null | Out-String)
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) {
      return $null
    }
    return ($raw | ConvertFrom-Json)
  } catch {
    return $null
  } finally {
    if ($null -eq $prevCfg) {
      Remove-Item Env:\P3DW_CAD_BRIDGE_CONFIG -ErrorAction SilentlyContinue
    } else {
      $env:P3DW_CAD_BRIDGE_CONFIG = $prevCfg
    }
  }
}

Write-Host ''
Write-Host "Pro3DWorks v$AppVersion - Windows Native SolidWorks / NX Setup"
Write-Host '--------------------------------------------------------------'
Write-Host ("Mode          : " + $(if ($IsKitMode) { 'Packaged Windows Native Kit (zero npm required)' } else { 'Source repository checkout' }))
Write-Host "App HTML      : $(Join-Path $Root 'dist\Pro3DWorks.html')"
Write-Host "Helper target : $HelperDir"
Write-Host "Runtime venv  : $RuntimeDir"
Write-Host ''

if (-not (Test-Path -LiteralPath (Join-Path $Root 'dist\Pro3DWorks.html') -PathType Leaf)) {
  Write-Error "dist\Pro3DWorks.html was not found under $Root."
  exit 1
}

$nodeExe = Find-Node20
$venvPython = Join-Path $RuntimeDir 'venv\Scripts\python.exe'
$runtimeReady = Test-UsdConvertCad $venvPython
$py312 = if ($runtimeReady) { $venvPython } else { Find-Python312 }
$helperReport = if ($nodeExe) { Invoke-HelperDoctor $nodeExe $HelperDir } else { $null }
$helperReady = ($null -ne $helperReport -and $helperReport.PSObject.Properties['ready'] -and $helperReport.ready -eq $true)

if ($CheckOnly) {
  Write-Host ("Node.js 20+   : " + $(if ($nodeExe) { "[OK] $nodeExe" } else { '[MISSING] Install Node.js 20+ (OpenJS.NodeJS.LTS)' }))
  Write-Host ("Python 3.12   : " + $(if ($py312) { "[OK] $py312" } else { '[MISSING] Install Python 3.12 (Python.Python.3.12)' }))
  Write-Host ("NVIDIA runtime: " + $(if ($runtimeReady) { "[OK] usd-convert-cad 0.3.0 in $venvPython" } else { '[NOT INSTALLED] Requires license consent + pip install usd-convert-cad==0.3.0' }))
  Write-Host ("Native helper : " + $(if ($helperReady) { "[OK] Ready at $HelperDir" } else { "[NOT CONFIGURED] Target: $HelperDir" }))
  exit 0
}

if (-not $nodeExe) {
  Write-Host 'Node.js 20 or newer was not found.' -ForegroundColor Yellow
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if ($winget) {
    $ans = Read-Host 'Install Node.js LTS via winget (OpenJS.NodeJS.LTS) now? [Y/N]'
    if ($ans.Trim().ToUpperInvariant() -eq 'Y') {
      & $winget.Source install --id OpenJS.NodeJS.LTS --exact --accept-package-agreements --accept-source-agreements
      if ($LASTEXITCODE -ne 0) {
        Write-Error "winget failed to install Node.js LTS (exit $LASTEXITCODE)."
        exit 1
      }
      Refresh-ProcessPath
      $nodeExe = Find-Node20
    }
  }
  if (-not $nodeExe) {
    Write-Host 'Please install Node.js 20 LTS or newer from https://nodejs.org/ and rerun Setup-Pro3DWorks-Native.cmd.'
    exit 1
  }
}
Write-Host "[OK] Node.js: $nodeExe"

if ($helperReady) {
  Write-Host "[OK] Pro3DWorks v$AppVersion native SolidWorks / NX helper is already configured and ready at:"
  Write-Host "     $HelperDir"
  if (-not $NoLaunch) {
    $launchAns = Read-Host 'Launch Pro3DWorks now via Start-Pro3DWorks-Native.cmd? [Y/N]'
    if ($launchAns.Trim().ToUpperInvariant() -eq 'Y') {
      & cmd.exe /c "`"$(Join-Path $Root 'Start-Pro3DWorks-Native.cmd')`""
    }
  }
  exit 0
}

if (-not $runtimeReady -and -not $py312) {
  Write-Host 'Python 3.12 (required by NVIDIA usd-convert-cad 0.3.0) was not found.' -ForegroundColor Yellow
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if ($winget) {
    $ans = Read-Host 'Install Python 3.12 via winget (Python.Python.3.12) now? [Y/N]'
    if ($ans.Trim().ToUpperInvariant() -eq 'Y') {
      & $winget.Source install --id Python.Python.3.12 --exact --accept-package-agreements --accept-source-agreements
      if ($LASTEXITCODE -ne 0) {
        Write-Error "winget failed to install Python 3.12 (exit $LASTEXITCODE)."
        exit 1
      }
      Refresh-ProcessPath
      $py312 = Find-Python312
    }
  }
  if (-not $py312) {
    Write-Host 'Please install Python 3.12 (64-bit) from https://www.python.org/downloads/release/python-3129/ and rerun Setup-Pro3DWorks-Native.cmd.'
    exit 1
  }
}
Write-Host "[OK] Python 3.12: $py312"
if ($runtimeReady) {
  Write-Host '[OK] Existing local NVIDIA usd-convert-cad 0.3.0 runtime detected - reusing it without re-downloading.' -ForegroundColor Green
}

Write-Host ''
Write-Host '================ NVIDIA RUNTIME LICENSE NOTICE ================' -ForegroundColor Cyan
Write-Host 'To decode native SolidWorks (.SLDPRT / .SLDASM) and Siemens NX (.prt)'
Write-Host 'files locally, Pro3DWorks configures an isolated Python 3.12 environment'
Write-Host 'using NVIDIA Omniverse CAD Converter (usd-convert-cad 0.3.0), which'
Write-Host 'includes the Tech Soft 3D HOOPS Exchange SDK licensed by NVIDIA.'
Write-Host ''
Write-Host 'Pro3DWorks does NOT bundle proprietary NVIDIA/HOOPS binaries or grant a license.'
Write-Host 'Review NVIDIA license terms before continuing:'
Write-Host '  - https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-software-license-agreement/'
Write-Host '  - https://docs.omniverse.nvidia.com/dev-guide/latest/common/NVIDIA_Omniverse_License_Agreement.html'
Write-Host '===============================================================' -ForegroundColor Cyan
$consent = Read-Host "Type I ACCEPT to continue under NVIDIA's license terms (anything else cancels)"
if ($consent.Trim().ToUpperInvariant() -ne 'I ACCEPT') {
  Write-Host 'Setup cancelled. Nothing was installed or modified.'
  exit 1
}

if (-not $runtimeReady) {
  Write-Host "Creating Python 3.12 virtual environment at $RuntimeDir\venv ..."
  New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
  $venvDir = Join-Path $RuntimeDir 'venv'
  & $py312 -m venv $venvDir
  if ($LASTEXITCODE -ne 0) { throw "python -m venv failed (exit $LASTEXITCODE)." }

  Write-Host 'Installing usd-convert-cad==0.3.0 into isolated venv ...'
  & $venvPython -m pip install --upgrade pip
  if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed (exit $LASTEXITCODE)." }
  & $venvPython -m pip install 'usd-convert-cad==0.3.0'
  if ($LASTEXITCODE -ne 0) { throw "pip install usd-convert-cad==0.3.0 failed (exit $LASTEXITCODE)." }

  if (-not (Test-UsdConvertCad $venvPython)) {
    throw 'usd-convert-cad==0.3.0 verification failed inside the new virtual environment.'
  }
}
Write-Host "[OK] NVIDIA usd-convert-cad 0.3.0 ready: $venvPython"

if (Test-Path -LiteralPath $HelperDir) {
  Write-Error "Target helper directory already exists but did not pass readiness check: $HelperDir`nRemove or rename that folder before rerunning setup."
  exit 1
}

Write-Host "Configuring Pro3DWorks native CAD helper at $HelperDir ..."
if ($IsKitMode) {
  $kitConfigScript = Join-Path $Root 'native-kit\configure-kit.mjs'
  & $nodeExe $kitConfigScript --output-dir $HelperDir --app (Join-Path $Root 'dist\Pro3DWorks.html') --python $venvPython --node $nodeExe --licensed-runtime
  if ($LASTEXITCODE -ne 0) { throw "configure-kit.mjs failed (exit $LASTEXITCODE)." }
} else {
  if (-not (Test-Path -LiteralPath (Join-Path $Root 'node_modules\esbuild') -PathType Container)) {
    Write-Host 'Installing project dependencies via npm ci (repo checkout mode)...'
    Push-Location $Root
    try {
      & npm.cmd ci
      if ($LASTEXITCODE -ne 0) { throw "npm ci failed (exit $LASTEXITCODE)." }
    } finally {
      Pop-Location
    }
  }
  $repoConfigScript = Join-Path $Root 'bridge\configure-native.mjs'
  & $nodeExe $repoConfigScript --output-dir $HelperDir --app (Join-Path $Root 'dist\Pro3DWorks.html') --python $venvPython --node $nodeExe --licensed-runtime
  if ($LASTEXITCODE -ne 0) { throw "configure-native.mjs failed (exit $LASTEXITCODE)." }
}

$finalDoctor = Invoke-HelperDoctor $nodeExe $HelperDir
if ($null -eq $finalDoctor -or -not $finalDoctor.PSObject.Properties['ready'] -or $finalDoctor.ready -ne $true) {
  throw "Final helper doctor check did not report ready=true at $HelperDir."
}

Write-Host ''
Write-Host '[SUCCESS] Pro3DWorks Native CAD Support is ready!' -ForegroundColor Green
Write-Host 'Supported native formats: SolidWorks (.SLDPRT, .SLDASM) and Siemens NX (.prt).'
Write-Host 'To launch Pro3DWorks anytime, double-click Start-Pro3DWorks-Native.cmd.'
Write-Host ''

if (-not $NoLaunch) {
  $launchAns = Read-Host 'Launch Pro3DWorks now? [Y/N]'
  if ($launchAns.Trim().ToUpperInvariant() -eq 'Y') {
    & cmd.exe /c "`"$(Join-Path $Root 'Start-Pro3DWorks-Native.cmd')`""
  }
}
exit 0
